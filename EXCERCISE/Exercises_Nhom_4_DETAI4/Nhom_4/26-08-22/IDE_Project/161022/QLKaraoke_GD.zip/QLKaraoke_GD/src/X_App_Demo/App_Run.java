package X_App_Demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import GUI.GUI_DangNhap;

public class App_Run {
	public static void main(String[] args) throws IOException {
		new GUI_DangNhap().main(args);
	}
}