package other;

public class demo {

}
