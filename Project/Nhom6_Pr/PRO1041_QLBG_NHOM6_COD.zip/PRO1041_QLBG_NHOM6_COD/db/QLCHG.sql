﻿DROP DATABASE QLCHG;
CREATE DATABASE QLCHG;
USE QLCHG;

DROP TABLE IF EXISTS TRANGTHAI;
CREATE TABLE TRANGTHAI(
ID INT PRIMARY KEY IDENTITY,
TRANGTHAI NVARCHAR(50) DEFAULT NULL
);

DROP TABLE IF EXISTS LOAI;
CREATE TABLE LOAI(
ID INT PRIMARY KEY IDENTITY,
LOAI NVARCHAR(50) UNIQUE DEFAULT NULL,
TRANGTHAI NVARCHAR(50) DEFAULT NULL
);

SELECT TRANGTHAI.TRANGTHAI FROM TRANGTHAI WHERE TRANGTHAI.TRANGTHAI = N'Hoạt động' OR TRANGTHAI.TRANGTHAI = N'Không hoạt động'

DROP TABLE IF EXISTS SIZE;
CREATE TABLE SIZE(
ID INT PRIMARY KEY IDENTITY, 
SIZE DECIMAL(20,1) UNIQUE DEFAULT 0,
TRANGTHAI NVARCHAR(50) DEFAULT NULL
);

DROP TABLE IF EXISTS HANG;
CREATE TABLE HANG(
ID INT PRIMARY KEY IDENTITY, 
HANG NVARCHAR(50) UNIQUE DEFAULT NULL,
TRANGTHAI NVARCHAR(50) DEFAULT NULL
);

DROP TABLE IF EXISTS NGUOIDUNG;
CREATE TABLE NGUOIDUNG(
ID INT PRIMARY KEY IDENTITY,
MAND NVARCHAR(50) UNIQUE DEFAULT NULL,
TENND NVARCHAR(50) DEFAULT NULL,
GIOITINH BIT DEFAULT NULL,
MATKHAU NVARCHAR(50) DEFAULT NULL,
SDT VARCHAR(50) DEFAULT NULL,
EMAIL NVARCHAR(50) DEFAULT NULL,
CHUCVU BIT DEFAULT NULL,
TRANGTHAI BIT DEFAULT NULL
);

DROP TABLE IF EXISTS SANPHAM;
CREATE TABLE SANPHAM(
ID INT PRIMARY KEY IDENTITY,
MASP NVARCHAR(50) UNIQUE DEFAULT NULL,
TENSP NVARCHAR(50) DEFAULT NULL
);

DROP TABLE IF EXISTS THONGTINSANPHAM;
CREATE TABLE THONGTINSANPHAM(
ID INT PRIMARY KEY IDENTITY,
MASP NVARCHAR(50) UNIQUE DEFAULT NULL,
ANH NVARCHAR(50) DEFAULT NULL,
MOTA NVARCHAR(255) DEFAULT NULL,
DONGIA DECIMAL(20,0) DEFAULT 0,
SOLUONG INT DEFAULT NULL,
LOAI NVARCHAR(50) DEFAULT NULL,
SIZE DECIMAL(20,1) DEFAULT NULL,
HANG NVARCHAR(50) DEFAULT NULL,
TRANGTHAI NVARCHAR(50) DEFAULT NULL,
CONSTRAINT FK1 FOREIGN KEY (MASP) REFERENCES SANPHAM(MASP),
CONSTRAINT FK2 FOREIGN KEY (LOAI) REFERENCES LOAI(LOAI),
CONSTRAINT FK3 FOREIGN KEY (SIZE) REFERENCES SIZE(SIZE),
CONSTRAINT FK4 FOREIGN KEY (HANG) REFERENCES HANG(HANG)
);

DROP TABLE IF EXISTS HOADON;
CREATE TABLE HOADON(
ID INT PRIMARY KEY IDENTITY,
MAHD NVARCHAR(100) UNIQUE DEFAULT NULL,
SDT VARCHAR(50) DEFAULT NULL,
TENKH NVARCHAR(100) DEFAULT NULL,
NGAYTAO DATE DEFAULT NULL,
DIACHI NVARCHAR(255) DEFAULT NULL,
GIASHIP DECIMAL(20,0) DEFAULT NULL,
MANV NVARCHAR(50) DEFAULT NULL,
THANHTIEN DECIMAL(20,0) DEFAULT NULL,
MOTA NVARCHAR(225) DEFAULT NULL,
TRANGTHAI NVARCHAR(50) DEFAULT NULL,
CACHTHUC BIT DEFAULT NULL,
CONSTRAINT FK6 FOREIGN KEY (MANV) REFERENCES NGUOIDUNG(MAND)
);

DROP TABLE IF EXISTS HDCHITIET;
CREATE TABLE HDCHITIET(
ID INT PRIMARY KEY IDENTITY,
SOLUONG INT DEFAULT 0,
DONGIA DECIMAL(20,0) DEFAULT 0,
MAHD NVARCHAR(100) DEFAULT NULL,
MASP NVARCHAR(50) DEFAULT NULL,
TRANGTHAI NVARCHAR(50) DEFAULT NULL,
CONSTRAINT FK7 FOREIGN KEY (MAHD) REFERENCES HOADON(MAHD),
CONSTRAINT FK8 FOREIGN KEY (MASP) REFERENCES SANPHAM(MASP)
);

DBCC CHECKIDENT (TRANGTHAI, RESEED, 0);
INSERT TRANGTHAI(TRANGTHAI)
VALUES (N'Hoạt động'),
(N'Không hoạt động'),
(N'Tại quầy'),
(N'Đã hủy'),
(N'Chờ xử lý'),
(N'Đã thanh toán'),
(N'Đang giao hàng'),
(N'Chưa thanh toán');
SELECT * FROM TRANGTHAI WHERE TRANGTHAI = N'Chờ xử lý' OR TRANGTHAI = N'Đã thanh toán'  OR TRANGTHAI = N'Đang giao hàng';
DELETE FROM TRANGTHAI;

DBCC CHECKIDENT (HANG, RESEED, 0);
INSERT INTO HANG(HANG, TRANGTHAI)
VALUES ('Nike', N'Hoạt động'),
('Balenciaga', N'Hoạt động'),
('Adidas', N'Hoạt động'),
('Puma', N'Hoạt động'),
('Vans', N'Hoạt động'),
('Fila', N'Hoạt động'),
('Converse', N'Hoạt động'),
('New Blance', N'Hoạt động'),
('Bitis', N'Hoạt động');
SELECT * FROM HANG;
DELETE FROM HANG;

DBCC CHECKIDENT (LOAI, RESEED, 0);
INSERT INTO LOAI(LOAI, TRANGTHAI)
VALUES ('Custom Shoes', N'Hoạt động'),
('Sneaker', N'Hoạt động'),
('Running Shoes', N'Hoạt động'),
('Basketball Shoes', N'Hoạt động'),
('Football Shoes', N'Hoạt động'),
('Gym & Training Shoes', N'Hoạt động'),
('Lifestyle Shoes', N'Hoạt động');
SELECT * FROM LOAI;
DELETE FROM LOAI;

DBCC CHECKIDENT (SIZE, RESEED, 0);
INSERT INTO SIZE(SIZE, TRANGTHAI)
VALUES (35.5, N'Hoạt động'),(36, N'Hoạt động'),(36.5, N'Hoạt động'),(37.5, N'Hoạt động'),(38, N'Hoạt động'),(38.5, N'Hoạt động'),(39, N'Hoạt động'),
(40, N'Hoạt động'),(40.5, N'Hoạt động'),(41, N'Hoạt động'),(42, N'Hoạt động'),(42.5, N'Hoạt động'),(43, N'Hoạt động'),(44, N'Hoạt động'),(44.5, N'Hoạt động'),
(45, N'Hoạt động'),(45.5, N'Hoạt động'),(46, N'Hoạt động'),(47, N'Hoạt động'),(47.5, N'Hoạt động'),(48, N'Hoạt động'),(48.5, N'Hoạt động'),(49, N'Hoạt động'),(49.5, N'Hoạt động');
SELECT * FROM SIZE;
DELETE FROM SIZE;

DBCC CHECKIDENT (NGUOIDUNG, RESEED, 0);
INSERT INTO NGUOIDUNG(MAND, TENND, GIOITINH, MATKHAU, SDT, EMAIL, CHUCVU, TRANGTHAI)
VALUES ('HAINH', N'Nguyễn Hoàng Hải', 1, '123456', '0868833489', 'Hainhph14825@gmail.com', 1, 1),
('NGONH', N'Nguyễn Hữu Ngọ', 1, '123456', 'N/A', 'Ngohnph15080@gmail.com', 0, 1);
SELECT * FROM NGUOIDUNG;
DELETE FROM NGUOIDUNG;

DBCC CHECKIDENT (SANPHAM, RESEED, 0);
INSERT INTO SANPHAM (MASP, TENSP)
VALUES ('SP001', 'Air Jordan 1 Mid Fearless Blue'),
('SP002', 'Adidas Yeezy Boost Black 350 V2 – Supreme'),
('SP003', 'Fila Cozy i7 Custom'),
('SP004', 'Bitis Air Zoom Alphafly Green NEXT%'),
('SP005', 'Nike Jordan Retro Low White Black'),
('SP006', 'Vans Retro Low White Black'),
('SP007', 'Balenciaga Tripple S Black'),
('SP008', 'Converse Chuck Taylor Black All Star Classic'),
('SP009', 'Sneaker Vans Old Skool Classic White'),
('SP010', 'New Blance 480LBG White Green'),
('SP011', 'New Blance 320LBGT Black Green'),
('SP012', 'Adidas ver18 Black Pink'),
('SP013', 'Vans in Gay Day'),
('SP014', 'Sneaker Desert Egile'),
('SP015', 'Balenciaga Tripple S White'),
('SP016', 'Converse Chuck Taylor Swift'),
('SP017', 'Fila Cozy Binla-den'),
('SP018', 'Sneaker Vans Gay Pink'),
('SP019', 'Adidas Yeezy Boost Black 350 V2 – Supreme'),
('SP020', 'New Blance Buzz Kill'),
('SP021', 'Sneaker Vans Origami'),
('SP022', 'Sneaker Prey'),
('SP023', 'Desert Eagle PrintStream'),
('SP024', 'MP9 Bioleak'),
('SP025', 'AK Frontside Misty'),
('SP026', 'USP Cortex'),
('SP027', 'Desert Eagle Corinthian'),
('SP028', 'SSG 08 Prey'),
('SP029', 'M4A1 Flashback'),
('SP030', 'Glock Off World'),
('SP031', 'Rezan The Ready Sabre'),
('SP032', 'Buckshot NSWC SEAL'),
('SP033', 'AUG Triqua');
SELECT * FROM SANPHAM;
DELETE FROM SANPHAM;

DBCC CHECKIDENT (THONGTINSANPHAM, RESEED, 0);
INSERT INTO THONGTINSANPHAM(MASP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI)
VALUES ('SP001', 'Air Jordan 1 Mid Fearless Blue.jpg', 'N/A', 3500000, 20, 'Sneaker', '40', 'Nike', N'Hoạt động'),
('SP002', 'Adidas Yeezy Boost Black 350 V2 – Supreme.jpg', 'N/A', 6500000, 20, 'Sneaker', '36.0', 'Adidas', N'Hoạt động'),
('SP003', 'Fila Cozy i7 Custom.jpg', 'N/A', 5500000, 20, 'Sneaker', '49.5', 'Fila', N'Hoạt động'),
('SP004', 'Bitis Air Zoom Alphafly Green NEXT%.jpg', 'N/A', 8500000, 20, 'Sneaker', '46', 'Bitis', N'Hoạt động'),
('SP005', 'Nike Jordan Retro Low White Black.jpg', 'N/A', 5500000, 20, 'Sneaker', '38.0', 'Nike', N'Hoạt động'),
('SP006', 'Vans Retro Low White Black.jpg', 'N/A', 9500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP007', 'Balenciaga Tripple S Black.jpg', 'N/A', 5500000, 20, 'Sneaker', '45.5', 'Balenciaga', N'Hoạt động'),
('SP008', 'Converse Chuck Taylor Black All Star Classic.jpg', 'N/A', 1500000, 20, 'Sneaker', '36', 'Converse', N'Hoạt động'),
('SP009', 'Sneaker Vans Old Skool Classic White.jpg', 'N/A', 3500000, 20, 'Sneaker', '40', 'Vans', N'Hoạt động'),
('SP010', 'New Blance 480LBG White Green.jpg', 'N/A', 4500000, 20, 'Sneaker', '48', 'New Blance', N'Hoạt động'),
('SP011', 'New Blance 320LBGT Black Green.jpg', 'N/A', 9500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP012', 'Adidas ver18 Black Pink.jpg', 'N/A', 5000000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP013', 'Vans in Gay Day.jpg', 'N/A', 2500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP014', 'Sneaker Desert Egile.jpg', 'N/A', 2300000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP015', 'Balenciaga Tripple S White.jpg', 'N/A', 5700000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP016', 'Converse Chuck Taylor Swift.jpg', 'N/A', 8900000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP017', 'Fila Cozy Binla den.jpg', 'N/A', 2300000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP018', 'Sneaker Vans Gay Pink.jpg', 'N/A', 5900000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP019', 'Adidas Yeezy Boost Black 350 V2 – Supreme.jpg', 'N/A', 4100000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP020', 'New Blance Buzz Kill.jpg', 'N/A', 1500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP021', 'Sneaker Vans Origami.jpg', 'N/A', 8700000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP022', 'Sneaker Prey.jpg', 'N/A', 2400000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP023', 'Desert Eagle PrintStream.jpg', 'N/A', 5500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP024', 'MP9 Bioleak.jpg', 'N/A', 7500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP025', 'AK Frontside Misty.jpg', 'N/A', 6500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP026', 'USP Cortex.jpg', 'N/A', 1500000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP027', 'Desert Eagle Corinthian.jpg', 'N/A', 1700000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP028', 'SSG 08 Prey.jpg', 'N/A', 6300000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP029', 'M4A1 Flashback.jpg', 'N/A', 6800000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP030', 'Glock Off World.jpg', 'N/A', 2700000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP031', 'Rezan The Ready Sabre.jpg', 'N/A', 5700000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP032', 'Buckshot NSWC SEAL.jpg', 'N/A', 1800000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động'),
('SP033', 'AUG Triqua.jpg', 'N/A', 1900000, 20, 'Sneaker', '35.5', 'Vans', N'Hoạt động');
SELECT * FROM THONGTINSANPHAM;
DELETE FROM THONGTINSANPHAM;

DBCC CHECKIDENT (HOADON, RESEED, 0);
INSERT INTO HOADON (MAHD, SDT, TENKH, NGAYTAO, DIACHI, GIASHIP, MANV, THANHTIEN, MOTA, TRANGTHAI, CACHTHUC)
VALUES ('HD001', '0674556944', N'Nguyễn Duy Phong', '2021-10-28', N'HÀ NỘI', 15000, 'HAINH', 3500000, 'N/A', N'Đã thanh toán', 1),
('HD002', '0988767765', N'Nguyễn Thu Hà', '2021-10-28', N'HÀ NỘI', 15000, 'HAINH', 6500000, 'N/A', N'Đã thanh toán', 1),
('HD003', '0898734456', N'Nguyễn Hoàng Thất', '2021-10-28', N'HÀ NỘI', 15000, 'HAINH', 5500000, 'N/A', N'Đã thanh toán', 1),
('HD004', '0786774321', N'Nguyễn Thị Chi', '2021-10-28', N'HÀ NỘI', 15000, 'HAINH', 8500000, 'N/A', N'Đã thanh toán', 1),
('HD005', '0508777554', N'Nguyễn Thế Phong', '2021-10-28', N'HÀ NỘI', 15000, 'HAINH', 5500000, 'N/A', N'Đã thanh toán', 1),
('HD006', '0434661276', N'Bùi Thị Yến', '2021-10-28', N'HÀ NỘI', 15000, 'NGONH', 9500000, 'N/A', N'Đã thanh toán', 1),
('HD007', '0354883409', N'Phạm Duy Khải', '2021-10-28', N'HÀ NỘI', 15000, 'NGONH', 5500000, 'N/A', N'Đã thanh toán', 1),
('HD008', '0269330912', N'Chu Thị Ngọc', '2021-10-28', N'HÀ NỘI', 15000, 'NGONH', 1500000, 'N/A', N'Đã thanh toán', 1),
('HD009', '0133656556', N'Hồ Quang Đại', '2021-10-28', N'HÀ NỘI', 15000, 'NGONH', 3500000, 'N/A', N'Đã thanh toán', 1),
('HD010', '0955600328', N'Nguyễn Thị Mai', '2021-10-28', N'HÀ NỘI', 15000, 'NGONH', 4500000, 'N/A', N'Đã thanh toán', 1),
('HD011', '0868833489', N'Nguyễn Hoàng Hải', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 9000000, 'N/A', N'Đã thanh toán', 1),
('HD012', '0868833414', N'Đinh Bộ Lĩnh', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 2300000, 'N/A', N'Đã thanh toán', 1),
('HD013', '0868833415', N'Lê Hoàn', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 9800000, 'N/A', N'Đã thanh toán', 1),
('HD014', '0868833427', N'Lý Công Uẩn', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 9200000, 'N/A', N'Đã thanh toán', 1),
('HD015', '0868833441', N'Trần Thủ Độ', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 3000000, 'N/A', N'Đã thanh toán', 1),
('HD016', '0868833485', N'Trần Cảnh', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 6000000, 'N/A', N'Đã thanh toán', 1),
('HD017', '0868833425', N'Trần Quốc Tuấn', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 8500000, 'N/A', N'Đã thanh toán', 1),
('HD018', '0328833489', N'Trần Quốc Toản', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 9000000, 'N/A', N'Đã thanh toán', 1),
('HD019', '0238833489', N'Hồ Quý Ly', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 3600000, 'N/A', N'Đã thanh toán', 1),
('HD020', '0258833489', N'Hồ Nguyên Trừng', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 10000000, 'N/A', N'Đã thanh toán', 1),
('HD021', '0857883489', N'Lê Lợi', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 90000000, 'N/A', N'Đã thanh toán', 1),
('HD022', '0868253389', N'Lê Tư Thành', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 19000000, 'N/A', N'Đã thanh toán', 1),
('HD023', '0868243489', N'Mạc Đăng Dung', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 3900000, 'N/A', N'Đã thanh toán', 1),
('HD024', '0868814489', N'Tôn Đức Thắng', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 5900000, 'N/A', N'Đã thanh toán', 1),
('HD025', '0868825349', N'Hoàng Phủ Ngọc Tường', '2021-12-04', N'HÀ NỘI', 15000, 'HAINH', 9500000, 'N/A', N'Đã thanh toán', 1),
('HD026', '0888825349', N'Thủ Thỉ Khỏa', '2021-12-07', N'HÀ NỘI', 15000, 'HAINH', 9500000, 'N/A', N'Đang giao hàng', 1);
SELECT * FROM HOADON;
DELETE FROM HOADON;

DBCC CHECKIDENT (HDCHITIET, RESEED, 0);
INSERT INTO HDCHITIET (SOLUONG, DONGIA, MAHD, MASP, TRANGTHAI)
VALUES (1, 3500000, 'HD001', 'SP001', N'Đã thanh toán'),
(1, 6500000, 'HD002', 'SP002', N'Đã thanh toán'),
(1, 5500000, 'HD003', 'SP003', N'Đã thanh toán'),
(1, 8500000, 'HD004', 'SP004', N'Đã thanh toán'),
(1, 5500000, 'HD005', 'SP005', N'Đã thanh toán'),
(1, 9500000, 'HD006', 'SP006', N'Đã thanh toán'),
(1, 5500000, 'HD007', 'SP007', N'Đã thanh toán'),
(1, 1500000, 'HD008', 'SP008', N'Đã thanh toán'),
(1, 3500000, 'HD009', 'SP009', N'Đã thanh toán'),
(1, 4500000, 'HD010', 'SP010', N'Đã thanh toán'),
(1, 4500000, 'HD011', 'SP010', N'Đã thanh toán'),
(1, 4500000, 'HD011', 'SP009', N'Đã thanh toán'),
(1, 5000000, 'HD012', 'SP012', N'Đã thanh toán'),
(1, 5000000, 'HD012', 'SP010', N'Đã thanh toán'),
(1, 9200000, 'HD013', 'SP013', N'Đã thanh toán'),
(1, 2300000, 'HD014', 'SP014', N'Đã thanh toán'),
(1, 3000000, 'HD015', 'SP015', N'Đã thanh toán'),
(1, 6000000, 'HD016', 'SP016', N'Đã thanh toán'),
(1, 8500000, 'HD017', 'SP017', N'Đã thanh toán'),
(1, 6000000, 'HD017', 'SP016', N'Đã thanh toán'),
(1, 9000000, 'HD018', 'SP018', N'Đã thanh toán'),
(1, 3600000, 'HD019', 'SP019', N'Đã thanh toán'),
(1, 10000000, 'HD020', 'SP020', N'Đã thanh toán'),
(1, 90000000, 'HD021', 'SP021', N'Đã thanh toán'),
(1, 10000000, 'HD021', 'SP022', N'Đã thanh toán'),
(1, 19000000, 'HD022', 'SP022', N'Đã thanh toán'),
(1, 3900000, 'HD023', 'SP023', N'Đã thanh toán'),
(1, 5900000, 'HD024', 'SP024', N'Đã thanh toán'),
(1, 9500000, 'HD025', 'SP025', N'Đã thanh toán'),
(1, 9500000, 'HD026', 'SP025', N'Đang giao hàng'),
(1, 9500000, 'HD026', 'SP025', N'Đang giao hàng');
