package DAO;

import ENTITY.HDCT_ENTITY;
import HELPER.JDBC_HELPER;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HDCT_DAO {

    String INSERT_SQL = "INSERT INTO HDCHITIET(SOLUONG,MAHD,MASP,DONGIA,TRANGTHAI)  VALUES(?,?,?,?,?)";
    String S = "UPDATE HDCHITIET SET SOLUONG = ? WHERE MAHD = ? AND MASP = ?";
    String XOA = "UPDATE HDCHITIET SET TRANGTHAI = ? WHERE MAHD = ? AND MASP = ?";
    String SELECT_ALL_SQL = "select MAHD,TENSP,HANG,SIZE,LOAI,HDCHITIET.TRANGTHAI,HDCHITIET.SOLUONG,"
            + "HDCHITIET.DONGIA,THONGTINSANPHAM.MASP from HDCHITIET \n"
            + "JOIN THONGTINSANPHAM ON THONGTINSANPHAM.MASP=HDCHITIET.MASP\n"
            + "JOIN SANPHAM ON SANPHAM.MASP=HDCHITIET.MASP\n"
            + "where HDCHITIET.TRANGTHAI = ? and MAHD = ?";
    String SELECT_ALL_SQL_HUY = "select MAHD,TENSP,HANG,SIZE,LOAI,HDCHITIET.TRANGTHAI,HDCHITIET.SOLUONG,"
            + "HDCHITIET.DONGIA,THONGTINSANPHAM.MASP from HDCHITIET \n"
            + "JOIN THONGTINSANPHAM ON THONGTINSANPHAM.MASP=HDCHITIET.MASP\n"
            + "JOIN SANPHAM ON SANPHAM.MASP=HDCHITIET.MASP\n"
            + "where HDCHITIET.TRANGTHAI = ? and MAHD = ?";

    String SELECT_BY_ID_SQL = "select MAHD,TENSP,HANG,SIZE,LOAI,HDCHITIET.TRANGTHAI,HDCHITIET.SOLUONG,HDCHITIET.DONGIA,THONGTINSANPHAM.MASP from HDCHITIET \n"
            + "JOIN THONGTINSANPHAM ON THONGTINSANPHAM.MASP=HDCHITIET.MASP\n"
            + "JOIN SANPHAM ON SANPHAM.MASP=HDCHITIET.MASP\n"
            + "where HDCHITIET.TRANGTHAI = ? and HDCHITIET.MAHD= ? and HDCHITIET.MASP = ? ";

    String SELECT_BY_ID_TENSP = "select MAHD,TENSP,HANG,SIZE,LOAI,HDCHITIET.TRANGTHAI,HDCHITIET.SOLUONG,HDCHITIET.DONGIA,THONGTINSANPHAM.MASP from HDCHITIET\n"
            + "          JOIN THONGTINSANPHAM ON THONGTINSANPHAM.MASP=HDCHITIET.MASP\n"
            + "          JOIN SANPHAM ON SANPHAM.MASP=HDCHITIET.MASP\n"
            + "          where HDCHITIET.TRANGTHAI = ? and HDCHITIET.MAHD= ?  and TENSP = ? ";

    public void Insert(HDCT_ENTITY hd_Entity) {
        JDBC_HELPER.executeUpdate(this.INSERT_SQL, hd_Entity.getSoluong(), hd_Entity.getMaHD(), hd_Entity.getMaSP(),
                 hd_Entity.getDonGia(), "Đã thanh toán");
    }

    public void Update_HDCT_TRUNGMASP(HDCT_ENTITY sp_Entity) {
        JDBC_HELPER.executeUpdate(S, sp_Entity.getSoluong(), sp_Entity.getMaHD(), sp_Entity.getMaSP());

    }

    public void XOA_HDCT(String mahd, String masp) {
        JDBC_HELPER.executeUpdate(this.XOA, "Không hoạt động", mahd, masp);

    }

    public List<HDCT_ENTITY> selectAll(String key) {
        return this.selectbySQL(this.SELECT_ALL_SQL, "Đã thanh toán", key);
    }
    public HDCT_ENTITY selectByID_masp(String mahd, String masp) {
        List<HDCT_ENTITY> lst = this.selectbySQL(this.SELECT_BY_ID_SQL, "Hoạt động", mahd, masp);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public HDCT_ENTITY selectByID_tensp(String mahd, String tensp) {
        List<HDCT_ENTITY> lst = this.selectbySQL(this.SELECT_BY_ID_TENSP, "Đã thanh toán", mahd, tensp);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public List<HDCT_ENTITY> selectbySQL(String sql, Object... args) {
        List<HDCT_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                HDCT_ENTITY hdct_entity = new HDCT_ENTITY();
                hdct_entity.setDonGia(rs.getFloat("DONGIA"));
                hdct_entity.setMaHD(rs.getString("MAHD"));
                hdct_entity.setMaSP(rs.getString("MASP"));
                hdct_entity.setSoluong(rs.getInt("SOLUONG"));
                hdct_entity.setTrangThai(rs.getString("TRANGTHAI"));
                hdct_entity.setLoai(rs.getString("LOAI"));
                hdct_entity.setHang(rs.getString("HANG"));
                hdct_entity.setSize(rs.getFloat("SIZE"));
                hdct_entity.setTenSP(rs.getString("TENSP"));
                lst.add(hdct_entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
