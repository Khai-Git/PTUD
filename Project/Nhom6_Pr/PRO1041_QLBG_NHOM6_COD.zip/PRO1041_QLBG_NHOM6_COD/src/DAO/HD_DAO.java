package DAO;

import ENTITY.HD_ENTITY;
import HELPER.JDBC_HELPER;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class HD_DAO {

   
    String INSERT_SQL = "INSERT INTO HOADON(MAHD,NGAYTAO,TRANGTHAI) VALUES (?,?,?) ";
    String UPDATE_HOANTHANHHD = "UPDATE HOADON SET NGAYTAO =?, DIACHI = ? , MANV = ?, THANHTIEN = ?, MOTA =?, TRANGTHAI=?,"
            + " GIASHIP = ?,SDT = ?,TENKH= ?"
            + " WHERE MAHD = ?";
    String UPDATE="UPDATE HOADON SET TRANGTHAI = ?  WHERE MAHD = ?";
    
    String SELECT_HD_SEARCH3 = "SELECT * FROM HOADON WHERE"
            + " MAHD LIKE ? OR TENKH LIKE ? OR DIACHI LIKE ? OR SDT LIKE ? OR MANV LIKE ? "
            + "and TRANGTHAI = ?";
    String DELETE_SQL = "DELETE FROM SANPHAM WHERE MASP = ?\n"
            + "DELETE FROM THONGTINSANPHAM WHERE MASP = ?";
    String SELECT_ALL_SQL = "select MAHD,TENKH,TENND,THANHTIEN,HOADON.DIACHI,NGAYTAO,MANV,MOTA,HOADON.TRANGTHAI,GIASHIP,HOADON.SDT from HOADON\n"
            + "FULL JOIN NGUOIDUNG ON NGUOIDUNG.MAND = HOADON.MANV\n";
         
    String SELECT_ALL_SQL_HUY = "select MAHD,TENKH,TENND,THANHTIEN,HOADON.DIACHI,NGAYTAO,MANV,MOTA,HOADON.TRANGTHAI,GIASHIP,HOADON.SDT from HOADON\n"
            + "FULL JOIN NGUOIDUNG ON NGUOIDUNG.MAND = HOADON.MANV\n"
            +" WHERE HOADON.TRANGTHAI = ?";
    
    String SELECT_BY_LOAI_SQL = "select MAHD,TENKH,TENND,THANHTIEN,HOADON.DIACHI,NGAYTAO,MANV,MOTA,HOADON.TRANGTHAI,GIASHIP,HOADON.SDT from HOADON\n"
            + "FULL JOIN NGUOIDUNG ON NGUOIDUNG.MAND = HOADON.MANV\n"
            +" WHERE HOADON.TRANGTHAI = ?";
    public void Insert(HD_ENTITY hd_Entity) {
        JDBC_HELPER.executeUpdate(this.INSERT_SQL, hd_Entity.getMaHD(), hd_Entity.getNgayTao(), "Chờ sử lí");
    }

    public List<HD_ENTITY> SELECT_T3_search(String input) {
        return this.selectbySQL(this.SELECT_HD_SEARCH3, "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%", "Hoạt động");
    }

    public void Update_HD_HOANTHANH(HD_ENTITY hd_en) {
        JDBC_HELPER.executeUpdate(this.UPDATE_HOANTHANHHD, hd_en.getNgayTao(), hd_en.getDiaChi(),
                hd_en.getMaNV(), hd_en.getThanhTien(), hd_en.getMota(), hd_en.getTrangThai(),
                hd_en.getGiaship(), hd_en.getSDT(),hd_en.getTenKH(), hd_en.getMaHD());
    }
     public void Update(String mahd,String trangthai) {
        JDBC_HELPER.executeUpdate(this.UPDATE, trangthai, mahd);
    }

    public List<HD_ENTITY> selectAll() {
        return this.selectbySQL(this.SELECT_ALL_SQL);
    }
    public List<HD_ENTITY> selectAll_LOAI(String loai) {
        return this.selectbySQL(this.SELECT_ALL_SQL_HUY, loai);
    }
    public HD_ENTITY selectByID(String key) {
        List<HD_ENTITY> lst = this.selectbySQL(this.SELECT_BY_LOAI_SQL, key);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public List<HD_ENTITY> selectbySQL(String sql, Object... args) {
        List<HD_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                HD_ENTITY hd_Entity = new HD_ENTITY();
                hd_Entity.setMaHD(rs.getString("MAHD"));
                hd_Entity.setDiaChi(rs.getString("DIACHI"));
                hd_Entity.setNgayTao(rs.getDate("NGAYTAO"));
                hd_Entity.setTrangThai(rs.getString("TRANGTHAI"));
                hd_Entity.setSDT(rs.getString("SDT"));
                hd_Entity.setTenKH(rs.getString("TENKH"));
                hd_Entity.setMaNV(rs.getString("TENND"));
                hd_Entity.setThanhTien(rs.getFloat("THANHTIEN"));
                lst.add(hd_Entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
