package DAO;

import ENTITY.KHACHHANG_ENTITY;
import HELPER.JDBC_HELPER;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class KH_DAO {

    String SELECT_KH_CBB = "SELECT * FROM KHACHHANG WHERE SDT = ?";
    String SELECT_KH_BYTENKH = "SELECT * FROM KHACHHANG WHERE TENKH = ?";

    public KHACHHANG_ENTITY select_cbb_kh(String input) {
         List<KHACHHANG_ENTITY> lst = this.selectbySQL(this.SELECT_KH_CBB,input);
         if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public KHACHHANG_ENTITY select_kh_byyenkh(String tenkh) {
        List<KHACHHANG_ENTITY> lst = this.selectbySQL(this.SELECT_KH_BYTENKH, tenkh);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public List<KHACHHANG_ENTITY> selectbySQL(String sql, Object... args) {
        List<KHACHHANG_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                KHACHHANG_ENTITY kh_Entity = new KHACHHANG_ENTITY();
                kh_Entity.setID(rs.getInt("ID"));
                kh_Entity.setSDT(rs.getString("SDT"));
                kh_Entity.setTenKH(rs.getString("TENKH"));
                kh_Entity.setGioiTinh(rs.getBoolean("GIOITINH"));
                kh_Entity.setEmail(rs.getString("EMAIL"));
                kh_Entity.setDiaChi(rs.getString("DIACHI"));
                lst.add(kh_Entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
