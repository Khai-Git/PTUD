package DAO;

import ENTITY.HANG_ENTITY;
import ENTITY.LOAI_ENTITY;
import ENTITY.SIZE_ENTITY;
import ENTITY.TRANGTHAI_ENTITY;
import HELPER.JDBC_HELPER;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LSHT_DAO {

    //Bắt đầu: Quản lý loại    
    public List<LOAI_ENTITY> selectLoaiHD() {
        String sql = "SELECT * FROM LOAI WHERE TRANGTHAI = N'Hoạt động'";
        return this.selectBySqlLoai(sql);
    }

    public List<LOAI_ENTITY> selectLoaiKHD() {
        String sql = "SELECT * FROM LOAI WHERE TRANGTHAI = N'Không hoạt động'";
        return this.selectBySqlLoai(sql);
    }

    public void insert(LOAI_ENTITY entity) {
        String sql = "INSERT LOAI(LOAI, TRANGTHAI) VALUES (?, ?)";
        JDBC_HELPER.executeUpdate(sql, entity.getLoai(), entity.getTrangThai());
    }

    public void updateHD(LOAI_ENTITY entity) {
        String sql = "UPDATE LOAI SET TRANGTHAI = N'Hoạt động' WHERE LOAI = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getLoai());
    }

    public void updateKHD(LOAI_ENTITY entity) {
        String sql = "UPDATE LOAI SET TRANGTHAI = N'Không hoạt động' WHERE LOAI = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getLoai());
    }

    public List<LOAI_ENTITY> getAllLoai() {
        String SQL_SELECT_ALL = "SELECT * FROM LOAI";
        try {
            List<LOAI_ENTITY> lst = new ArrayList<>();
            try (Connection conn = JDBC_HELPER.opConnection(); PreparedStatement pds = conn.prepareStatement(SQL_SELECT_ALL)) {
                ResultSet rs = pds.executeQuery();
                while (rs.next()) {
                    lst.add(new LOAI_ENTITY(rs.getString("LOAI"), rs.getString("TRANGTHAI")));
                }
                return lst;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<LOAI_ENTITY> getAllLoaiHD() {
        String SQL_SELECT_ALL_HD = "SELECT * FROM LOAI WHERE TRANGTHAI = N'Hoạt động'";
        try {
            List<LOAI_ENTITY> lst = new ArrayList<>();
            try (Connection conn = JDBC_HELPER.opConnection(); PreparedStatement pds = conn.prepareStatement(SQL_SELECT_ALL_HD)) {
                ResultSet rs = pds.executeQuery();
                while (rs.next()) {
                    lst.add(new LOAI_ENTITY(rs.getString("LOAI"), rs.getString("TRANGTHAI")));
                }
                return lst;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    protected List<LOAI_ENTITY> selectBySqlLoai(String sql, Object... args) {
        List<LOAI_ENTITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                LOAI_ENTITY l = new LOAI_ENTITY();
                l.setLoai(rs.getString("LOAI"));
                l.setTrangThai(rs.getString("TRANGTHAI"));
                list.add(l);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    //Bắt đầu: Quản lý size    
    public List<SIZE_ENTITY> selectSizeHD() {
        String sql = "SELECT * FROM SIZE WHERE TRANGTHAI = N'Hoạt động'";
        return this.selectBySqlSize(sql);
    }

    public List<SIZE_ENTITY> selectSizeKHD() {
        String sql = "SELECT * FROM SIZE WHERE TRANGTHAI = N'Không hoạt động'";
        return this.selectBySqlSize(sql);
    }

    public void insert(SIZE_ENTITY entity) {
        String sql = "INSERT SIZE(SIZE, TRANGTHAI) VALUES (?, ?)";
        JDBC_HELPER.executeUpdate(sql, entity.getSize(), entity.getTrangThai());
    }

    public void updateHD(SIZE_ENTITY entity) {
        String sql = "UPDATE SIZE SET TRANGTHAI = N'Hoạt động' WHERE SIZE = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getSize());
    }

    public void updateKHD(SIZE_ENTITY entity) {
        String sql = "UPDATE SIZE SET TRANGTHAI = N'Không hoạt động' WHERE SIZE = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getSize());
    }

    public List<SIZE_ENTITY> getAllSize() {
        String SQL_SELECT_ALL = "SELECT * FROM SIZE";
        try {
            List<SIZE_ENTITY> lst = new ArrayList<>();
            try (Connection conn = JDBC_HELPER.opConnection(); PreparedStatement pds = conn.prepareStatement(SQL_SELECT_ALL)) {
                ResultSet rs = pds.executeQuery();
                while (rs.next()) {
                    lst.add(new SIZE_ENTITY(rs.getString("SIZE"), rs.getString("TRANGTHAI")));
                }
                return lst;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    protected List<SIZE_ENTITY> selectBySqlSize(String sql, Object... args) {
        List<SIZE_ENTITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                SIZE_ENTITY l = new SIZE_ENTITY();
                l.setSize(rs.getString("SIZE"));
                l.setTrangThai(rs.getString("TRANGTHAI"));
                list.add(l);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    //Bắt đầu: Quản lý hãng   
    public List<HANG_ENTITY> selectHangHD() {
        String sql = "SELECT * FROM HANG WHERE TRANGTHAI = N'Hoạt động'";
        return this.selectBySqlHang(sql);
    }

    public List<HANG_ENTITY> selectHangKHD() {
        String sql = "SELECT * FROM HANG WHERE TRANGTHAI = N'Không hoạt động'";
        return this.selectBySqlHang(sql);
    }

    public void insert(HANG_ENTITY entity) {
        String sql = "INSERT INTO HANG(HANG, TRANGTHAI) VALUES (?, ?)";
        JDBC_HELPER.executeUpdate(sql, entity.getHang(), entity.getTrangThai());
    }

    public void updateHD(HANG_ENTITY entity) {
        String sql = "UPDATE HANG SET TRANGTHAI = N'Hoạt động' WHERE HANG = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getHang());
    }

    public void updateKHD(HANG_ENTITY entity) {
        String sql = "UPDATE HANG SET TRANGTHAI = N'Không hoạt động' WHERE HANG = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getHang());
    }

    public List<HANG_ENTITY> getAllHang() {
        String SQL_SELECT_ALL = "SELECT * FROM HANG";
        try {
            List<HANG_ENTITY> lst = new ArrayList<>();
            try (Connection conn = JDBC_HELPER.opConnection(); PreparedStatement pds = conn.prepareStatement(SQL_SELECT_ALL)) {
                ResultSet rs = pds.executeQuery();
                while (rs.next()) {
                    lst.add(new HANG_ENTITY(rs.getString("HANG"), rs.getString("TRANGTHAI")));
                }
                return lst;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    protected List<HANG_ENTITY> selectBySqlHang(String sql, Object... args) {
        List<HANG_ENTITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                HANG_ENTITY l = new HANG_ENTITY();
                l.setHang(rs.getString("HANG"));
                l.setTrangThai(rs.getString("TRANGTHAI"));
                list.add(l);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    //Bắt đầu: Quản lý trạng thái    
    public void insert(TRANGTHAI_ENTITY entity) {
        String sql = "INSERT INTO TRANGTHAI(TRANGTHAI, TRANGTHAI) VALUES (?, ?)";
        JDBC_HELPER.executeUpdate(sql, entity.getTenTT());
    }

    public List<TRANGTHAI_ENTITY> getAllTT() {
        String SQL_SELECT_ALL = "SELECT TRANGTHAI FROM TRANGTHAI WHERE TRANGTHAI = N'Hoạt động' OR TRANGTHAI = N'Không hoạt động'";
        try {
            List<TRANGTHAI_ENTITY> lst = new ArrayList<>();
            try (Connection conn = JDBC_HELPER.opConnection(); PreparedStatement pds = conn.prepareStatement(SQL_SELECT_ALL)) {
                ResultSet rs = pds.executeQuery();
                while (rs.next()) {
                    lst.add(new TRANGTHAI_ENTITY(rs.getString("TRANGTHAI")));
                }
                return lst;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    protected List<TRANGTHAI_ENTITY> selectBySqlTT(String sql, Object... args) {
        List<TRANGTHAI_ENTITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                TRANGTHAI_ENTITY tt = new TRANGTHAI_ENTITY();
                tt.setTenTT(rs.getString("TRANGTHAI"));
                list.add(tt);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }
}
