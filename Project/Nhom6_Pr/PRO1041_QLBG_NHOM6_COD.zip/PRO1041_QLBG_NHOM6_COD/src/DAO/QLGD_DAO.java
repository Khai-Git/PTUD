package DAO;

import ENTITY.SANPHAM_ENTITY;
import HELPER.JDBC_HELPER;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class QLGD_DAO {

    String UPDATE_SP_TBL1_SL_SQL = "UPDATE THONGTINSANPHAM SET SOLUONG = ?  WHERE MASP = ?";
    String SELECT_ALL_SQL = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM "
            + "JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP"
            + " WHERE TRANGTHAI = ?";
    String SELECT_T1_search = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM \n"
            + "            JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP \n"
            + "             WHERE THONGTINSANPHAM.MASP LIKE ?\n"
            + "            OR LOAI LIKE ? \n"
            + "            OR HANG LIKE  ?\n"
            + "            OR SIZE LIKE ? \n"
            + "            OR SANPHAM.TENSP LIKE ?\n"
            + "            AND TRANGTHAI = ? ";
    String SELECT_BY_ID_SQL = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM\n"
            + "JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP\n"
            + "WHERE SANPHAM.MASP = ? AND TRANGTHAI = ?";
    String SELECT_BY_ID_TENSP = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM\n"
            + "JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP\n"
            + "WHERE TENSP = ? AND TRANGTHAI = ?";
    String SELECT_XOAHDCT = "SELECT * FROM THONGTINSANPHAM WHERE MASP = ?";

    public List<SANPHAM_ENTITY> selectAll() {
        return this.selectbySQL(this.SELECT_ALL_SQL, "Hoạt động");
    }

    public void Update(int soluong, String ma) {
        //update so luong vao san pham chi tiet trong qlsp 
        JDBC_HELPER.executeUpdate(UPDATE_SP_TBL1_SL_SQL, soluong, ma);
    }

    public List<SANPHAM_ENTITY> SELECT_T1_search(String input) {
        return this.selectbySQL(this.SELECT_T1_search, "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%", "Hoạt động");
    }

    public SANPHAM_ENTITY SELECT_XOAHDCT(String masp) {
        List<SANPHAM_ENTITY> lst = this.selectbySQL(this.SELECT_XOAHDCT, masp);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public SANPHAM_ENTITY selectByID(String key) {
        List<SANPHAM_ENTITY> lst = this.selectbySQL(this.SELECT_BY_ID_SQL, key, "Hoạt động");
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public SANPHAM_ENTITY selectBytensp(String key) {
        List<SANPHAM_ENTITY> lst = this.selectbySQL(this.SELECT_BY_ID_SQL, key, "Hoạt động");
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public List<SANPHAM_ENTITY> selectbySQL(String sql, Object... args) {
        List<SANPHAM_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                SANPHAM_ENTITY sp_Entity = new SANPHAM_ENTITY();
                sp_Entity.setMaSP(rs.getString("MASP"));
                sp_Entity.setTenSP(rs.getString("TENSP"));
                sp_Entity.setAnh(rs.getString("ANH"));
                sp_Entity.setMoTa(rs.getString("MOTA"));
                sp_Entity.setDonGia(rs.getFloat("DONGIA"));
                sp_Entity.setSoLuong(rs.getInt("SOLUONG"));
                sp_Entity.setLoai(rs.getString("LOAI"));
                sp_Entity.setSize(rs.getString("SIZE"));
                sp_Entity.setHang(rs.getString("HANG"));
                sp_Entity.setTrangThai(rs.getString("TRANGTHAI"));
                lst.add(sp_Entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
