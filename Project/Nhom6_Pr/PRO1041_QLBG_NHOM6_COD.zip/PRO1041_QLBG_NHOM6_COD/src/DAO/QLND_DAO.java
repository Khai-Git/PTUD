package DAO;

import HELPER.JDBC_HELPER;
import ENTITY.NGUOIDUNG_ENTITY;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class QLND_DAO {

    String INSERT_SQL = "INSERT INTO NguoiDung (MaND, TenND, GIOITINH, MatKhau, SDT, Email, ChucVu, TRANGTHAI) VALUES (?, ? ,? ,?, ?, ?, ?, ?)";
    String UPDATE_SQL = "UPDATE NguoiDung SET TenND=?, GioiTinh=?, MatKhau=?, SDT=?, Email=?, ChucVu=?, TRANGTHAI=? WHERE MaND=?";
    String DELETE_SQL = "UPDATE NguoiDung SET TRANGTHAI= 0 WHERE MaND =?";
    String SELECT_ALL_SQL = "SELECT * FROM NguoiDung";
    String SELECT_BY_ID_SQL = "SELECT * FROM NguoiDung WHERE MaND=?";

    public void Insert(NGUOIDUNG_ENTITY nd_Entity) {
        JDBC_HELPER.executeUpdate(this.INSERT_SQL,
                nd_Entity.getMaND(),
                nd_Entity.getTenND(),
                nd_Entity.isGioiTinh(),
                nd_Entity.getMatKhau(),
                nd_Entity.getSdt(),
                nd_Entity.getEmail(),
                nd_Entity.isChucVu(),
                nd_Entity.isTrangThai()
        );
    }

    public void Update(NGUOIDUNG_ENTITY nd_Entity) {
        JDBC_HELPER.executeUpdate(this.UPDATE_SQL,
                nd_Entity.getTenND(),
                nd_Entity.isGioiTinh(),
                nd_Entity.getMatKhau(),
                nd_Entity.getSdt(),
                nd_Entity.getEmail(),
                nd_Entity.isChucVu(),
                nd_Entity.isTrangThai(),
                nd_Entity.getMaND()
        );
    }

    public void Delete(NGUOIDUNG_ENTITY nd_Entity) {
        JDBC_HELPER.executeUpdate(this.DELETE_SQL, 
                //nd_Entity.isTrangThai(),
                nd_Entity.getMaND()
                
        );
    }

    public List<NGUOIDUNG_ENTITY> selectAll() {
        return selectbySQL(this.SELECT_ALL_SQL);
    }

    public NGUOIDUNG_ENTITY selectByID(String key) {
        List<NGUOIDUNG_ENTITY> lst = this.selectbySQL(this.SELECT_BY_ID_SQL, key);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public void update_mk(NGUOIDUNG_ENTITY entity) {
        String update_mk = "update NGUOIDUNG set MATKHAU = ? where EMAIL=?";
        JDBC_HELPER.executeUpdate(update_mk, entity.getMatKhau(), entity.getEmail());
    }
    
    public NGUOIDUNG_ENTITY select_by_email(String key) {
        String select_by_email = "SELECT * FROM NGUOIDUNG WHERE email = ?";
        List<NGUOIDUNG_ENTITY> list = this.selectbySQL(select_by_email, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public List<NGUOIDUNG_ENTITY> selectbySQL(String sql, Object... args) {
        List<NGUOIDUNG_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                NGUOIDUNG_ENTITY nd_Entity = new NGUOIDUNG_ENTITY();
                nd_Entity.setMaND(rs.getString("MAND"));
                nd_Entity.setTenND(rs.getString("TENND"));
                nd_Entity.setGioiTinh(rs.getBoolean("GioiTinh"));
                nd_Entity.setMatKhau(rs.getString("MatKhau"));
                nd_Entity.setSdt(rs.getString("Sdt"));
                nd_Entity.setEmail(rs.getString("Email"));
                nd_Entity.setChucVu(rs.getBoolean("ChucVu"));
                nd_Entity.setTrangThai(rs.getBoolean("TRANGTHAI"));
                lst.add(nd_Entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
    
    public List<NGUOIDUNG_ENTITY> selectByKeyword(String keyword){
        String sql = "SELECT *FROM NguoiDung WHERE MaND like ?";
        return this.selectbySQL(sql, "%"+keyword+"%");
    }
}
