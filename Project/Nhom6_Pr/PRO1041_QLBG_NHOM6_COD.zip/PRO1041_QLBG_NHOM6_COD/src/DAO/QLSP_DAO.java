package DAO;

import ENTITY.SANPHAM_ENTITY;
import HELPER.JDBC_HELPER;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class QLSP_DAO {

    public List<SANPHAM_ENTITY> SELECT_T1_search(String input) {
        String SELECT_T1_search = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM \n"
            + "            JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP \n"
            + "             WHERE THONGTINSANPHAM.MASP LIKE ?\n"
            + "            OR LOAI LIKE ? \n"
            + "            OR HANG LIKE  ?\n"
            + "            OR SIZE LIKE ? \n"
            + "            OR SANPHAM.TENSP LIKE ?\n"
            + "            AND TRANGTHAI = ? ";
        return this.selectbySQL(SELECT_T1_search, "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%", "Hoạt động");
    }

    public List<SANPHAM_ENTITY> selectHD() {
        String sql = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM\n"
                + "JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP\n"
                + "WHERE TRANGTHAI = N'Hoạt động'";
        return this.selectbySQL(sql);
    }

    public List<SANPHAM_ENTITY> selectKHD() {
        String sql = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM\n"
                + "JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP\n"
                + "WHERE TRANGTHAI = N'Không hoạt động'";
        return this.selectbySQL(sql);
    }

    public void InsertSP(SANPHAM_ENTITY entity) {
        String INSERT_SQL_SP = "INSERT INTO SANPHAM(MASP, TENSP) VALUES (?, ?)";
        JDBC_HELPER.executeUpdate(INSERT_SQL_SP, entity.getMaSP(), entity.getTenSP());
    }

    public void InsertTTSP(SANPHAM_ENTITY entity) {
        String INSERT_SQL_TTSP = "INSERT INTO THONGTINSANPHAM(MASP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        JDBC_HELPER.executeUpdate(INSERT_SQL_TTSP, entity.getMaSP(),
                entity.getAnh(), entity.getMoTa(), entity.getDonGia(),
                entity.getSoLuong(), entity.getLoai(), entity.getSize(),
                entity.getHang(), entity.getTrangThai());
    }

    public void UpdateSP(SANPHAM_ENTITY entity) {
        String UPDATE_SQL_SP = "UPDATE SANPHAM SET TENSP = ? WHERE MASP = ?";
        JDBC_HELPER.executeUpdate(UPDATE_SQL_SP, entity.getTenSP(), entity.getMaSP()
        );
    }

    public void UpdateTTSP(SANPHAM_ENTITY entity) {
        String UPDATE_SQL_TTSP = "UPDATE THONGTINSANPHAM SET ANH = ?, MOTA = ?, DONGIA = ?, SOLUONG = ?, LOAI = ?, SIZE = ?, HANG= ?, TRANGTHAI = ? WHERE MASP = ?";
        JDBC_HELPER.executeUpdate(UPDATE_SQL_TTSP, entity.getAnh(),
                entity.getMoTa(), entity.getDonGia(), entity.getSoLuong(),
                entity.getLoai(), entity.getSize(), entity.getHang(),
                entity.getTrangThai(), entity.getMaSP()
        );
    }

    public void UpdateKHD(SANPHAM_ENTITY entity) {
        String sql = "UPDATE THONGTINSANPHAM SET TRANGTHAI = N'Không hoạt động' WHERE MASP = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getMaSP()
        );
    }

    public void UpdateHD(SANPHAM_ENTITY entity) {
        String sql = "UPDATE THONGTINSANPHAM SET TRANGTHAI = N'Hoạt động' WHERE MASP = ?";
        JDBC_HELPER.executeUpdate(sql, entity.getMaSP()
        );
    }

    public void SoftDelete(SANPHAM_ENTITY entity) {
        String UPDATE_SQL_STATUS = "UPDATE THONGTINSANPHAM SET TRANGTHAI = ? WHERE MASP = ?";
        JDBC_HELPER.executeUpdate(UPDATE_SQL_STATUS, entity.getTrangThai(), entity.getMaSP());
    }

    public List<SANPHAM_ENTITY> selectAll() {
        String SELECT_ALL_SQL = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM\n"
                + "JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP";
        return this.selectbySQL(SELECT_ALL_SQL);
    }

    public SANPHAM_ENTITY selectByID(String key) {
        String SELECT_BY_ID_SQL = "SELECT SANPHAM.MASP, SANPHAM.TENSP, ANH, MOTA, DONGIA, SOLUONG, LOAI, SIZE, HANG, TRANGTHAI FROM THONGTINSANPHAM\n"
                + "JOIN SANPHAM ON THONGTINSANPHAM.MASP = SANPHAM.MASP\n"
                + "WHERE SANPHAM.MASP = ?";
        List<SANPHAM_ENTITY> lst = this.selectbySQL(SELECT_BY_ID_SQL, key);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }

    public List<SANPHAM_ENTITY> selectbyMASP(String key) {
        String selectMASP = "SELECT MASP FROM SANPHAM";
        try {
            List<SANPHAM_ENTITY> lst = new ArrayList<>();
            try (Connection conn = JDBC_HELPER.opConnection(); PreparedStatement pds = conn.prepareStatement(selectMASP)) {
                ResultSet rs = pds.executeQuery();
                while (rs.next()) {
                    lst.add(new SANPHAM_ENTITY(rs.getString("MASP")));
                }
                return lst;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<SANPHAM_ENTITY> selectbySQL(String sql, Object... args) {
        List<SANPHAM_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                SANPHAM_ENTITY entity = new SANPHAM_ENTITY();
                entity.setMaSP(rs.getString("MASP"));
                entity.setTenSP(rs.getString("TENSP"));
                entity.setAnh(rs.getString("ANH"));
                entity.setMoTa(rs.getString("MOTA"));
                entity.setDonGia(rs.getFloat("DONGIA"));
                entity.setSoLuong(rs.getInt("SOLUONG"));
                entity.setLoai(rs.getString("LOAI"));
                entity.setSize(rs.getString("SIZE"));
                entity.setHang(rs.getString("HANG"));
                entity.setTrangThai(rs.getString("TRANGTHAI"));
                lst.add(entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
