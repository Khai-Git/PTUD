package DAO;

import ENTITY.HDCT_ENTITY;
import ENTITY.HD_ENTITY;
import ENTITY.SANPHAM_ENTITY;
import HELPER.JDBC_HELPER;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.print.DocFlavor;

public class QLTH_DAO {

    public List<HD_ENTITY> selectAllHD( String loaihd) {
        String select_all_HD = "SELECT MAHD, TENKH, TENND,THANHTIEN,NGAYTAO,HOADON.TRANGTHAI,HOADON.SDT FROM HOADON "
                + "JOIN NGUOIDUNG ON NGUOIDUNG.MAND=HOADON.MANV "
                + "WHERE HOADON.TRANGTHAI= ?";
        return selectbySQLHD(select_all_HD,loaihd);
    }
    public  HD_ENTITY select_DK(String loai,String mahd){
        String sql= "SELECT MAHD, TENKH, TENND,THANHTIEN,NGAYTAO,HOADON.TRANGTHAI,HOADON.SDT FROM HOADON "
                + "JOIN NGUOIDUNG ON NGUOIDUNG.MAND=HOADON.MANV "
                + "WHERE HOADON.TRANGTHAI= ? and HOADON.MAHD = ?";
        List<HD_ENTITY> lst = this.selectbySQLHD(sql,loai,mahd);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }
    public List<HD_ENTITY> search( String input,String loaihd) {
        String select = "SELECT MAHD, TENKH, TENND,THANHTIEN,NGAYTAO,HOADON.TRANGTHAI,HOADON.SDT FROM HOADON "//đổi
                + "JOIN NGUOIDUNG ON NGUOIDUNG.MAND=HOADON.MANV "
                + "WHERE (HOADON.MAHD LIKE ? OR TENKH LIKE ? OR HOADON.SDT LIKE ?) AND HOADON.TRANGTHAI= ?";
        return selectbySQLHD(select, "%" + input + "%", "%" + input + "%", "%" + input + "%",loaihd);
    }
    String UPDATE_SP="UPDATE THONGTINSANPHAM SET SOLUONG = ? WHERE MASP = ?";
    String INSERT_SQL = "INSERT INTO HDCHITIET(SOLUONG,MAHD,MASP,DONGIA,TRANGTHAI)  VALUES(?,?,?,?,?)";
    String S2 = "UPDATE HDCHITIET SET TRANGTHAI = ?,SOLUONG = ? WHERE MAHD = ? AND MASP = ? AND TRANGTHAI = ?";
     String S1 = "UPDATE HDCHITIET SET TRANGTHAI = ? WHERE MAHD = ? AND TRANGTHAI = ?";
    String SELECT_BY_ID_TENSP = "select MAHD,TENSP,HANG,SIZE,LOAI,HDCHITIET.TRANGTHAI,HDCHITIET.SOLUONG,HDCHITIET.DONGIA,THONGTINSANPHAM.MASP from HDCHITIET\n"
            + "          JOIN THONGTINSANPHAM ON THONGTINSANPHAM.MASP=HDCHITIET.MASP\n"
            + "          JOIN SANPHAM ON SANPHAM.MASP=HDCHITIET.MASP\n"
            + "          where HDCHITIET.TRANGTHAI = ? and HDCHITIET.MAHD= ?  and TENSP = ? ";
    String SELECT_SL_SP=" SELECT SOLUONG FROM  THONGTINSANPHAM WHERE MASP = ?";
    String sql = "SELECT HOADON.MAHD, SANPHAM.TENSP, HDCHITIET.SOLUONG, HDCHITIET.DONGIA ,SANPHAM.MASP FROM HDCHITIET\n"
                    + "JOIN HOADON ON HOADON.MAHD = HDCHITIET.MAHD\n"
                    + "JOIN SANPHAM ON SANPHAM.MASP = HDCHITIET.MASP\n"
                    + "WHERE HDCHITIET.MAHD = ? AND HDCHITIET.TRANGTHAI =?";
    public void Update_HDCT_TRUNGMASP(HDCT_ENTITY sp_Entity,String trangthai) {
        JDBC_HELPER.executeUpdate(S2,sp_Entity.getTrangThai(), sp_Entity.getSoluong(), 
                sp_Entity.getMaHD(), sp_Entity.getMaSP(),trangthai);

    }
    public void Update_TRAHANG(String trangthai,String mahd,String trangthai1) {
        JDBC_HELPER.executeUpdate(S1,trangthai,mahd,trangthai1);

    }
    
    public void Insert(HDCT_ENTITY hd_Entity) {
        JDBC_HELPER.executeUpdate(this.INSERT_SQL, hd_Entity.getSoluong(), hd_Entity.getMaHD(), hd_Entity.getMaSP(),
                 hd_Entity.getDonGia(), "Đã trả hang");
    }
    
    public void UPDATE_SP(String masp, int soluong) {
        JDBC_HELPER.executeUpdate(this.UPDATE_SP, soluong,masp);

    }
    public HDCT_ENTITY selectByID_tensp(String mahd, String tensp) {
        List<HDCT_ENTITY> lst = this.selectbySQLHDCT(this.SELECT_BY_ID_TENSP, "Đã thanh toán", mahd, tensp);
        if (lst.isEmpty()) {
            return null;
        }
        return lst.get(0);
    }
    public List<HDCT_ENTITY> select(String mahd, String tentrangthai) {
        return this.selectbySQLHDCT(sql, mahd,tentrangthai);
    }
    
    public SANPHAM_ENTITY selectByID_SP(String masp) {
        List<SANPHAM_ENTITY> lst = this.selectbySQLSP(this.SELECT_SL_SP,masp);
        if (lst.isEmpty()) {
            return null;
        }
       return lst.get(0);
    }
    ///////////////////////////////////////////////////////////////////////
    public List<HD_ENTITY> selectbySQLHD(String sql, Object... args) {
        List<HD_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                HD_ENTITY entity = new HD_ENTITY();
                entity.setMaHD(rs.getString("MAHD"));
                entity.setTenKH(rs.getString("TENKH"));
                entity.setThanhTien(rs.getFloat("THANHTIEN"));
                entity.setMaNV(rs.getString("TENND"));
                entity.setNgayTao(rs.getDate("NGAYTAO"));
                entity.setTrangThai(rs.getString("TRANGTHAI"));
                entity.setSDT(rs.getString("SDT"));
                lst.add(entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public List<HDCT_ENTITY> selectbySQLHDCT(String sql, Object... args) {
        List<HDCT_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                HDCT_ENTITY entity = new HDCT_ENTITY();
                entity.setMaHD(rs.getString("MAHD"));
                entity.setTenSP(rs.getString("TENSP"));
                entity.setSoluong(rs.getInt("SOLUONG"));
                entity.setDonGia(rs.getFloat("DONGIA"));
                entity.setMaSP(rs.getString("MASP"));
                lst.add(entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }  

    public List<SANPHAM_ENTITY> selectbySQLSP(String sql, Object... args) {
        List<SANPHAM_ENTITY> lst = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                SANPHAM_ENTITY entity = new SANPHAM_ENTITY();
                entity.setSoLuong(rs.getInt("SOLUONG"));
                lst.add(entity);
            }
            rs.getStatement().getConnection().close();
            return lst;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    } 
}
