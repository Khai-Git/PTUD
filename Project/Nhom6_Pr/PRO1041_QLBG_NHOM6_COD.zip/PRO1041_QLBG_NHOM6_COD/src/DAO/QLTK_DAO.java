/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import ENTITY.HD_ENTITY;
import ENTITY.SHD_ENITY;
import ENTITY.SPBR_ENITY;
import ENTITY.STDT_ENITY;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import HELPER.JDBC_HELPER;
import java.util.Date;

/**
 *
 * @author Admin
 */
public class QLTK_DAO {

    public List<HD_ENTITY> selectbySQL(String sql, Object... args) {
        List<HD_ENTITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                HD_ENTITY hd = new HD_ENTITY();
                hd.setMaHD(rs.getString("MAHD"));
                hd.setNgayTao(rs.getDate("NGAYTAO"));
                hd.setTenKH(rs.getString("TENKH"));
                hd.setMaNV(rs.getString("MANV"));
                hd.setThanhTien(rs.getFloat("THANHTIEN"));
                list.add(hd);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public List<SPBR_ENITY> selectSPBR() {
        String sql = "SELECT SANPHAM.MASP, COUNT(*) AS TONGSO FROM HDCHITIET JOIN SANPHAM ON SANPHAM.MASP = HDCHITIET.MASP group by SANPHAM.MASP ";
        return this.hienthiDSSPBR(sql);
    }

    public List<SPBR_ENITY> hienthiDSSPBR(String sql, Object... args) {
        List<SPBR_ENITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                SPBR_ENITY sp = new SPBR_ENITY();
                sp.setMasp(rs.getString("MASP"));
                sp.setSoluong(rs.getInt("TONGSO"));
                list.add(sp);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public List<HD_ENTITY> selectHD() {
        String sql = "select MAHD, MANV , NGAYTAO , TENKH , THANHTIEN from HOADON hd \n" + "join NGUOIDUNG nd on hd.MANV = nd.MAND ";
        return this.selectbySQL(sql);
    }

    public List<SHD_ENITY> hienthi(String sql, Object... args) {
        List<SHD_ENITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                SHD_ENITY hd = new SHD_ENITY();
                hd.setNgayTao(rs.getDate("NGAYTAO"));
                hd.setSohoadon(rs.getInt("so_luong"));
                list.add(hd);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public List<SHD_ENITY> selectSHD() {
        String sql = "select NGAYTAO  , COUNT(*) as so_luong from HOADON group by NGAYTAO";
        return this.hienthi(sql);
    }

    public List<STDT_ENITY> hienthiDoanhthu(String sql, Object... args) {
        List<STDT_ENITY> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_HELPER.executeQuery(sql, args);
            while (rs.next()) {
                STDT_ENITY st = new STDT_ENITY();
                st.setDoanhthu(rs.getFloat("DOANH_THU"));
                st.setNgaytao(rs.getDate("NGAYTAO"));
                list.add(st);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public List<STDT_ENITY> selectDT() {
        String sql = "SELECT NGAYTAO, (SOLUONG*DONGIA) AS DOANH_THU FROM HOADON JOIN HDCHITIET ON HDCHITIET.MAHD = HOADON.MAHD GROUP BY NGAYTAO , HDCHITIET.SOLUONG , HDCHITIET.DONGIA";
        return this.hienthiDoanhthu(sql);
    }

    public List<HD_ENTITY> search(String input) {
        String sql = "select MAHD, MANV , NGAYTAO , TENKH , THANHTIEN from HOADON hd join NGUOIDUNG nd on hd.MANV = nd.MAND where MaHD like ? or MaNV like ? or NGAYTAO like ? or TENKH like ? or NGAYTAO like ?";
        return this.selectbySQL(sql, "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%", "%" + input + "%");
    }

    public List<HD_ENTITY> tongsohoadonHT() {
        String sql = "SELECT MAHD , NGAYTAO , MANV, THANHTIEN , TENKH from HOADON where TRANGTHAI = ?";
        return this.selectbySQL(sql, "Đã thanh toán");
    }

    public List<HD_ENTITY> Tịmkiemtheongay(String input) {
        String sql = "select MAHD, MANV, NGAYTAO, TENKH, THANHTIEN from HOADON where NGAYTAO =?";
        return this.selectbySQL(sql, "%" + input + "%");
    }
}
