package ENTITY;

public class HANG_ENTITY {

    private String hang;
    private String trangThai;

    public HANG_ENTITY() {
    }

    public HANG_ENTITY(String hang, String trangThai) {
        this.hang = hang;
        this.trangThai = trangThai;
    }

    public String getHang() {
        return hang;
    }

    public void setHang(String hang) {
        this.hang = hang;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

}
