package ENTITY;

public class HDCT_ENTITY {

    private String MaHD;
    private String TenSP;
    private Integer soluong;
    private String MaSP;
    private Float DonGia;
    private String TrangThai;
    private String hang;
    private String loai;
    private Float size;

    public HDCT_ENTITY() {
    }

    public HDCT_ENTITY(String MaHD, String TenSP, Integer soluong, String MaSP, Float DonGia, String TrangThai, String hang, String loai, Float size) {
        this.MaHD = MaHD;
        this.TenSP = TenSP;
        this.soluong = soluong;
        this.MaSP = MaSP;
        this.DonGia = DonGia;
        this.TrangThai = TrangThai;
        this.hang = hang;
        this.loai = loai;
        this.size = size;
    }

    public String getMaHD() {
        return MaHD;
    }

    public void setMaHD(String MaHD) {
        this.MaHD = MaHD;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String TenSP) {
        this.TenSP = TenSP;
    }

    public Integer getSoluong() {
        return soluong;
    }

    public void setSoluong(Integer soluong) {
        this.soluong = soluong;
    }

    public String getMaSP() {
        return MaSP;
    }

    public void setMaSP(String MaSP) {
        this.MaSP = MaSP;
    }

    public Float getDonGia() {
        return DonGia;
    }

    public void setDonGia(Float DonGia) {
        this.DonGia = DonGia;
    }

    public String getTrangThai() {
        return TrangThai;
    }

    public void setTrangThai(String TrangThai) {
        this.TrangThai = TrangThai;
    }

    public String getHang() {
        return hang;
    }

    public void setHang(String hang) {
        this.hang = hang;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public Float getSize() {
        return size;
    }

    public void setSize(Float size) {
        this.size = size;
    }

}
