package ENTITY;

import java.util.Date;

public class HD_ENTITY {

    private String MaHD;
    private Date NgayTao;
    private String DiaChi;
    private String SDT;
    private String TrangThai;
    private String TenKH;
    private String MaNV;
    private Float ThanhTien;
    private String Mota;
    private Float Giaship;

    public HD_ENTITY() {
    }

    public HD_ENTITY(String MaHD, Date NgayTao, String DiaChi, String SDT, String TrangThai, String TenKH, String MaNV, Float ThanhTien, String Mota, Float Giaship) {
        this.MaHD = MaHD;
        this.NgayTao = NgayTao;
        this.DiaChi = DiaChi;
        this.SDT = SDT;
        this.TrangThai = TrangThai;
        this.TenKH = TenKH;
        this.MaNV = MaNV;
        this.ThanhTien = ThanhTien;
        this.Mota = Mota;
        this.Giaship = Giaship;
    }

    public String getMaHD() {
        return MaHD;
    }

    public void setMaHD(String MaHD) {
        this.MaHD = MaHD;
    }

    public Date getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(Date NgayTao) {
        this.NgayTao = NgayTao;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String getTrangThai() {
        return TrangThai;
    }

    public void setTrangThai(String TrangThai) {
        this.TrangThai = TrangThai;
    }

    public String getTenKH() {
        return TenKH;
    }

    public void setTenKH(String TenKH) {
        this.TenKH = TenKH;
    }

    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public Float getThanhTien() {
        return ThanhTien;
    }

    public void setThanhTien(Float ThanhTien) {
        this.ThanhTien = ThanhTien;
    }

    public String getMota() {
        return Mota;
    }

    public void setMota(String Mota) {
        this.Mota = Mota;
    }

    public Float getGiaship() {
        return Giaship;
    }

    public void setGiaship(Float Giaship) {
        this.Giaship = Giaship;
    }

    
   

    

   
}