package ENTITY;

public class KHACHHANG_ENTITY {

    private int ID;
    private String SDT;
    private String TenKH;
    private boolean GioiTinh;
    private String Email;
    private String DiaChi;

    public KHACHHANG_ENTITY() {
    }

    public KHACHHANG_ENTITY(int ID, String SDT, String TenKH, boolean GioiTinh, String Email, String DiaChi) {
        this.ID = ID;
        this.SDT = SDT;
        this.TenKH = TenKH;
        this.GioiTinh = GioiTinh;
        this.Email = Email;
        this.DiaChi = DiaChi;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String getTenKH() {
        return TenKH;
    }

    public void setTenKH(String TenKH) {
        this.TenKH = TenKH;
    }

    public boolean isGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(boolean GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getDiaChi() {
        return DiaChi;
    }

    public void setDiaChi(String DiaChi) {
        this.DiaChi = DiaChi;
    }

    @Override
    public String toString() {
        return SDT + " - " + TenKH;
    }
}
