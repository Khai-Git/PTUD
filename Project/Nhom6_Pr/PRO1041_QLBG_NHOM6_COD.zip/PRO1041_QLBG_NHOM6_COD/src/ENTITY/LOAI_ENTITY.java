package ENTITY;

public class LOAI_ENTITY {

    private String loai;
    private String trangThai;

    public LOAI_ENTITY() {
    }

    public LOAI_ENTITY(String loai, String trangThai) {
        this.loai = loai;
        this.trangThai = trangThai;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

}
