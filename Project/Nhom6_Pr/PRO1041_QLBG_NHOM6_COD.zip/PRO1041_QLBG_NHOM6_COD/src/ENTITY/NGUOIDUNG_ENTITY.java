package ENTITY;

public class NGUOIDUNG_ENTITY {
    private String MaND;
    private String TenND;
    private boolean GioiTinh;
    private String MatKhau;    
    private String Sdt;
    private String Email;
    private boolean ChucVu;
    private boolean TrangThai;

    public NGUOIDUNG_ENTITY() {
    }

    public NGUOIDUNG_ENTITY(String MaND, String TenND, boolean GioiTinh, String MatKhau, String Sdt, String Email, boolean ChucVu, boolean TrangThai) {
        this.MaND = MaND;
        this.TenND = TenND;
        this.GioiTinh = GioiTinh;
        this.MatKhau = MatKhau;
        this.Sdt = Sdt;
        this.Email = Email;
        this.ChucVu = ChucVu;
        this.TrangThai = TrangThai;
    }

    public String getMaND() {
        return MaND;
    }

    public void setMaND(String MaND) {
        this.MaND = MaND;
    }

    public String getTenND() {
        return TenND;
    }

    public void setTenND(String TenND) {
        this.TenND = TenND;
    }

    public boolean isGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(boolean GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public String getMatKhau() {
        return MatKhau;
    }

    public void setMatKhau(String MatKhau) {
        this.MatKhau = MatKhau;
    }

    public String getSdt() {
        return Sdt;
    }

    public void setSdt(String Sdt) {
        this.Sdt = Sdt;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public boolean isChucVu() {
        return ChucVu;
    }

    public void setChucVu(boolean ChucVu) {
        this.ChucVu = ChucVu;
    }

    public boolean isTrangThai() {
        return TrangThai;
    }

    public void setTrangThai(boolean TrangThai) {
        this.TrangThai = TrangThai;
    }

    public boolean getTrangThai(){
        return TrangThai=true;
    }      
}
