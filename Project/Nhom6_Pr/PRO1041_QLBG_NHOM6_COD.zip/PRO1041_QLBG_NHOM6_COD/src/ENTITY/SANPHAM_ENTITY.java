package ENTITY;

public class SANPHAM_ENTITY {

    private String maSP;
    private String tenSP;
    private String anh;
    private String moTa;
    private Float donGia;
    private Integer soLuong;
    private String loai;
    private String size;
    private String hang;
    private String trangThai;

    public SANPHAM_ENTITY() {
    }

    public SANPHAM_ENTITY(String maSP, String tenSP, String anh, String moTa, Float donGia, Integer soLuong, String loai, String size, String hang, String trangThai) {
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.anh = anh;
        this.moTa = moTa;
        this.donGia = donGia;
        this.soLuong = soLuong;
        this.loai = loai;
        this.size = size;
        this.hang = hang;
        this.trangThai = trangThai;
    }

    public SANPHAM_ENTITY(String maSP) {
        this.maSP = maSP;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public String getAnh() {
        return anh;
    }

    public void setAnh(String anh) {
        this.anh = anh;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public Float getDonGia() {
        return donGia;
    }

    public void setDonGia(Float donGia) {
        this.donGia = donGia;
    }

    public Integer getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(Integer soLuong) {
        this.soLuong = soLuong;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getHang() {
        return hang;
    }

    public void setHang(String hang) {
        this.hang = hang;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }
}
