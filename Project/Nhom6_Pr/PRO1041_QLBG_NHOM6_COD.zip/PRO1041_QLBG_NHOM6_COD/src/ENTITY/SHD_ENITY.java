/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ENTITY;

import java.util.Date;




/**
 *
 * @author Admin
 */
public class SHD_ENITY {
    private int sohoadon;
    private Date NgayTao;

    public SHD_ENITY() {
    }

    public SHD_ENITY(int sohoadon, Date NgayTao) {
        this.sohoadon = sohoadon;
        this.NgayTao = NgayTao;
    }

    public int getSohoadon() {
        return sohoadon;
    }

    public void setSohoadon(int sohoadon) {
        this.sohoadon = sohoadon;
    }

    public Date getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(Date NgayTao) {
        this.NgayTao = NgayTao;
    }
    
}
