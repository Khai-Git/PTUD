package ENTITY;

public class SIZE_ENTITY {

    private String size;
    private String trangThai;

    public SIZE_ENTITY() {
    }

    public SIZE_ENTITY(String size, String trangThai) {
        this.size = size;
        this.trangThai = trangThai;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

}
