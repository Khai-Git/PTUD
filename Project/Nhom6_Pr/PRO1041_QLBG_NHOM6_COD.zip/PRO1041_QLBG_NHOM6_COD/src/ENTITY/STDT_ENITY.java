/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ENTITY;

import java.util.Date;

/**
 *
 * @author Admin
 */
public class STDT_ENITY {
    private float doanhthu;
    private Date NgayTao;

    public STDT_ENITY() {
    }

    public STDT_ENITY(float doanhthu, Date NgayTao) {
        this.doanhthu = doanhthu;
        this.NgayTao = NgayTao;
    }

    public float getDoanhthu() {
        return doanhthu;
    }

    public void setDoanhthu(float doanhthu) {
        this.doanhthu = doanhthu;
    }

    public Date getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(Date NgayTao) {
        this.NgayTao = NgayTao;
    }

   

    public Date getNgaytao() {
        return NgayTao;
    }

    public void setNgaytao(Date ngaytao) {
        this.NgayTao = ngaytao;
    }

    
    
}
