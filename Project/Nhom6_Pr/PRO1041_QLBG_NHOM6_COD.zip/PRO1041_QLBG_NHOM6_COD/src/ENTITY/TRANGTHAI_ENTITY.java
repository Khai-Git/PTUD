package ENTITY;

public class TRANGTHAI_ENTITY {

    private String tenTT;

    public TRANGTHAI_ENTITY() {
    }

    public TRANGTHAI_ENTITY(String tenTT) {
        this.tenTT = tenTT;
    }

    public String getTenTT() {
        return tenTT;
    }

    public void setTenTT(String tenTT) {
        this.tenTT = tenTT;
    }

    @Override
    public String toString() {
        return tenTT;
    }
    
    
}
