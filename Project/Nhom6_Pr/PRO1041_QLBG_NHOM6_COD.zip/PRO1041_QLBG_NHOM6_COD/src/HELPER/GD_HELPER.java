package HELPER;

import DAO.HDCT_DAO;
import DAO.HD_DAO;
import DAO.QLGD_DAO;
import ENTITY.HDCT_ENTITY;
import ENTITY.HD_ENTITY;
import ENTITY.SANPHAM_ENTITY;
import UI.QLGD_UI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class GD_HELPER extends JPopupMenu {

    private QLGD_UI qlgd = new QLGD_UI();
    private HD_DAO hd_dao = new HD_DAO();
    private HDCT_DAO hdct_dao = new HDCT_DAO();
    private QLGD_DAO qlgd_dao = new QLGD_DAO();
    private List<SANPHAM_ENTITY> sp_list;
    private List<HDCT_ENTITY> hdct_list;
    private List<HD_ENTITY> hd_list;
    private DefaultTableModel model1 = new DefaultTableModel();
    private DefaultTableModel model2 = new DefaultTableModel();
    private DefaultTableModel model3 = new DefaultTableModel();
    private Locale locale = new Locale("vi", "VN");
    private NumberFormat format = NumberFormat.getCurrencyInstance(locale);

    public void poupmenu(JTable table, String masp, String mahd, int sl, JLabel lbl,
            DefaultTableModel model2, DefaultTableModel model1, int slsp) {
        this.model2 = model2;
        this.model1 = model1;
        JMenuItem Sua = new JMenuItem("Sửa");
        JMenuItem Xoa = new JMenuItem("Xóa");
        Sua.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                int soluong = 0;
                String input = JOptionPane.showInputDialog("Nhập số lượng");
                //check là số
                while (input.replaceAll("[*a-zA-Z]", "").trim().length() == 0) {
                    UTILS_HELPER.alert(qlgd, "Nhập phải là số");
                    input = JOptionPane.showInputDialog("Nhập số lượng");
                }

                soluong = Integer.parseInt(input);
                HDCT_ENTITY hdct_en = new HDCT_ENTITY();
                hdct_en.setMaHD(mahd);
                hdct_en.setMaSP(masp);
                hdct_en.setSoluong(soluong);
                hdct_dao.Update_HDCT_TRUNGMASP(hdct_en);

                int soluong_1 = slsp + sl - soluong;
                qlgd_dao.Update(soluong_1, masp);

                hienthijtable1(mahd);
                hienthijtable2();
                tinhthanhtien(lbl, mahd);
            }

        });
        Xoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                if (UTILS_HELPER.confirm(qlgd, "Bạn có muốn xóa không ?")) {
                    xoa(mahd, masp, sl);
                    hienthijtable1(mahd);
                    hienthijtable2();
                    tinhthanhtien(lbl, mahd);
                } else {
                    return;
                }
            }
        });
        add(Sua);
        add(new JSeparator());
        add(Xoa);
    }

    public void poupmenu2(JTable table, String masp, String mahd, int sl, float donggia,
            DefaultTableModel model2, DefaultTableModel model1, JLabel lbl) {
        JMenuItem Them = new JMenuItem("Thêm");
        this.model2 = model2;
        this.model1 = model1;
        Them.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                try {
                    int soluong = 0;
                    String input = JOptionPane.showInputDialog("Nhập số lượng");
                    //check là số
                    while (input.replaceAll("[*a-zA-Z]", "").trim().length() == 0) {
                        UTILS_HELPER.alert(qlgd, "Vui lòng nhập lại số lượng sản phẩm !");
                        input = JOptionPane.showInputDialog("Nhập số lượng");
                    }

                    soluong = Integer.parseInt(input);
                    HDCT_ENTITY zz = hdct_dao.selectByID_masp(mahd, masp);
                    if (hdct_dao.selectByID_masp(mahd, masp) != null) {
                        //lấy số lượng cũ của HĐCT
                        int s_l_cu = zz.getSoluong();
                        HDCT_ENTITY hdct_en = new HDCT_ENTITY();
                        hdct_en.setMaHD(mahd);
                        hdct_en.setMaSP(masp);
                        hdct_en.setSoluong(soluong + s_l_cu);
                        hdct_dao.Update_HDCT_TRUNGMASP(hdct_en);
                        //tính lại số lượng trong kho
                        int soluong_1 = sl - soluong;
                        qlgd_dao.Update(soluong_1, masp);
                    } else {
                        HDCT_ENTITY hdct_en = new HDCT_ENTITY();

                        hdct_en.setMaHD(mahd);
                        hdct_en.setDonGia(donggia);
                        hdct_en.setMaSP(masp);
                        hdct_en.setSoluong(soluong);
                        hdct_dao.Insert(hdct_en);
                        // tính lại số lượng trong kho
                        int soluong_1 = sl - soluong;
                        qlgd_dao.Update(soluong_1, masp);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
                hienthijtable2();
                hienthijtable1(mahd);
                tinhthanhtien(lbl, mahd);
            }
        });
        add(Them);
    }
    
    
    public void poupmenu3(String mahd,JLabel lbl1,JLabel lbl2,DefaultTableModel model) {
        JMenuItem Hoanthanh = new JMenuItem("Hoàn thành");
        JMenuItem Huy = new JMenuItem("Hủy");
        JMenuItem Giaohang = new JMenuItem("Giao hàng");
        JMenuItem Sua = new JMenuItem("Sửa thông tin");
        this.model3=model;
        Giaohang.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                hd_dao.Update( mahd,"Đang giao hàng");
                loadTblHDCT("Chờ xử lý");
                load(lbl2);
                load1(lbl1);
            }
        });
        Huy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                hd_dao.Update(mahd, "Không hoạt động");
                HuyHD_TRAHANG(mahd);
                loadTblHDCT("Chờ xử lý");
                hienthijtable2();
                load(lbl2);
                load1(lbl1);
                
            }
        });
        
  
        add(Hoanthanh);
        add(Huy);
    }
    public void poupmenu4(String mahd,JComboBox cbbloadHD,DefaultTableModel model,JLabel lbl1,JLabel lbl2) {
        JMenuItem Giaohang = new JMenuItem("Giao hàng");
        JMenuItem Hoanthanh = new JMenuItem("Hoàn thành");
        JMenuItem Huy = new JMenuItem("Hủy");        
        this.model3 = model;
        
        
        Hoanthanh.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                hd_dao.Update(mahd, "Đã thanh toán");
                loadTblHDCT("Đang giao hàng");
                load(lbl2);
                load1(lbl1);
                
            }
        });
        Huy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                
                hd_dao.Update(mahd, "Không hoạt động");
                HuyHD_TRAHANG(mahd);
                loadTblHDCT("Đang giao hàng");
                hienthijtable2();
                load(lbl2);
                load1(lbl1);
                
            }
        });
        
//        add(Giaohang);
        add(Hoanthanh);
        add(Huy);
    }
    
    private void HuyHD_TRAHANG(String maHD) {
//        String maHD = this.txtMaHD_BH.getText();
        this.hdct_list = hdct_dao.selectAll(maHD);
        for (HDCT_ENTITY sp_Entity : hdct_list) {
           String masp  =sp_Entity.getMaSP();
           int sl_hdct=sp_Entity.getSoluong();
           SANPHAM_ENTITY sp = this.qlgd_dao.selectByID(masp);
           int sl_sp=sp.getSoLuong();
           int soluong=sl_hdct+sl_sp;
           this.qlgd_dao.Update(soluong, masp);
        }
    }
    
    private void load(JLabel lbl) {
    this.hd_list = this.hd_dao.selectAll_LOAI("Đang giao hàng");
    int so1=hd_list.size();
    lbl.setText(String.valueOf(so1));
    }
    private void load1(JLabel lbl) {
    this.hd_list = this.hd_dao.selectAll_LOAI("Chờ xử lý");
    int so1=hd_list.size();
    lbl.setText(String.valueOf(so1));
    }
    
    private void hienthijtable2() {
        this.model2.setRowCount(0);
        try {
            this.sp_list = qlgd_dao.selectAll();
            for (SANPHAM_ENTITY sp_Entity : sp_list) {
                this.model2.addRow(new Object[]{
                    sp_Entity.getMaSP(),
                    sp_Entity.getTenSP(),
                    sp_Entity.getLoai(),
                    sp_Entity.getSize(),
                    sp_Entity.getHang(),
                    format.format(sp_Entity.getDonGia()),
                    sp_Entity.getSoLuong()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void hienthijtable1(String mahd) {
        this.model1.setRowCount(0);
        try {
            this.hdct_list = hdct_dao.selectAll(mahd);
            for (HDCT_ENTITY sp_Entity : hdct_list) {
                this.model1.addRow(new Object[]{
                    sp_Entity.getTenSP(),
                    sp_Entity.getSoluong(),
                    sp_Entity.getLoai(),
                    sp_Entity.getHang(),
                    sp_Entity.getSize(),
                    format.format(sp_Entity.getDonGia()),
                    0
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }
    private void loadTblHDCT(String loai) {
        this.model3.setRowCount(0);
        try {
            this.hd_list = this.hd_dao.selectAll_LOAI(loai);
            for (HD_ENTITY sp_Entity : this.hd_list) {
                this.model3.addRow(new Object[]{
                    sp_Entity.getMaHD(),
                    sp_Entity.getTenKH(),
                    sp_Entity.getMaNV(),
                    this.format.format(sp_Entity.getThanhTien())
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }
    private void tinhthanhtien(JLabel lbl, String mahd) {
        this.hdct_list = this.hdct_dao.selectAll(mahd);
        float thanhtien = 0;
        int soluong;
        float dongia;
        for (HDCT_ENTITY sp_Entity : hdct_list) {
            soluong = sp_Entity.getSoluong();
            dongia = sp_Entity.getDonGia();
            thanhtien += soluong * dongia;
        }
        format.setRoundingMode(RoundingMode.HALF_UP);
        lbl.setText(format.format(thanhtien));
    }

    private void xoa(String mahd, String masp, int sl) {
        this.hdct_dao.XOA_HDCT(mahd, masp);
        SANPHAM_ENTITY sp = this.qlgd_dao.selectByID(masp);
        int soluong = sl + sp.getSoLuong();
        this.qlgd_dao.Update(soluong, masp);
    }
}
