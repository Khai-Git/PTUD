package HELPER;

import ENTITY.NGUOIDUNG_ENTITY;
import java.awt.Component;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class UTILS_HELPER {

    public static SimpleDateFormat DATE_FORMARTER = new SimpleDateFormat("dd/MM/yyyy");

    public static Date now() {
        return new Date();
    }

    public static String toString(Date date, String... pattern) {
        if (pattern.length > 0) {
            DATE_FORMARTER.applyPattern(pattern[0]);
        }
        if (date == null) {
            date = UTILS_HELPER.now();
        }
        return DATE_FORMARTER.format(date);
    }
    
    public static void alert(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Hệ thống quản lý cửa hàng giày", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirm(Component parent, String message) {
        int result = JOptionPane.showConfirmDialog(parent, message, "Hệ thống quản lý cửa hàng giày", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }

    public static final Image APP_ICON;
    public static final ImageIcon APP_ICON_1;

    static {
        String file = "/ICON/Shoes2.png";
        APP_ICON = new ImageIcon(UTILS_HELPER.class.getResource(file)).getImage();
        APP_ICON_1 = new ImageIcon(UTILS_HELPER.class.getResource(file));
    }

    public static boolean saveLogo(File file) {
        File dir = new File("img");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File newFile = new File(dir, file.getName());
        try {
            Path source = Paths.get(file.getAbsolutePath());
            Path destination = Paths.get(newFile.getAbsolutePath());
            Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    public static ImageIcon readLogo(String fileName) {
        File path = new File("img", fileName);
        return new ImageIcon(new ImageIcon(path.getAbsolutePath()).getImage().getScaledInstance(180, 180, Image.SCALE_DEFAULT));
    }
    
    public static NGUOIDUNG_ENTITY user = null;

    public static void clear() {
        UTILS_HELPER.user = null;
    }

    public static boolean isLogin() {
        return UTILS_HELPER.user != null;
    }

    public static boolean isManager() {
        return UTILS_HELPER.isLogin() && user.isTrangThai();
    }
}
