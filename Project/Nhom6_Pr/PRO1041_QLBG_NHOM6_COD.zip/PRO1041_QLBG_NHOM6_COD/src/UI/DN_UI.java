package UI;

import DAO.QLND_DAO;
import ENTITY.NGUOIDUNG_ENTITY;
import HELPER.UTILS_HELPER;

public class DN_UI extends javax.swing.JDialog {

    public DN_UI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.initComponents();
        this.init();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtten = new javax.swing.JTextField();
        txtmk = new javax.swing.JPasswordField();
        btndn = new javax.swing.JButton();
        btnthoat = new javax.swing.JButton();
        lblquen = new javax.swing.JLabel();
        cbohienmk = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("ĐĂNG NHẬP");

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel1.setForeground(new java.awt.Color(204, 204, 204));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Tên đăng nhập: ");

        jLabel2.setText("Mật khẩu:");

        txtten.setText("HAINH");

        txtmk.setText("123456");

        btndn.setBackground(new java.awt.Color(102, 255, 102));
        btndn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Accept.png"))); // NOI18N
        btndn.setText("Đăng nhập");
        btndn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndnActionPerformed(evt);
            }
        });

        btnthoat.setBackground(new java.awt.Color(255, 153, 153));
        btnthoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/No.png"))); // NOI18N
        btnthoat.setText("Thoát");
        btnthoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnthoatActionPerformed(evt);
            }
        });

        lblquen.setBackground(new java.awt.Color(51, 153, 255));
        lblquen.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblquen.setText("Quên mật khẩu");
        lblquen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblquenMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblquenMousePressed(evt);
            }
        });

        cbohienmk.setText("Hiện mật khẩu");
        cbohienmk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbohienmkActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtmk, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtten)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 103, Short.MAX_VALUE)
                        .addComponent(btndn)
                        .addGap(18, 18, 18)
                        .addComponent(btnthoat))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(cbohienmk)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblquen, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel1, jLabel2});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btndn, btnthoat});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cbohienmk, lblquen});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(txtten, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtmk, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblquen)
                    .addComponent(cbohienmk))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btndn, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnthoat))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtmk, txtten});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btndn, btnthoat});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jLabel1, jLabel2});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cbohienmk, lblquen});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btndnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndnActionPerformed
        try {
            this.dangnhap();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btndnActionPerformed

    private void cbohienmkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbohienmkActionPerformed
        try {
            this.hienmk();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_cbohienmkActionPerformed

    private void btnthoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnthoatActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có muốn thoát không?")) {
            this.dispose();
        }
    }//GEN-LAST:event_btnthoatActionPerformed

    private void lblquenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquenMouseClicked
        this.quenmk();
    }//GEN-LAST:event_lblquenMouseClicked

    private void lblquenMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquenMousePressed

    }//GEN-LAST:event_lblquenMousePressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btndn;
    private javax.swing.JButton btnthoat;
    private javax.swing.JCheckBox cbohienmk;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblquen;
    private javax.swing.JPasswordField txtmk;
    private javax.swing.JTextField txtten;
    // End of variables declaration//GEN-END:variables

    private void init() {
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setIconImage(UTILS_HELPER.APP_ICON);
        this.setTitle("Hệ thống quản lý cửa hàng giày");
    }

    private void dangnhap() {
        try {
            QLND_DAO nd_dao = new QLND_DAO();
            String maND = this.txtten.getText();
            String matKhau = new String(txtmk.getPassword());
            NGUOIDUNG_ENTITY nd = nd_dao.selectByID(maND);
            if (nd == null) {
                UTILS_HELPER.alert(this, "Sai tên đăng nhập");
                return;
            } else if (!matKhau.equalsIgnoreCase(nd.getMatKhau())) {
                UTILS_HELPER.alert(this, "Sai mật khẩu");
                return;
            } else {
                if (!nd.isTrangThai()) {
                    UTILS_HELPER.alert(this, "Nhân viên " + txtten.getText() + " không còn hoạt động");
                    return;
                }
                UTILS_HELPER.alert(this, "Đăng nhập thành công");
                UTILS_HELPER.user = nd;
                this.dispose();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void hienmk() {
        if (this.cbohienmk.isSelected()) {
            this.txtmk.setEchoChar((char) 0);
        } else {
            this.txtmk.setEchoChar('*');
        }
    }

    private void quenmk() {
        this.dispose();
        new QMK_UI().setVisible(true);
    }
}
