package UI;

import DAO.HDCT_DAO;
import DAO.HD_DAO;
import DAO.QLGD_DAO;
import DAO.KH_DAO;
import ENTITY.HDCT_ENTITY;
import ENTITY.HD_ENTITY;
import ENTITY.KHACHHANG_ENTITY;
import ENTITY.SANPHAM_ENTITY;
import HELPER.GD_HELPER;
import HELPER.UTILS_HELPER;
import java.awt.Color;
import java.awt.print.PrinterException;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class QLGD_UI extends javax.swing.JInternalFrame {

    private int index;
    private HD_DAO hd_Dao;
    private QLGD_DAO gd_Dao;
    private KH_DAO kh_Dao;
    private HDCT_DAO hdct_Dao;
    private List<HD_ENTITY> hd_Lst;
    private List<SANPHAM_ENTITY> Lst;
    private List<HDCT_ENTITY> hdct_Lst;
    private DefaultTableModel hdct_Model;
    private DefaultTableModel ttsp_Model;
    private DefaultTableModel tthd_Model;
    private Locale locale = new Locale("vi", "VN");
    private NumberFormat format = NumberFormat.getCurrencyInstance(locale);

    public QLGD_UI() {
        this.initComponents();
        this.hd_Dao = new HD_DAO();
        this.gd_Dao = new QLGD_DAO();
        this.kh_Dao = new KH_DAO();
        this.hdct_Dao = new HDCT_DAO();
        this.hdct_Model = (DefaultTableModel) this.tblHDCT_BH.getModel();
        this.ttsp_Model = (DefaultTableModel) this.tblTTSP.getModel();
        this.tthd_Model = (DefaultTableModel) this.tblHDC_BH.getModel();
        this.inIt();
    }

    private boolean checknull() {
        if (txtTienKhachTra_BH.getText().isEmpty()) {
            UTILS_HELPER.alert(this, "Vui lòng điền tiền khách trả");
            this.lblTienKhachTra_BH.setBackground(Color.yellow);
            if (this.lblTienDu_BH.getText().equals("Còn thiếu:")) {
                this.lblTienKhachTra_BH.setBackground(Color.red);
            }
            return false;
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btgCachThuc = new javax.swing.ButtonGroup();
        btgTrangThai = new javax.swing.ButtonGroup();
        lblQLGD = new javax.swing.JLabel();
        pnlTTHD_BH = new javax.swing.JPanel();
        lblMaHD_BH = new javax.swing.JLabel();
        txtMaHD_BH = new javax.swing.JTextField();
        lblThanhTien_BH = new javax.swing.JLabel();
        ThanhTien_BH = new javax.swing.JLabel();
        lblTienKhachTra_BH = new javax.swing.JLabel();
        txtTienKhachTra_BH = new javax.swing.JTextField();
        lblTienDu_BH = new javax.swing.JLabel();
        TienDu_BH = new javax.swing.JLabel();
        btnThanhToan_BH = new javax.swing.JButton();
        btnHuyDon_BH = new javax.swing.JButton();
        btnTaoDon_BH = new javax.swing.JButton();
        pnlTblTTHD = new javax.swing.JPanel();
        txtTimKiemTTHD_BH = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblHDC_BH = new javax.swing.JTable();
        dtctimkiemHD = new com.toedter.calendar.JDateChooser();
        lblDonDangGiao_BH = new javax.swing.JLabel();
        SDCXL_BH = new javax.swing.JLabel();
        lblSoDonChoXuLy_BH = new javax.swing.JLabel();
        SDDG_BH = new javax.swing.JLabel();
        cbbloadHD = new javax.swing.JComboBox<>();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtPrint_BH = new javax.swing.JTextArea();
        lblCachThuc_BH = new javax.swing.JLabel();
        rdoGiaoHang_BH = new javax.swing.JRadioButton();
        rdoTaiQuay_BH = new javax.swing.JRadioButton();
        lblSDT_BH = new javax.swing.JLabel();
        lblNgayTao_BH = new javax.swing.JLabel();
        dtcNgayTao_BH = new com.toedter.calendar.JDateChooser();
        lblTenKH_BH = new javax.swing.JLabel();
        txtTenKH_BH = new javax.swing.JTextField();
        txttimkiemkh = new javax.swing.JTextField();
        pnlTTSP_BH = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblTTSP = new javax.swing.JTable();
        lblTimKiem_BH = new javax.swing.JLabel();
        txtTimKiem_BH = new javax.swing.JTextField();
        pnlHDCT_BH = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblHDCT_BH = new javax.swing.JTable();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
                formInternalFrameClosed(evt);
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
            }
        });

        lblQLGD.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblQLGD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblQLGD.setText("QUẢN LÝ GIAO DỊCH");

        pnlTTHD_BH.setBackground(new java.awt.Color(204, 204, 255));
        pnlTTHD_BH.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin hóa đơn"));

        lblMaHD_BH.setText("Mã HĐ:");

        txtMaHD_BH.setEditable(false);

        lblThanhTien_BH.setText("Thành tiền:");

        ThanhTien_BH.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        ThanhTien_BH.setForeground(new java.awt.Color(255, 51, 51));
        ThanhTien_BH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ThanhTien_BH.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        lblTienKhachTra_BH.setText("Tiền khách trả:");

        txtTienKhachTra_BH.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTienKhachTra_BHFocusLost(evt);
            }
        });
        txtTienKhachTra_BH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTienKhachTra_BHActionPerformed(evt);
            }
        });

        lblTienDu_BH.setText("Tiền dư:");

        TienDu_BH.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        TienDu_BH.setForeground(new java.awt.Color(255, 51, 51));
        TienDu_BH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        TienDu_BH.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        btnThanhToan_BH.setBackground(new java.awt.Color(102, 255, 102));
        btnThanhToan_BH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Dollar.png"))); // NOI18N
        btnThanhToan_BH.setText("Thanh toán");
        btnThanhToan_BH.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnThanhToan_BH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThanhToan_BHActionPerformed(evt);
            }
        });

        btnHuyDon_BH.setBackground(new java.awt.Color(255, 153, 153));
        btnHuyDon_BH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/No.png"))); // NOI18N
        btnHuyDon_BH.setText("Hủy đơn");
        btnHuyDon_BH.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHuyDon_BH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyDon_BHActionPerformed(evt);
            }
        });

        btnTaoDon_BH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Create.png"))); // NOI18N
        btnTaoDon_BH.setText("Tạo đơn");
        btnTaoDon_BH.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTaoDon_BH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTaoDon_BHActionPerformed(evt);
            }
        });

        pnlTblTTHD.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        tblHDC_BH.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã HĐ", "Tên KH", "Tên NV", "Thành tiền"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblHDC_BH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHDC_BHMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblHDC_BH);

        lblDonDangGiao_BH.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblDonDangGiao_BH.setForeground(new java.awt.Color(255, 0, 51));
        lblDonDangGiao_BH.setText("Số đơn đang giao:");

        SDCXL_BH.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        SDCXL_BH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SDCXL_BH.setText("0");

        lblSoDonChoXuLy_BH.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblSoDonChoXuLy_BH.setForeground(new java.awt.Color(255, 0, 51));
        lblSoDonChoXuLy_BH.setText("Số đơn chờ xử lý:");

        SDDG_BH.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        SDDG_BH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SDDG_BH.setText("0");

        cbbloadHD.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Đang giao hàng", "Chờ xử lý", "Hoàn thành" }));
        cbbloadHD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbbloadHDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlTblTTHDLayout = new javax.swing.GroupLayout(pnlTblTTHD);
        pnlTblTTHD.setLayout(pnlTblTTHDLayout);
        pnlTblTTHDLayout.setHorizontalGroup(
            pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTblTTHDLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 859, Short.MAX_VALUE)
                    .addGroup(pnlTblTTHDLayout.createSequentialGroup()
                        .addComponent(dtctimkiemHD, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTimKiemTTHD_BH))
                    .addGroup(pnlTblTTHDLayout.createSequentialGroup()
                        .addGroup(pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlTblTTHDLayout.createSequentialGroup()
                                .addComponent(lblDonDangGiao_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SDDG_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlTblTTHDLayout.createSequentialGroup()
                                .addComponent(lblSoDonChoXuLy_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(SDCXL_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbbloadHD, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pnlTblTTHDLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {SDCXL_BH, SDDG_BH, lblDonDangGiao_BH, lblSoDonChoXuLy_BH});

        pnlTblTTHDLayout.setVerticalGroup(
            pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTblTTHDLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(dtctimkiemHD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtTimKiemTTHD_BH))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlTblTTHDLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDonDangGiao_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SDDG_BH)))
                    .addGroup(pnlTblTTHDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblSoDonChoXuLy_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(SDCXL_BH)
                        .addComponent(cbbloadHD, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pnlTblTTHDLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {SDCXL_BH, SDDG_BH, lblDonDangGiao_BH, lblSoDonChoXuLy_BH});

        txtPrint_BH.setEditable(false);
        txtPrint_BH.setColumns(20);
        txtPrint_BH.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        txtPrint_BH.setRows(5);
        txtPrint_BH.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "HÓA ĐƠN", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 1, 13))); // NOI18N
        txtPrint_BH.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane5.setViewportView(txtPrint_BH);

        lblCachThuc_BH.setText("Hình thức:");

        btgCachThuc.add(rdoGiaoHang_BH);
        rdoGiaoHang_BH.setText("Giao hàng");
        rdoGiaoHang_BH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        rdoGiaoHang_BH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdoGiaoHang_BHActionPerformed(evt);
            }
        });

        btgCachThuc.add(rdoTaiQuay_BH);
        rdoTaiQuay_BH.setSelected(true);
        rdoTaiQuay_BH.setText("Tại quầy");
        rdoTaiQuay_BH.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblSDT_BH.setText("SĐT:");

        lblNgayTao_BH.setText("Ngày tạo:");

        lblTenKH_BH.setText("Tên KH:");

        txttimkiemkh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txttimkiemkhActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlTTHD_BHLayout = new javax.swing.GroupLayout(pnlTTHD_BH);
        pnlTTHD_BH.setLayout(pnlTTHD_BHLayout);
        pnlTTHD_BHLayout.setHorizontalGroup(
            pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTTHD_BHLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlTblTTHD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTTHD_BHLayout.createSequentialGroup()
                        .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlTTHD_BHLayout.createSequentialGroup()
                                .addComponent(lblCachThuc_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rdoGiaoHang_BH)
                                .addGap(18, 18, 18)
                                .addComponent(rdoTaiQuay_BH)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTTHD_BHLayout.createSequentialGroup()
                                .addComponent(lblMaHD_BH)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtMaHD_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblSDT_BH)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txttimkiemkh))
                            .addGroup(pnlTTHD_BHLayout.createSequentialGroup()
                                .addComponent(lblThanhTien_BH)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ThanhTien_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblTienKhachTra_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtTienKhachTra_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTTHD_BHLayout.createSequentialGroup()
                                .addComponent(lblTienDu_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(TienDu_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(pnlTTHD_BHLayout.createSequentialGroup()
                                .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblTenKH_BH)
                                    .addComponent(lblNgayTao_BH))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(dtcNgayTao_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtTenKH_BH))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTTHD_BHLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnTaoDon_BH)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnThanhToan_BH)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnHuyDon_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pnlTTHD_BHLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblCachThuc_BH, lblMaHD_BH, lblNgayTao_BH, lblTenKH_BH, lblThanhTien_BH, lblTienDu_BH, lblTienKhachTra_BH});

        pnlTTHD_BHLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnHuyDon_BH, btnTaoDon_BH, btnThanhToan_BH});

        pnlTTHD_BHLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {ThanhTien_BH, txtTienKhachTra_BH});

        pnlTTHD_BHLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {rdoGiaoHang_BH, rdoTaiQuay_BH});

        pnlTTHD_BHLayout.setVerticalGroup(
            pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTTHD_BHLayout.createSequentialGroup()
                .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlTTHD_BHLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblMaHD_BH)
                                .addComponent(txtMaHD_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblSDT_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txttimkiemkh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblCachThuc_BH)
                            .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(rdoGiaoHang_BH)
                                .addComponent(rdoTaiQuay_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(11, 11, 11)
                        .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNgayTao_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dtcNgayTao_BH, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTenKH_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTenKH_BH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ThanhTien_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblThanhTien_BH)
                            .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblTienKhachTra_BH)
                                .addComponent(txtTienKhachTra_BH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblTienDu_BH)
                            .addComponent(TienDu_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlTTHD_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThanhToan_BH)
                    .addComponent(btnHuyDon_BH, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTaoDon_BH))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnlTblTTHD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlTTHD_BHLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {ThanhTien_BH, TienDu_BH, lblCachThuc_BH, lblMaHD_BH, lblNgayTao_BH, lblSDT_BH, lblTenKH_BH, lblThanhTien_BH, lblTienDu_BH, lblTienKhachTra_BH, txtTienKhachTra_BH, txttimkiemkh});

        pnlTTHD_BHLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnHuyDon_BH, btnTaoDon_BH, btnThanhToan_BH});

        pnlTTHD_BHLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {dtcNgayTao_BH, rdoGiaoHang_BH, rdoTaiQuay_BH, txtMaHD_BH, txtTenKH_BH});

        pnlTTSP_BH.setBackground(new java.awt.Color(204, 204, 255));
        pnlTTSP_BH.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin sản phẩm"));

        tblTTSP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã SP", "Tên SP", "Loại", "Hãng", "Size", "Đơn giá", "Số lượng"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblTTSP.setRowHeight(25);
        tblTTSP.setRowMargin(5);
        tblTTSP.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblTTSP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTTSPMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblTTSP);

        lblTimKiem_BH.setText("Tìm kiếm:");

        txtTimKiem_BH.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiem_BHKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout pnlTTSP_BHLayout = new javax.swing.GroupLayout(pnlTTSP_BH);
        pnlTTSP_BH.setLayout(pnlTTSP_BHLayout);
        pnlTTSP_BHLayout.setHorizontalGroup(
            pnlTTSP_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTTSP_BHLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTTSP_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(pnlTTSP_BHLayout.createSequentialGroup()
                        .addComponent(lblTimKiem_BH)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiem_BH)))
                .addContainerGap())
        );
        pnlTTSP_BHLayout.setVerticalGroup(
            pnlTTSP_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTTSP_BHLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlTTSP_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTimKiem_BH)
                    .addComponent(txtTimKiem_BH, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 326, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnlTTSP_BHLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblTimKiem_BH, txtTimKiem_BH});

        pnlHDCT_BH.setBackground(new java.awt.Color(204, 204, 255));
        pnlHDCT_BH.setBorder(javax.swing.BorderFactory.createTitledBorder("Hóa đơn chi tiết"));

        tblHDCT_BH.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tên SP", "Số lượng", "Loại", "Hãng", "Size", "Đơn giá"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblHDCT_BH.setRowHeight(25);
        tblHDCT_BH.setRowMargin(5);
        tblHDCT_BH.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblHDCT_BH.setShowVerticalLines(false);
        tblHDCT_BH.setUpdateSelectionOnSort(false);
        tblHDCT_BH.setVerifyInputWhenFocusTarget(false);
        tblHDCT_BH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblHDCT_BHMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblHDCT_BH);
        tblHDCT_BH.getAccessibleContext().setAccessibleName("");
        tblHDCT_BH.getAccessibleContext().setAccessibleDescription("");

        javax.swing.GroupLayout pnlHDCT_BHLayout = new javax.swing.GroupLayout(pnlHDCT_BH);
        pnlHDCT_BH.setLayout(pnlHDCT_BHLayout);
        pnlHDCT_BHLayout.setHorizontalGroup(
            pnlHDCT_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHDCT_BHLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        pnlHDCT_BHLayout.setVerticalGroup(
            pnlHDCT_BHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHDCT_BHLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblQLGD, javax.swing.GroupLayout.PREFERRED_SIZE, 1381, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 37, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(pnlTTSP_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pnlHDCT_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlTTHD_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQLGD, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlHDCT_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pnlTTSP_BH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(pnlTTHD_BH, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblHDCT_BHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHDCT_BHMouseClicked
        try {
            this.index = this.tblHDCT_BH.getSelectedRow();
            String maHD = this.txtMaHD_BH.getText();
            int sl = (int) this.tblHDCT_BH.getValueAt(this.index, 1);
            String tensp = (String) this.tblHDCT_BH.getValueAt(this.index, 0);
            HDCT_ENTITY hdct_entity = this.hdct_Dao.selectByID_tensp(maHD, tensp);
            String masp = hdct_entity.getMaSP();
            SANPHAM_ENTITY sp_entity = this.gd_Dao.selectByID(masp);
            int slsp = sp_entity.getSoLuong();
            GD_HELPER po = new GD_HELPER();
            if (SwingUtilities.isRightMouseButton(evt)) {
                po.poupmenu(this.tblHDCT_BH, masp, maHD, sl, this.ThanhTien_BH, this.ttsp_Model, this.hdct_Model, slsp);
                po.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_tblHDCT_BHMouseClicked

    private void tblTTSPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTTSPMouseClicked
        try {
            GD_HELPER po = new GD_HELPER();
            this.index = this.tblTTSP.getSelectedRow();
            String masp = (String) this.tblTTSP.getValueAt(this.index, 0);
            String maHD = this.txtMaHD_BH.getText();
            int sl = (int) this.tblTTSP.getValueAt(this.index, 6);
            String dongias = (String) this.tblTTSP.getValueAt(this.index, 5);
            String dongiar = dongias.replaceAll("[. đ]", "");
            float dongia = Float.parseFloat(dongiar);
            if (SwingUtilities.isRightMouseButton(evt)) {
                po.poupmenu2(this.tblTTSP, masp, maHD, sl, dongia, this.ttsp_Model, this.hdct_Model, this.ThanhTien_BH);
                po.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_tblTTSPMouseClicked

    private void btnTaoDon_BHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTaoDon_BHActionPerformed
        if (this.txtMaHD_BH.getText().trim().length() == 0) {
            this.clear();
            this.loadTblTTHD("Chờ xử lý");
            this.loadDCXL();
            this.loadSDDG();
            this.autoMaHD();
            return;
        }
        if (this.txtMaHD_BH.getText().trim().length() > 0) {
            this.HDchoxuly();
            this.clear();
            this.loadTblTTHD("Chờ xử lý");
            this.loadDCXL();
            this.loadSDDG();
            this.autoMaHD();
            return;
        }
    }//GEN-LAST:event_btnTaoDon_BHActionPerformed

    private void btnThanhToan_BHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThanhToan_BHActionPerformed
        String tenKH = this.txtTenKH_BH.getText();
        String maHD = this.txtMaHD_BH.getText();
        String thanhTien = this.ThanhTien_BH.getText();
        String SDT = this.txttimkiemkh.getText();

        if (this.rdoTaiQuay_BH.isSelected() == true) {
            if (checknull() == true) {
                if (UTILS_HELPER.confirm(this, "Bạn có muốn in hóa đơn không?")) {
                    try {
                        this.inHD();
                        this.txtPrint_BH.print();
                    } catch (PrinterException ex) {
                        Logger.getLogger(QLGD_UI.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (ParseException ex) {
                        Logger.getLogger(QLGD_UI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (UTILS_HELPER.confirm(this, "Bạn có muốn thanh toán không?")) {
                    this.thanhToan(tenKH);
                    this.clear();

                }
            }
        } else if (this.rdoGiaoHang_BH.isSelected() == true) {
            new TTKH_UI(tenKH, thanhTien, maHD, SDT, this.tthd_Model,
                    this.hdct_Model, this.txtMaHD_BH, this.txttimkiemkh, this.txtTenKH_BH, this.ThanhTien_BH, this.txtPrint_BH,
                    this.SDDG_BH, this.SDCXL_BH).setVisible(true);
        }
    }//GEN-LAST:event_btnThanhToan_BHActionPerformed

    private void txtTienKhachTra_BHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTienKhachTra_BHActionPerformed
        this.tinhTienDu();
    }//GEN-LAST:event_txtTienKhachTra_BHActionPerformed

    private void btnHuyDon_BHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyDon_BHActionPerformed
        String tenKH = this.txtTenKH_BH.getText();
        try {
            this.HuyHD(tenKH);
            this.HuyHD_TRAHANG();
            this.loadTblTTHD("Chờ xử lý");
            this.loadTblSP();
            this.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnHuyDon_BHActionPerformed

    private void tblHDC_BHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblHDC_BHMouseClicked
//       Đang giao hàng, Chờ xử lý, Hoàn thành
//        this.loa
        this.index = this.tblHDC_BH.getSelectedRow();
        String maHD = (String) this.tblHDC_BH.getValueAt(this.index, 0);
        this.loadTblHDCT(maHD);
        GD_HELPER po = new GD_HELPER();
        if (this.cbbloadHD.getSelectedItem().equals("Đang giao hàng")) {
            if (SwingUtilities.isRightMouseButton(evt)) {
                po.poupmenu4(maHD, this.cbbloadHD, this.tthd_Model, this.SDCXL_BH, this.SDDG_BH);
                po.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        } else if (this.cbbloadHD.getSelectedItem().equals("Chờ xử lý")) {
            if (SwingUtilities.isRightMouseButton(evt)) {
                po.poupmenu3(maHD, this.SDCXL_BH, this.SDDG_BH, this.tthd_Model);
                po.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        }
    }//GEN-LAST:event_tblHDC_BHMouseClicked

    private void txtTimKiem_BHKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiem_BHKeyReleased
        this.ttsp_Model.setRowCount(0);
        try {
            this.Lst = this.gd_Dao.SELECT_T1_search(this.txtTimKiem_BH.getText());
            for (SANPHAM_ENTITY sp_Entity : this.Lst) {
                this.ttsp_Model.addRow(new Object[]{
                    sp_Entity.getMaSP(),
                    sp_Entity.getTenSP(),
                    sp_Entity.getLoai(),
                    sp_Entity.getSize(),
                    sp_Entity.getHang(),
                    this.format.format(sp_Entity.getDonGia()),
                    sp_Entity.getSoLuong()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }//GEN-LAST:event_txtTimKiem_BHKeyReleased

    private void txtTienKhachTra_BHFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTienKhachTra_BHFocusLost

    }//GEN-LAST:event_txtTienKhachTra_BHFocusLost

    private void rdoGiaoHang_BHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdoGiaoHang_BHActionPerformed

    }//GEN-LAST:event_rdoGiaoHang_BHActionPerformed

    private void txttimkiemkhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txttimkiemkhActionPerformed
        String input = this.txttimkiemkh.getText();
        KHACHHANG_ENTITY kh_list = this.kh_Dao.select_cbb_kh(input);
        if (kh_list != null) {
            this.txtTenKH_BH.setText(kh_list.getTenKH());
            this.txttimkiemkh.setText(kh_list.getSDT());
        } else {
            UTILS_HELPER.alert(this, "Khách hàng không tồn tại");
            this.txtTenKH_BH.setText(kh_list.getTenKH());
        }
    }//GEN-LAST:event_txttimkiemkhActionPerformed

    private void cbbloadHDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbbloadHDActionPerformed
        if (this.cbbloadHD.getSelectedItem().equals("Đang giao hàng")) {
            loadTblTTHD("Đang giao hàng");

        } else if (this.cbbloadHD.getSelectedItem().equals("Chờ xử lý")) {
            loadTblTTHD("Chờ xử lý");
        } else if (this.cbbloadHD.getSelectedItem().equals("Hoàn thành")) {
            loadTblTTHD("Đã thanh toán");
        }
    }//GEN-LAST:event_cbbloadHDActionPerformed

    private void formInternalFrameClosed(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_formInternalFrameClosed
        if (this.txtMaHD_BH.getText().length() > 0) {
            this.HDchoxuly();
        }
    }//GEN-LAST:event_formInternalFrameClosed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel SDCXL_BH;
    private javax.swing.JLabel SDDG_BH;
    private javax.swing.JLabel ThanhTien_BH;
    private javax.swing.JLabel TienDu_BH;
    private javax.swing.ButtonGroup btgCachThuc;
    private javax.swing.ButtonGroup btgTrangThai;
    private javax.swing.JButton btnHuyDon_BH;
    private javax.swing.JButton btnTaoDon_BH;
    private javax.swing.JButton btnThanhToan_BH;
    private javax.swing.JComboBox<String> cbbloadHD;
    private com.toedter.calendar.JDateChooser dtcNgayTao_BH;
    private com.toedter.calendar.JDateChooser dtctimkiemHD;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel lblCachThuc_BH;
    private javax.swing.JLabel lblDonDangGiao_BH;
    private javax.swing.JLabel lblMaHD_BH;
    private javax.swing.JLabel lblNgayTao_BH;
    private javax.swing.JLabel lblQLGD;
    private javax.swing.JLabel lblSDT_BH;
    private javax.swing.JLabel lblSoDonChoXuLy_BH;
    private javax.swing.JLabel lblTenKH_BH;
    private javax.swing.JLabel lblThanhTien_BH;
    private javax.swing.JLabel lblTienDu_BH;
    private javax.swing.JLabel lblTienKhachTra_BH;
    private javax.swing.JLabel lblTimKiem_BH;
    private javax.swing.JPanel pnlHDCT_BH;
    private javax.swing.JPanel pnlTTHD_BH;
    private javax.swing.JPanel pnlTTSP_BH;
    private javax.swing.JPanel pnlTblTTHD;
    private javax.swing.JRadioButton rdoGiaoHang_BH;
    private javax.swing.JRadioButton rdoTaiQuay_BH;
    private javax.swing.JTable tblHDCT_BH;
    private javax.swing.JTable tblHDC_BH;
    private javax.swing.JTable tblTTSP;
    private javax.swing.JTextField txtMaHD_BH;
    private javax.swing.JTextArea txtPrint_BH;
    private javax.swing.JTextField txtTenKH_BH;
    private javax.swing.JTextField txtTienKhachTra_BH;
    private javax.swing.JTextField txtTimKiemTTHD_BH;
    private javax.swing.JTextField txtTimKiem_BH;
    private javax.swing.JTextField txttimkiemkh;
    // End of variables declaration//GEN-END:variables

    private void inIt() {
        this.loadTblSP();
        this.loadTblTTHD("Đang giao hàng");
        this.setFrameIcon(UTILS_HELPER.APP_ICON_1);
        this.loadDCXL();
        this.loadSDDG();
        this.setTitle("Hệ thống quản lý cửa hàng giày");
        this.dtcNgayTao_BH.setDate(new Date());
    }

    private void loadTblSP() {
        this.ttsp_Model.setRowCount(0);
        try {
            this.Lst = this.gd_Dao.selectAll();
            for (SANPHAM_ENTITY sp_Entity : this.Lst) {
                this.ttsp_Model.addRow(new Object[]{
                    sp_Entity.getMaSP(),
                    sp_Entity.getTenSP(),
                    sp_Entity.getLoai(),
                    sp_Entity.getSize(),
                    sp_Entity.getHang(),
                    this.format.format(sp_Entity.getDonGia()),
                    sp_Entity.getSoLuong()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void loadTblTTHD(String Loai) {
        this.tthd_Model.setRowCount(0);
        try {
            this.hd_Lst = this.hd_Dao.selectAll_LOAI(Loai);
            for (HD_ENTITY sp_Entity : this.hd_Lst) {
                this.tthd_Model.addRow(new Object[]{
                    sp_Entity.getMaHD(),
                    sp_Entity.getTenKH(),
                    sp_Entity.getMaNV(),
                    this.format.format(sp_Entity.getThanhTien())
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void loadDCXL() {
        this.hd_Lst = this.hd_Dao.selectAll_LOAI("Chờ xử lý");
        int so = hd_Lst.size();
        this.SDCXL_BH.setText(String.valueOf(so));
    }

    private void loadSDDG() {
        this.hd_Lst = this.hd_Dao.selectAll_LOAI("Đang giao hàng");
        int so = this.hd_Lst.size();
        this.SDDG_BH.setText(String.valueOf(so));
    }

    private void autoMaHD() {
        this.hd_Lst = this.hd_Dao.selectAll();
        int so = hd_Lst.size();
        int so1 = so + 1;
        String AUTOMAHD = "HD0".concat(String.valueOf(so1));
        HD_ENTITY hd_entity = new HD_ENTITY();
        hd_entity.setMaHD(AUTOMAHD);
        hd_entity.setNgayTao(new Date());
        try {
            if (this.txtMaHD_BH.getText().trim().equals("")) {
                this.txtMaHD_BH.setText(AUTOMAHD);
                this.hd_Dao.Insert(hd_entity);
            } else {
                UTILS_HELPER.alert(this, "Bạn cần hoàn thành trước khi tạo hóa đơn mới");
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Tạo hóa đơn thất bại");
        }
    }

    private void thanhToan(String tenKH) {
        String maHD = this.txtMaHD_BH.getText();
        String SDT = this.txttimkiemkh.getText();
        String ttstring = this.ThanhTien_BH.getText().replaceAll("[. đ]", "");
        float thanhtien = Float.parseFloat(ttstring);
        String diaChi = "";
        HD_ENTITY hd_entity = new HD_ENTITY();
        hd_entity.setNgayTao(UTILS_HELPER.now());
        hd_entity.setMaHD(maHD);
        hd_entity.setThanhTien(thanhtien);
        hd_entity.setMaNV(UTILS_HELPER.user.getMaND());
        hd_entity.setTenKH(tenKH);
        hd_entity.setDiaChi(diaChi);
        hd_entity.setTrangThai("Đã thanh toán");
        hd_entity.setMota("");
        hd_entity.setGiaship(null);
        hd_entity.setSDT(SDT);
        this.hd_Dao.Update_HD_HOANTHANH(hd_entity);
    }

    private void clear() {
        this.txtPrint_BH.setText("");
        this.ThanhTien_BH.setText("0 đ");
        this.txtMaHD_BH.setText("");
        this.txtTienKhachTra_BH.setText("");
        this.TienDu_BH.setText("0 đ");
        this.hdct_Model.setRowCount(0);
        this.lblTienDu_BH.setText("Tiền dư: ");
        this.txttimkiemkh.setText("");
        this.txtTenKH_BH.setText("");
    }

    private void tinhTienDu() {
        try {
            String tktss = this.txtTienKhachTra_BH.getText().replaceAll("[. đ]", "");
            float tienkhachtra = Float.parseFloat(tktss);
            float tiendu = 0;
            String ttstring = this.ThanhTien_BH.getText().replaceAll("[. đ]", "");
            float thanhtien = Float.parseFloat(ttstring);
            tiendu = tienkhachtra - thanhtien;
            if (tiendu < 0) {
                tiendu = tiendu * -1;
                this.lblTienDu_BH.setText("Còn thiếu:");
                this.format = NumberFormat.getCurrencyInstance(locale);
                format.setRoundingMode(RoundingMode.HALF_UP);
                this.TienDu_BH.setText(format.format(tiendu));
            } else {
                this.format = NumberFormat.getCurrencyInstance(locale);
                this.format.setRoundingMode(RoundingMode.HALF_UP);
                this.TienDu_BH.setText(this.format.format(tiendu));
                this.lblTienDu_BH.setText("Tiền dư:");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void HuyHD(String tenKH) {
        String mota = JOptionPane.showInputDialog(this, "Lý do:");

        String maHD = this.txtMaHD_BH.getText();
        String ttstring = this.ThanhTien_BH.getText().replaceAll("[. đ]", "");
        String SDT = this.txttimkiemkh.getText();
        float thanhtien = Float.parseFloat(ttstring);
        String diachi = "";
        if (HELPER.UTILS_HELPER.confirm(this, "Bạn có muốn hủy không?")) {
            HD_ENTITY hd_entity = new HD_ENTITY();
            hd_entity.setNgayTao(new Date());
            hd_entity.setMaHD(maHD);
            hd_entity.setThanhTien(thanhtien);
            hd_entity.setMaNV("HAINH");
            hd_entity.setTenKH(tenKH);
            hd_entity.setDiaChi(diachi);
            hd_entity.setTrangThai("Không hoạt động");
            hd_entity.setMota(mota);
            hd_entity.setGiaship(null);
            hd_entity.setSDT(SDT);
            this.hd_Dao.Update_HD_HOANTHANH(hd_entity);
        }
    }

    private void HuyHD_TRAHANG() {
        String maHD = this.txtMaHD_BH.getText();
        this.hdct_Lst = hdct_Dao.selectAll(maHD);
        for (HDCT_ENTITY sp_Entity : hdct_Lst) {
            String masp = sp_Entity.getMaSP();
            int sl_hdct = sp_Entity.getSoluong();
            SANPHAM_ENTITY sp = this.gd_Dao.selectByID(masp);
            int sl_sp = sp.getSoLuong();
            int soluong = sl_hdct + sl_sp;
            this.gd_Dao.Update(soluong, masp);
        }
    }

    private void inHD() throws ParseException {
        String tenKH = this.txtTenKH_BH.getText();
        String thanhTien = this.ThanhTien_BH.getText();
        HD_ENTITY hd_entity = new HD_ENTITY();
        DateFormat output = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        DateFormat input = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date nth = input.parse(java.time.LocalDate.now().toString());
        String outputDate = output.format(nth);
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "Hóa đơn thanh toán" + "\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "*******************" + "\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "Tên khách hàng: " + tenKH + "\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "Thành tiền: " + thanhTien + "\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "Thời gian thanh toán: " + outputDate +"\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "Địa chỉ giao hàng: " + hd_entity.getDiaChi() + "(Nếu có)" + "\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "*******************" + "\n");
        this.txtPrint_BH.setText(this.txtPrint_BH.getText() + "Hẹn gặp lại quý khách vào lần tới" + "\n");
    }

    private void HDchoxuly() {
        String mahd = this.txtMaHD_BH.getText();
        String tenkh = this.txtTenKH_BH.getText();
        String sdt = this.txttimkiemkh.getText();
        String thanhtien = this.ThanhTien_BH.getText();
        String ttstring = thanhtien.replaceAll("[. đ]", "");
        float thanhtien1 = Float.parseFloat(ttstring);
        HD_ENTITY hd_entity = new HD_ENTITY();
        hd_entity.setNgayTao(new Date());
        hd_entity.setMaHD(mahd);
        hd_entity.setThanhTien(thanhtien1);
        hd_entity.setMaNV("HAINH");
        hd_entity.setTenKH(tenkh);
        hd_entity.setDiaChi("");
        hd_entity.setTrangThai("Chờ xử lý");
        hd_entity.setMota("");
        hd_entity.setGiaship(null);
        hd_entity.setSDT(sdt);
        this.hd_Dao.Update_HD_HOANTHANH(hd_entity);
    }    

    private void loadTblHDCT(String maHD) {
        this.hdct_Model.setRowCount(0);
        try {
            this.hdct_Lst = this.hdct_Dao.selectAll(maHD);
            for (HDCT_ENTITY sp_Entity : this.hdct_Lst) {
                this.hdct_Model.addRow(new Object[]{
                    sp_Entity.getTenSP(),
                    sp_Entity.getSoluong(),
                    sp_Entity.getLoai(),
                    sp_Entity.getHang(),
                    sp_Entity.getSize(),
                    this.format.format(sp_Entity.getDonGia()),
                    0
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

}
