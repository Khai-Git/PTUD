package UI;

import DAO.QLND_DAO;
import ENTITY.NGUOIDUNG_ENTITY;
import HELPER.UTILS_HELPER;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class QLND_UI extends javax.swing.JInternalFrame {

    private QLND_DAO dao = new QLND_DAO();
    private int row = -1;

    public QLND_UI() {
        this.initComponents();
        this.init();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblNhanVien = new javax.swing.JTable();
        lblHoTen = new javax.swing.JLabel();
        txtHoTen = new javax.swing.JTextField();
        lblMatKhau = new javax.swing.JLabel();
        lblXacNhanMK = new javax.swing.JLabel();
        lblSDT = new javax.swing.JLabel();
        txtSDT = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        lblChucVu = new javax.swing.JLabel();
        rdoNhanVien = new javax.swing.JRadioButton();
        rdoChuCuaHang = new javax.swing.JRadioButton();
        lblTrangThai = new javax.swing.JLabel();
        rdoHoatDong = new javax.swing.JRadioButton();
        rdoKhongHoatDong = new javax.swing.JRadioButton();
        lblMaNV = new javax.swing.JLabel();
        txtMaNV = new javax.swing.JTextField();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnTim = new javax.swing.JButton();
        btnCuoi = new javax.swing.JButton();
        btnTiep = new javax.swing.JButton();
        btnTruoc = new javax.swing.JButton();
        btnDau = new javax.swing.JButton();
        lblQLND = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        rdoNam = new javax.swing.JRadioButton();
        rdoNu = new javax.swing.JRadioButton();
        txtMatKhau = new javax.swing.JPasswordField();
        txtXacNhanMK = new javax.swing.JPasswordField();
        btnMoi = new javax.swing.JButton();
        txtEmail = new javax.swing.JTextField();
        btnXoa = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);
        setTitle("Quản Lý Người Dùng");

        tblNhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã NV", "Họ tên", "Giới Tính", "Mật khẩu", "SĐT", "Email", "Chức vụ", "Trạng Thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, true, true, true, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhanVienMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblNhanVien);

        lblHoTen.setText("Họ tên:");

        lblMatKhau.setText("Mật khẩu:");

        lblXacNhanMK.setText("Xác nhận mật khẩu:");

        lblSDT.setText("SĐT:");

        lblEmail.setText("Email:");

        lblChucVu.setText("Chức vụ:");

        buttonGroup1.add(rdoNhanVien);
        rdoNhanVien.setText("Nhân viên");

        buttonGroup1.add(rdoChuCuaHang);
        rdoChuCuaHang.setText("Chủ cửa hàng");

        lblTrangThai.setText("Trạng thái:");

        buttonGroup2.add(rdoHoatDong);
        rdoHoatDong.setText("Hoạt động");

        buttonGroup2.add(rdoKhongHoatDong);
        rdoKhongHoatDong.setText("Không hoạt động");

        lblMaNV.setText("Mã NV:");

        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Save.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Edit.png"))); // NOI18N
        btnSua.setText("Sửa");
        btnSua.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnTim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Search.png"))); // NOI18N
        btnTim.setText("Tìm Kiếm");
        btnTim.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimActionPerformed(evt);
            }
        });

        btnCuoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Last_Btn.png"))); // NOI18N
        btnCuoi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCuoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuoiActionPerformed(evt);
            }
        });

        btnTiep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Next_Btn.png"))); // NOI18N
        btnTiep.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTiep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTiepActionPerformed(evt);
            }
        });

        btnTruoc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Prev_Btn.png"))); // NOI18N
        btnTruoc.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTruoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTruocActionPerformed(evt);
            }
        });

        btnDau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/First_Btn.png"))); // NOI18N
        btnDau.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDauActionPerformed(evt);
            }
        });

        lblQLND.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblQLND.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblQLND.setText("QUẢN LÝ NGƯỜI DÙNG");

        jLabel1.setText("Giới tính:");

        buttonGroup3.add(rdoNam);
        rdoNam.setText("Nam");

        buttonGroup3.add(rdoNu);
        rdoNu.setText("Nữ");

        btnMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Add.png"))); // NOI18N
        btnMoi.setText("Mới");
        btnMoi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Delete.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblQLND, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtTimKiem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnTim, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblMatKhau)
                                    .addComponent(lblHoTen)
                                    .addComponent(lblSDT))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtMatKhau, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 396, Short.MAX_VALUE)
                                    .addComponent(txtSDT, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtHoTen)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(lblChucVu))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(rdoNam)
                                        .addGap(18, 18, 18)
                                        .addComponent(rdoNu))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(rdoNhanVien)
                                        .addGap(18, 18, 18)
                                        .addComponent(rdoChuCuaHang)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblXacNhanMK)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtXacNhanMK, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblMaNV)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(lblEmail)
                                .addGap(12, 12, 12)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblTrangThai)
                                .addGap(18, 18, 18)
                                .addComponent(rdoHoatDong)
                                .addGap(18, 18, 18)
                                .addComponent(rdoKhongHoatDong))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnThem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSua)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnMoi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnXoa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnDau)
                        .addGap(18, 18, 18)
                        .addComponent(btnTruoc)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTiep)
                        .addGap(18, 18, 18)
                        .addComponent(btnCuoi)))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblChucVu, lblEmail, lblHoTen, lblMaNV, lblMatKhau, lblSDT, lblTrangThai, lblXacNhanMK});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {rdoChuCuaHang, rdoHoatDong, rdoKhongHoatDong, rdoNam, rdoNhanVien, rdoNu});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnCuoi, btnDau, btnMoi, btnSua, btnThem, btnTiep, btnTruoc});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtEmail, txtHoTen, txtMaNV, txtMatKhau, txtSDT, txtXacNhanMK});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblQLND, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTim)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblHoTen)
                            .addComponent(txtHoTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMatKhau)
                            .addComponent(txtMatKhau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblSDT)
                            .addComponent(txtSDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(26, 26, 26)
                                .addComponent(lblChucVu))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(rdoNam)
                                    .addComponent(rdoNu))
                                .addGap(13, 13, 13)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(rdoNhanVien)
                                    .addComponent(rdoChuCuaHang)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblMaNV)
                            .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblXacNhanMK)
                            .addComponent(txtXacNhanMK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblEmail)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTrangThai)
                            .addComponent(rdoKhongHoatDong)
                            .addComponent(rdoHoatDong))))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnThem)
                        .addComponent(btnSua)
                        .addComponent(btnMoi)
                        .addComponent(btnXoa))
                    .addComponent(btnDau, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTruoc, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTiep, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCuoi, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 408, Short.MAX_VALUE)
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {rdoChuCuaHang, rdoHoatDong, rdoKhongHoatDong, rdoNam, rdoNhanVien, rdoNu});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtEmail, txtHoTen, txtMaNV, txtMatKhau, txtSDT, txtXacNhanMK});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTim, txtTimKiem});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhanVienMouseClicked
        if (evt.getClickCount() == 2) {
            this.row = tblNhanVien.getSelectedRow();
            if (this.row >= 0) {
                this.edit();
            }
        }
    }//GEN-LAST:event_tblNhanVienMouseClicked

    private void btnTimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimActionPerformed
        this.timKiem();
    }//GEN-LAST:event_btnTimActionPerformed

    private void btnDauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDauActionPerformed
        this.first();
    }//GEN-LAST:event_btnDauActionPerformed

    private void btnTruocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTruocActionPerformed
        this.prev();
    }//GEN-LAST:event_btnTruocActionPerformed

    private void btnTiepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTiepActionPerformed
        this.next();
    }//GEN-LAST:event_btnTiepActionPerformed

    private void btnCuoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuoiActionPerformed
        this.last();
    }//GEN-LAST:event_btnCuoiActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có muốn thêm nhân viên không?")) {
            this.insert();
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        this.update();
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        this.clearForm();
    }//GEN-LAST:event_btnMoiActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có muốn xóa nhân viên không?")) {
            this.delete();
        }
    }//GEN-LAST:event_btnXoaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCuoi;
    private javax.swing.JButton btnDau;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTiep;
    private javax.swing.JButton btnTim;
    private javax.swing.JButton btnTruoc;
    private javax.swing.JButton btnXoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblChucVu;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblHoTen;
    private javax.swing.JLabel lblMaNV;
    private javax.swing.JLabel lblMatKhau;
    private javax.swing.JLabel lblQLND;
    private javax.swing.JLabel lblSDT;
    private javax.swing.JLabel lblTrangThai;
    private javax.swing.JLabel lblXacNhanMK;
    private javax.swing.JRadioButton rdoChuCuaHang;
    private javax.swing.JRadioButton rdoHoatDong;
    private javax.swing.JRadioButton rdoKhongHoatDong;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdoNhanVien;
    private javax.swing.JRadioButton rdoNu;
    private javax.swing.JTable tblNhanVien;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtHoTen;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JPasswordField txtMatKhau;
    private javax.swing.JTextField txtSDT;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JPasswordField txtXacNhanMK;
    // End of variables declaration//GEN-END:variables

    void timKiem() {
        this.fillTable();
        this.clearForm();
        this.row = -1;
        updateStatus();
        this.setTitle("Hệ thống quản lý cửa hàng giày");
    }

    void init() {
        this.fillTable();
        this.row = -1;
        this.updateStatus();
    }

    private void fillTable() {
        DefaultTableModel dtm = (DefaultTableModel) this.tblNhanVien.getModel();
        dtm.setRowCount(0);
        try {
            String keyword = this.txtTimKiem.getText();
            List<NGUOIDUNG_ENTITY> list = dao.selectByKeyword(keyword);
            for (NGUOIDUNG_ENTITY nd : list) {
                Object[] row = {
                    nd.getMaND(),
                    nd.getTenND(),
                    nd.isGioiTinh() ? "Nam" : "Nữ",
                    "******",
                    nd.getSdt(),
                    nd.getEmail(),
                    nd.isChucVu() ? "Chủ Cửa Hàng" : "Nhân Viên",
                    nd.isTrangThai() ? "Hoạt động" : "Không hoạt động"
                };
                dtm.addRow(row);
            }
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void updateStatus() {
        boolean edit = (this.row >= 0);
        boolean first = (this.row == 0);
        boolean last = (this.row == tblNhanVien.getRowCount() - 1);
        txtMaNV.setEditable(!edit);
        btnThem.setEnabled(!edit);
        btnSua.setEnabled(edit);
        btnDau.setEnabled(edit && !first);
        btnTruoc.setEnabled(edit && !first);
        btnTiep.setEnabled(edit && !last);
        btnCuoi.setEnabled(edit && !last);
    }

    private void edit() {
        try {
            String mand = (String) tblNhanVien.getValueAt(this.row, 0);
            NGUOIDUNG_ENTITY nd = dao.selectByID(mand);
            this.setForm(nd);
            this.updateStatus();
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void setForm(NGUOIDUNG_ENTITY nd) {
        txtMaNV.setText(nd.getMaND());
        txtHoTen.setText(nd.getTenND());
        if (nd.isGioiTinh()) {
            rdoNam.setSelected(true);
        } else {
            rdoNu.setSelected(true);
        }

        txtMatKhau.setText(nd.getMatKhau());
        txtXacNhanMK.setText(nd.getMatKhau());
        txtSDT.setText(nd.getSdt());
        txtEmail.setText(nd.getEmail());
        if (nd.isChucVu()) {
            rdoChuCuaHang.setSelected(true);
        } else {
            rdoNhanVien.setSelected(true);
        }
        if (nd.isTrangThai()) {
            rdoHoatDong.setSelected(true);
        } else {
            rdoKhongHoatDong.setSelected(true);
        }

    }

    NGUOIDUNG_ENTITY getForm() {
        NGUOIDUNG_ENTITY nd = new NGUOIDUNG_ENTITY();
        nd.setMaND(txtMaNV.getText());
        nd.setTenND(txtHoTen.getText());
        nd.setGioiTinh(rdoNam.isSelected() ? true : false);
        nd.setMatKhau(txtMatKhau.getText());
        nd.setSdt(txtSDT.getText());
        nd.setEmail(txtEmail.getText());
        nd.setChucVu(rdoChuCuaHang.isSelected() ? true : false);
        nd.setTrangThai(rdoHoatDong.isSelected() ? true : false);
        return nd;
    }

    void clearForm() {
        NGUOIDUNG_ENTITY nd = new NGUOIDUNG_ENTITY();
        this.setForm(nd);
        this.row = -1;
        this.updateStatus();
    }

    void first() {
        this.row = 0;
        this.edit();
    }

    void prev() {
        if (this.row > 0) {
            this.row--;
            this.edit();
        }
    }

    void next() {
        if (this.row < tblNhanVien.getRowCount() - 1) {
            this.row++;
            this.edit();
        }
    }

    void last() {
        this.row = tblNhanVien.getRowCount() - 1;
        this.edit();
    }

    void insert() {
        if (check() == true) {
            NGUOIDUNG_ENTITY nd = getForm();
            String mk2 = new String(txtXacNhanMK.getText());
            if (!mk2.equals(nd.getMatKhau())) {
                UTILS_HELPER.alert(this, "Xác nhận mk ko đúng");
            } else {
                try {
                    dao.Insert(nd);
                    this.fillTable();
                    UTILS_HELPER.alert(this, "Thêm mới thành công");
                } catch (Exception e) {
                    UTILS_HELPER.alert(this, "Thêm mới thất bại");
                }
            }
        }
    }

    void update() {
        NGUOIDUNG_ENTITY nd = getForm();
        String mk2 = new String(txtXacNhanMK.getText());
        if (!mk2.equals(nd.getMatKhau())) {
            UTILS_HELPER.alert(this, "Xác nhận mk ko đúng");
        } else {
            try {
                dao.Update(nd);
                this.fillTable();
                UTILS_HELPER.alert(this, "Sửa thành công");
            } catch (Exception e) {
                UTILS_HELPER.alert(this, "Sửa thất bại");
            }
        }
    }

    private void delete() {
        NGUOIDUNG_ENTITY nd = getForm();
        try {
            dao.Delete(nd);
            this.fillTable();
            UTILS_HELPER.alert(this, "Xoá thành công");
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Xoá thất bại");
        }
    }

    private boolean check() {
        String mand = txtMaNV.getText();
        String hoten = txtHoTen.getText();
        String mk = txtMatKhau.getText();
        String sdt = txtSDT.getText();
        String email = txtEmail.getText();
        String checkemail
                = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        String checksdt = "[0-9]{10}";
        if (mand.length() == 0 || hoten.length() == 0 || mk.length() == 0 || sdt.length() == 0 || email.length() == 0) {
            JOptionPane.showMessageDialog(this, "Bạn chưa nhập đầy đủ các ô");
            return false;
        }
        if (!email.matches(checkemail)) {
            JOptionPane.showMessageDialog(this, "Email ko đúng định dạng");
            return false;
        }
        if (!sdt.matches(checksdt)) {
            JOptionPane.showMessageDialog(this, "SĐT phải đủ 10 số");
            return false;
        }
        return true;
    }
}
