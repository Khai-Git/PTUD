package UI;

import DAO.QLSP_DAO;
import DAO.LSHT_DAO;
import java.util.List;
import ENTITY.HANG_ENTITY;
import ENTITY.LOAI_ENTITY;
import ENTITY.SIZE_ENTITY;
import HELPER.UTILS_HELPER;
import ENTITY.SANPHAM_ENTITY;
import ENTITY.TRANGTHAI_ENTITY;
import java.awt.Image;
import java.io.File;
import java.text.NumberFormat;
import java.util.Locale;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.table.DefaultTableModel;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

public class QLSP_UI extends javax.swing.JInternalFrame {

    private int Index;
    private QLSP_DAO Dao;
    private String HinhAnh;
    private DefaultTableModel TblModel;
    private List<SANPHAM_ENTITY> sp_Lst;
    private Locale locale = new Locale("vi", "VN");
    private NumberFormat format = NumberFormat.getCurrencyInstance(locale);

    public QLSP_UI() {
        this.initComponents();
        this.Dao = new QLSP_DAO();
        this.TblModel = (DefaultTableModel) this.tblSanPham.getModel();
        this.inIt();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        lblQLSP = new javax.swing.JLabel();
        pnlTimKiem = new javax.swing.JPanel();
        txtTimKiem = new javax.swing.JTextField();
        lblAnh = new javax.swing.JLabel();
        lblTenSP = new javax.swing.JLabel();
        lblGia = new javax.swing.JLabel();
        lblSoLuong = new javax.swing.JLabel();
        lblLoai = new javax.swing.JLabel();
        lblHang = new javax.swing.JLabel();
        lblMoTa = new javax.swing.JLabel();
        txtTenSP = new javax.swing.JTextField();
        txtGia = new javax.swing.JTextField();
        txtSoLuong = new javax.swing.JTextField();
        lblMaSP = new javax.swing.JLabel();
        txtMaSP = new javax.swing.JTextField();
        cbxLoai = new javax.swing.JComboBox<>();
        cbxHang = new javax.swing.JComboBox<>();
        lblSize = new javax.swing.JLabel();
        cbxSize = new javax.swing.JComboBox<>();
        srcMoTa = new javax.swing.JScrollPane();
        txtMoTa = new javax.swing.JTextArea();
        btnThemHang = new javax.swing.JButton();
        btnLuu = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnMoi = new javax.swing.JButton();
        btnDau = new javax.swing.JButton();
        btnTruoc = new javax.swing.JButton();
        btnTiep = new javax.swing.JButton();
        btnCuoi = new javax.swing.JButton();
        btnThemLoai = new javax.swing.JButton();
        btnThemSize = new javax.swing.JButton();
        lblTrangThai = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        srcQLSP = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        btnKHD = new javax.swing.JButton();
        btnHD = new javax.swing.JButton();
        cbxTrangThai = new javax.swing.JComboBox<>();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        lblQLSP.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblQLSP.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblQLSP.setText("QUẢN LÝ SẢN PHẨM");

        pnlTimKiem.setBorder(javax.swing.BorderFactory.createTitledBorder("Tìm kiếm"));

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout pnlTimKiemLayout = new javax.swing.GroupLayout(pnlTimKiem);
        pnlTimKiem.setLayout(pnlTimKiemLayout);
        pnlTimKiemLayout.setHorizontalGroup(
            pnlTimKiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTimKiemLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTimKiem)
                .addContainerGap())
        );
        pnlTimKiemLayout.setVerticalGroup(
            pnlTimKiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTimKiemLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblAnh.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAnh.setText("Nhấn để thêm ảnh");
        lblAnh.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblAnh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAnhMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblAnhMouseReleased(evt);
            }
        });

        lblTenSP.setText("Tên SP:");

        lblGia.setText("Giá:");

        lblSoLuong.setText("Số lượng:");

        lblLoai.setText("Loại:");

        lblHang.setText("Hãng:");

        lblMoTa.setText("Mô tả:");

        txtTenSP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTenSPKeyReleased(evt);
            }
        });

        lblMaSP.setText("Mã SP:");

        txtMaSP.setEditable(false);

        cbxLoai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbxLoaiMouseClicked(evt);
            }
        });
        cbxLoai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxLoaiActionPerformed(evt);
            }
        });

        cbxHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbxHangMouseClicked(evt);
            }
        });
        cbxHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxHangActionPerformed(evt);
            }
        });

        lblSize.setText("Size:");

        cbxSize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbxSizeMouseClicked(evt);
            }
        });

        txtMoTa.setColumns(20);
        txtMoTa.setRows(5);
        srcMoTa.setViewportView(txtMoTa);

        btnThemHang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Add.png"))); // NOI18N
        btnThemHang.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnThemHang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemHangActionPerformed(evt);
            }
        });

        btnLuu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Save.png"))); // NOI18N
        btnLuu.setText("Lưu");
        btnLuu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnLuu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLuuActionPerformed(evt);
            }
        });

        btnSua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Edit.png"))); // NOI18N
        btnSua.setText("Sửa");
        btnSua.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Delete.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Refresh.png"))); // NOI18N
        btnMoi.setText("Mới");
        btnMoi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        btnDau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/First_Btn.png"))); // NOI18N
        btnDau.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnDau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDauActionPerformed(evt);
            }
        });

        btnTruoc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Prev_Btn.png"))); // NOI18N
        btnTruoc.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTruoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTruocActionPerformed(evt);
            }
        });

        btnTiep.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Next_Btn.png"))); // NOI18N
        btnTiep.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnTiep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTiepActionPerformed(evt);
            }
        });

        btnCuoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Last_Btn.png"))); // NOI18N
        btnCuoi.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnCuoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuoiActionPerformed(evt);
            }
        });

        btnThemLoai.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Add.png"))); // NOI18N
        btnThemLoai.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnThemLoai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemLoaiActionPerformed(evt);
            }
        });

        btnThemSize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Add.png"))); // NOI18N
        btnThemSize.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnThemSize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemSizeActionPerformed(evt);
            }
        });

        lblTrangThai.setText("Trạng thái:");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã SP", "Tên SP", "Ảnh", "Mô tả", "Đơn giá", "Số lượng", "Loại", "Size", "Hãng", "Trạng thái"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.String.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSanPham.setRowHeight(25);
        tblSanPham.setRowMargin(5);
        tblSanPham.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSanPhamMouseClicked(evt);
            }
        });
        srcQLSP.setViewportView(tblSanPham);

        btnKHD.setBackground(new java.awt.Color(255, 51, 51));
        btnKHD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Stop.png"))); // NOI18N
        btnKHD.setText("Không hoạt động");
        btnKHD.setToolTipText("");
        btnKHD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnKHD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKHDActionPerformed(evt);
            }
        });

        btnHD.setBackground(new java.awt.Color(51, 255, 0));
        btnHD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Accept.png"))); // NOI18N
        btnHD.setText("Hoạt động");
        btnHD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnHD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(srcQLSP)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnHD)
                        .addGap(18, 18, 18)
                        .addComponent(btnKHD)))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnHD, btnKHD});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(srcQLSP, javax.swing.GroupLayout.DEFAULT_SIZE, 267, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnKHD)
                    .addComponent(btnHD))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnHD, btnKHD});

        cbxTrangThai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbxTrangThaiMouseClicked(evt);
            }
        });
        cbxTrangThai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxTrangThaiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnLuu)
                                .addGap(18, 18, 18)
                                .addComponent(btnSua)
                                .addGap(18, 18, 18)
                                .addComponent(btnXoa)
                                .addGap(18, 18, 18)
                                .addComponent(btnMoi)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnDau)
                                .addGap(18, 18, 18)
                                .addComponent(btnTruoc)
                                .addGap(18, 18, 18)
                                .addComponent(btnTiep)
                                .addGap(18, 18, 18)
                                .addComponent(btnCuoi))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblTrangThai)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbxTrangThai, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(3, 3, 3)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(lblGia, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblTenSP, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addComponent(lblLoai)
                                                .addGap(466, 466, 466)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(btnThemLoai)
                                                    .addComponent(btnThemHang)))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblHang, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(cbxLoai, 0, 457, Short.MAX_VALUE)
                                            .addComponent(cbxHang, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(txtTenSP, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 521, Short.MAX_VALUE)
                                                .addComponent(txtGia)))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(lblMoTa)
                                            .addGap(23, 23, 23)
                                            .addComponent(srcMoTa, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(lblSize, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGap(23, 23, 23)
                                            .addComponent(cbxSize, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(btnThemSize)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblMaSP)
                                            .addComponent(lblSoLuong))
                                        .addGap(23, 23, 23)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 521, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pnlTimKiem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(lblQLSP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(15, 15, 15))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblGia, lblHang, lblLoai, lblMaSP, lblMoTa, lblSize, lblSoLuong, lblTenSP, lblTrangThai});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnCuoi, btnDau, btnLuu, btnMoi, btnSua, btnTiep, btnTruoc, btnXoa});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnThemHang, btnThemLoai, btnThemSize});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cbxHang, cbxLoai, cbxSize});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtGia, txtMaSP, txtSoLuong, txtTenSP});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblQLSP, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblMaSP)
                                .addGap(30, 30, 30)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblSoLuong)
                            .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblSize)
                            .addComponent(cbxSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnThemSize))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblMoTa)
                            .addComponent(srcMoTa, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(lblAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTenSP)
                            .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblGia)
                            .addComponent(txtGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(13, 13, 13)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblLoai)
                                    .addComponent(cbxLoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblHang)
                                    .addComponent(cbxHang)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnThemLoai)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnThemHang)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTrangThai)
                            .addComponent(cbxTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(13, 16, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnTiep, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnTruoc, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(btnDau, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnLuu)
                        .addComponent(btnSua)
                        .addComponent(btnXoa)
                        .addComponent(btnMoi))
                    .addComponent(btnCuoi, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnThemHang, btnThemLoai, btnThemSize, cbxHang, cbxLoai, cbxSize, txtGia, txtMaSP, txtSoLuong, txtTenSP});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnCuoi, btnDau, btnLuu, btnMoi, btnSua, btnTiep, btnTruoc, btnXoa});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblGia, lblHang, lblLoai, lblMaSP, lblMoTa, lblSize, lblSoLuong, lblTenSP, lblTrangThai});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSanPhamMouseClicked
        try {
            if (evt.getClickCount() == 2) {
                this.Index = this.tblSanPham.rowAtPoint(evt.getPoint());
                if (this.Index >= 0) {
                    this.edit();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_tblSanPhamMouseClicked

    private void btnLuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLuuActionPerformed
        if (this.checkNull() == true && this.checkFormat() == true) {
            this.insert();
        }
    }//GEN-LAST:event_btnLuuActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        if (this.checkFormat() == true) {
            this.update();
        }
    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        this.clear();
    }//GEN-LAST:event_btnMoiActionPerformed

    private void btnDauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDauActionPerformed
        this.Index = 0;
        this.edit();
    }//GEN-LAST:event_btnDauActionPerformed

    private void btnTruocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTruocActionPerformed
        if (this.Index > 0) {
            this.Index--;
            this.edit();
        }
    }//GEN-LAST:event_btnTruocActionPerformed

    private void btnTiepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTiepActionPerformed
        if (this.Index < this.tblSanPham.getRowCount() - 1) {
            this.Index++;
            this.edit();
        }
    }//GEN-LAST:event_btnTiepActionPerformed

    private void btnCuoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuoiActionPerformed
        this.Index = tblSanPham.getRowCount() - 1;
        this.edit();
    }//GEN-LAST:event_btnCuoiActionPerformed

    private void btnThemLoaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemLoaiActionPerformed
        this.openFrmLoai();
    }//GEN-LAST:event_btnThemLoaiActionPerformed

    private void btnThemHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemHangActionPerformed
        this.openFrmHang();
    }//GEN-LAST:event_btnThemHangActionPerformed

    private void btnThemSizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemSizeActionPerformed
        this.openFrmSize();
    }//GEN-LAST:event_btnThemSizeActionPerformed

    private void btnHDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHDActionPerformed
        this.loadTblHD();
    }//GEN-LAST:event_btnHDActionPerformed

    private void btnKHDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKHDActionPerformed
        this.loadTblKHD();
    }//GEN-LAST:event_btnKHDActionPerformed

    private void lblAnhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAnhMouseClicked
        try {
            JFileChooser jfc = new JFileChooser("C:\\Users\\Asus\\eclipse-workspace\\PRO1041_QLBG_NHOM6_COD\\img/");
            jfc.showOpenDialog(null);
            File file = jfc.getSelectedFile();
            this.HinhAnh = file.getName();
            Image img = ImageIO.read(file);
            this.lblAnh.setText("");
            int width = this.lblAnh.getWidth();
            int height = this.lblAnh.getHeight();
            this.lblAnh.setIcon(new ImageIcon(img.getScaledInstance(width, height, 0)));
        } catch (Exception e) {
            return;
        }
    }//GEN-LAST:event_lblAnhMouseClicked

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có muốn xóa sản phẩm không?")) {
            this.UpdateTT();
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void cbxHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxHangMouseClicked
        this.loadToCbxHang();
    }//GEN-LAST:event_cbxHangMouseClicked

    private void cbxHangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxHangActionPerformed
//trống
    }//GEN-LAST:event_cbxHangActionPerformed

    private void cbxLoaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxLoaiMouseClicked
        this.loadToCbxLoaiHD();
    }//GEN-LAST:event_cbxLoaiMouseClicked

    private void cbxSizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxSizeMouseClicked
        this.loadToCbxSize();
    }//GEN-LAST:event_cbxSizeMouseClicked

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
//trống
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        this.search();
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void cbxTrangThaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbxTrangThaiMouseClicked
        this.loadToCbxTT();
    }//GEN-LAST:event_cbxTrangThaiMouseClicked

    private void cbxTrangThaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxTrangThaiActionPerformed
//trống
    }//GEN-LAST:event_cbxTrangThaiActionPerformed

    private void cbxLoaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxLoaiActionPerformed
//trốngs
    }//GEN-LAST:event_cbxLoaiActionPerformed

    private void txtTenSPKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTenSPKeyReleased
        try {
            this.sp_Lst = this.Dao.selectAll();
            Integer so = this.sp_Lst.size();
            Integer so1 = so + 1;
            String AUTOMAHD = "SP0".concat(String.valueOf(so1));
            this.txtMaSP.setText(AUTOMAHD);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_txtTenSPKeyReleased

    private void lblAnhMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAnhMouseReleased
//trống
    }//GEN-LAST:event_lblAnhMouseReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCuoi;
    private javax.swing.JButton btnDau;
    private javax.swing.JButton btnHD;
    private javax.swing.JButton btnKHD;
    private javax.swing.JButton btnLuu;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThemHang;
    private javax.swing.JButton btnThemLoai;
    private javax.swing.JButton btnThemSize;
    private javax.swing.JButton btnTiep;
    private javax.swing.JButton btnTruoc;
    private javax.swing.JButton btnXoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbxHang;
    private javax.swing.JComboBox<String> cbxLoai;
    private javax.swing.JComboBox<String> cbxSize;
    private javax.swing.JComboBox<String> cbxTrangThai;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblAnh;
    private javax.swing.JLabel lblGia;
    private javax.swing.JLabel lblHang;
    private javax.swing.JLabel lblLoai;
    private javax.swing.JLabel lblMaSP;
    private javax.swing.JLabel lblMoTa;
    private javax.swing.JLabel lblQLSP;
    private javax.swing.JLabel lblSize;
    private javax.swing.JLabel lblSoLuong;
    private javax.swing.JLabel lblTenSP;
    private javax.swing.JLabel lblTrangThai;
    private javax.swing.JPanel pnlTimKiem;
    private javax.swing.JScrollPane srcMoTa;
    private javax.swing.JScrollPane srcQLSP;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTextField txtGia;
    private javax.swing.JTextField txtMaSP;
    private javax.swing.JTextArea txtMoTa;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenSP;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables

    private boolean checkNull() {
        if (this.txtTenSP.getText().isEmpty()) {
            UTILS_HELPER.alert(this, "Vui lòng điền tên sản phẩm");
            return false;
        }

        if (this.txtMaSP.getText().isEmpty()) {
            UTILS_HELPER.alert(this, "Vui lòng điền mã sản phẩm");
            return false;
        }

        if (this.txtSoLuong.getText().isEmpty()) {
            UTILS_HELPER.alert(this, "Vui lòng điền số lượng");
            return false;
        }

        if (this.txtGia.getText().isEmpty()) {
            UTILS_HELPER.alert(this, "Vui lòng điền giá");
            return false;
        }

        if (this.txtMoTa.getText().isEmpty()) {
            UTILS_HELPER.alert(this, "Vui lòng điền mô tả");
            return false;
        }
        return true;
    }

    private boolean checkFormat() {
        try {
            Float gia = Float.parseFloat(this.txtGia.getText());
            if (gia <= 0) {
                UTILS_HELPER.alert(this, "Vui lòng điền giá lớn hơn 0");
                return false;
            }
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Vui lòng điền giá là số");
            return false;
        }

        try {
            Integer soLuong = Integer.parseInt(this.txtSoLuong.getText());
            if (soLuong <= 0) {
                UTILS_HELPER.alert(this, "Vui lòng điền số lượng lớn hơn 0");
                return false;
            }
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Vui lòng điền số lượng là số");
            return false;
        }

        return true;
    }

    private void inIt() {
        this.Index = -1;
        this.updateStatus();
        this.loadTblHD();
        this.loadToCbxLoaiHD();
        AutoCompleteDecorator.decorate(this.cbxLoai);
        this.loadToCbxSize();
        AutoCompleteDecorator.decorate(this.cbxSize);
        this.loadToCbxHang();
        AutoCompleteDecorator.decorate(this.cbxHang);
        this.loadToCbxTT();
        this.setFrameIcon(UTILS_HELPER.APP_ICON_1);
        this.setTitle("Hệ thống quản lý cửa hàng giày");
    }

    private void loadToTblQLSP() {
        this.TblModel.setRowCount(0);
        try {
            this.sp_Lst = this.Dao.selectAll();
            for (SANPHAM_ENTITY sp_Entity : this.sp_Lst) {
                this.TblModel.addRow(new Object[]{
                    sp_Entity.getMaSP(), sp_Entity.getTenSP(),
                    sp_Entity.getAnh(), sp_Entity.getMoTa(),
                    this.format.format(sp_Entity.getDonGia()),
                    sp_Entity.getSoLuong(), sp_Entity.getLoai(),
                    sp_Entity.getSize(), sp_Entity.getHang(),
                    sp_Entity.getTrangThai()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void loadToCbxLoaiHD() {
        LSHT_DAO loai_dao = new LSHT_DAO();
        List<LOAI_ENTITY> lst = loai_dao.getAllLoaiHD();
        cbxLoai.removeAllItems();
        for (LOAI_ENTITY loai_Entity : lst) {
            cbxLoai.addItem(loai_Entity.getLoai());
        }
    }

    private void loadToCbxSize() {
        LSHT_DAO size_dao = new LSHT_DAO();
        List<SIZE_ENTITY> lst = size_dao.getAllSize();
        this.cbxSize.removeAllItems();
        for (SIZE_ENTITY size_Entity : lst) {
            this.cbxSize.addItem(size_Entity.getSize());
        }
    }

    private void loadToCbxHang() {
        LSHT_DAO hang_dao = new LSHT_DAO();
        List<HANG_ENTITY> lst = hang_dao.getAllHang();
        this.cbxHang.removeAllItems();
        for (HANG_ENTITY hang_Entity : lst) {
            this.cbxHang.addItem(hang_Entity.getHang());
        }
    }

    private void updateStatus() {
        boolean edit = (this.Index >= 0);
        boolean first = (this.Index == 0);
        boolean last = (this.Index == this.tblSanPham.getRowCount() - 1);
        this.txtMaSP.setEditable(!edit);
        this.btnLuu.setEnabled(!edit);
        this.btnSua.setEnabled(edit);
        this.btnXoa.setEnabled(edit);
        this.btnDau.setEnabled(edit && !first);
        this.btnTruoc.setEnabled(edit && !first);
        this.btnTiep.setEnabled(edit && !last);
        this.btnCuoi.setEnabled(edit && !last);
    }

    private void insert() {
        try {
            SANPHAM_ENTITY entity_SP = this.getModel();
            this.Dao.InsertSP(entity_SP);
            SANPHAM_ENTITY entity_TTSP = this.getModel();
            this.Dao.InsertTTSP(entity_TTSP);
            this.loadToTblQLSP();
            this.clear();
            UTILS_HELPER.alert(this, "Thêm mới thành công");
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Thêm mới thất bại");
            e.printStackTrace();
        }
    }

    private void update() {
        if (UTILS_HELPER.confirm(this, "Bạn có muốn cập nhật không?")) {
            SANPHAM_ENTITY entity_TTSP = this.getModel();
            try {
                this.Dao.UpdateTTSP(entity_TTSP);
                this.loadTblHD();
                UTILS_HELPER.alert(this, "Cập nhật thành công");
                return;
            } catch (Exception e) {
                e.printStackTrace();
                UTILS_HELPER.alert(this, "Cập nhật thất bại");
            }
        }
    }

    private void clear() {
        this.txtMaSP.setText("");
        this.txtTenSP.setText("");
        this.txtGia.setText("");
        this.txtSoLuong.setText("");
        this.txtMoTa.setText("");
        this.buttonGroup1.clearSelection();
        this.cbxLoai.setSelectedIndex(0);
        this.cbxSize.setSelectedIndex(0);
        this.cbxHang.setSelectedIndex(0);
        this.lblAnh.setIcon(null);
        this.lblAnh.setText("Nhấn để chọn ảnh");
        this.Index = -1;
        this.updateStatus();
    }

    private void openFrmLoai() {
        try {
            new LOAI_UI(null, closable).setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openFrmSize() {
        try {
            new SIZE_UI(null, closable).setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openFrmHang() {
        try {
            new HANG_UI(null, closable).setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void edit() {
        if (this.Index >= 0) {
            try {
                this.lblAnh.setText(null);
                String maSP = this.tblSanPham.getValueAt(this.Index, 0).toString();
                SANPHAM_ENTITY entity = this.Dao.selectByID(maSP);
                this.setModel(entity);
                this.updateStatus();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            return;
        }
    }

    private void setModel(SANPHAM_ENTITY entity) {
        this.txtMaSP.setText(entity.getMaSP());
        this.txtTenSP.setText(entity.getTenSP());
        this.txtGia.setText(entity.getDonGia() + "");
        this.txtSoLuong.setText(entity.getSoLuong() + "");
        this.cbxTrangThai.setSelectedItem(entity.getTrangThai());
        this.txtMoTa.setText(entity.getMoTa());
        this.cbxLoai.setSelectedItem(entity.getLoai());
        this.cbxSize.setSelectedItem(entity.getSize());
        this.cbxHang.setSelectedItem(entity.getHang());
        if (entity.getAnh() == null) {
            this.lblAnh.setIcon(null);
            this.lblAnh.setText("Trống");
        } else {
            this.lblAnh.setText("");
            ImageIcon imgHinhAnh = new ImageIcon("C:\\Users\\Asus\\eclipse-workspace\\PRO1041_QLBG_NHOM6_COD\\img/" + entity.getAnh());
            Image img = imgHinhAnh.getImage();
            this.HinhAnh = entity.getAnh();
            this.lblAnh.setIcon(new ImageIcon(img.getScaledInstance(this.lblAnh.getWidth(), this.lblAnh.getHeight(), Image.SCALE_SMOOTH)));
        }
    }

    private SANPHAM_ENTITY getModel() {
        SANPHAM_ENTITY entity = new SANPHAM_ENTITY();
        entity.setMaSP(this.txtMaSP.getText());
        entity.setTenSP(this.txtTenSP.getText());
        entity.setAnh(this.HinhAnh);
        entity.setDonGia(Float.parseFloat(this.txtGia.getText()));
        entity.setSoLuong(Integer.parseInt(this.txtSoLuong.getText()));
        entity.setTrangThai(this.cbxTrangThai.getSelectedItem() + "");
        entity.setMoTa(this.txtMoTa.getText());
        entity.setLoai(this.cbxLoai.getSelectedItem() + "");
        entity.setSize(this.cbxSize.getSelectedItem() + "");
        entity.setHang(this.cbxHang.getSelectedItem() + "");
        return entity;
    }

    private void UpdateTT() {
        this.Index = tblSanPham.getSelectedRow();
        if (Index >= 0) {
            this.Index = this.tblSanPham.getSelectedRow();
            if (this.tblSanPham.getValueAt(Index, 9).equals("Hoạt động")) {
                SANPHAM_ENTITY entity = new SANPHAM_ENTITY();
                entity.setMaSP((String) this.tblSanPham.getValueAt(Index, 0));
                this.Dao.UpdateKHD(entity);
                this.clear();
                this.loadTblHD();
                UTILS_HELPER.alert(this, "Xóa thành công");
            } else if (this.tblSanPham.getValueAt(Index, 9).equals("Không hoạt động")) {
                SANPHAM_ENTITY entity = new SANPHAM_ENTITY();
                entity.setMaSP((String) this.tblSanPham.getValueAt(Index, 0));
                this.Dao.UpdateHD(entity);
                this.clear();
                this.loadTblKHD();
                UTILS_HELPER.alert(this, "Xóa thành công");
            }
        } else {
            return;
        }
    }

    private void loadTblHD() {
        this.TblModel.setRowCount(0);
        try {
            this.sp_Lst = this.Dao.selectHD();
            for (SANPHAM_ENTITY sp_Entity : this.sp_Lst) {
                this.TblModel.addRow(new Object[]{
                    sp_Entity.getMaSP(), sp_Entity.getTenSP(),
                    sp_Entity.getAnh(), sp_Entity.getMoTa(),
                    this.format.format(sp_Entity.getDonGia()), sp_Entity.getSoLuong(),
                    sp_Entity.getLoai(), sp_Entity.getSize(),
                    sp_Entity.getHang(), sp_Entity.getTrangThai()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void loadTblKHD() {
        this.TblModel.setRowCount(0);
        try {
            this.sp_Lst = this.Dao.selectKHD();
            for (SANPHAM_ENTITY sp_Entity : this.sp_Lst) {
                this.TblModel.addRow(new Object[]{
                    sp_Entity.getMaSP(), sp_Entity.getTenSP(),
                    sp_Entity.getAnh(), sp_Entity.getMoTa(),
                    this.format.format(sp_Entity.getDonGia()), sp_Entity.getSoLuong(),
                    sp_Entity.getLoai(), sp_Entity.getSize(),
                    sp_Entity.getHang(), sp_Entity.getTrangThai()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void search() {
        this.TblModel.setRowCount(0);
        try {
            this.sp_Lst = this.Dao.SELECT_T1_search(this.txtTimKiem.getText());
            for (SANPHAM_ENTITY sp_Entity : this.sp_Lst) {
                this.TblModel.addRow(new Object[]{
                    sp_Entity.getMaSP(),
                    sp_Entity.getTenSP(),
                    sp_Entity.getAnh(),
                    sp_Entity.getMoTa(),
                    this.format.format(sp_Entity.getDonGia()),
                    sp_Entity.getSoLuong(),
                    sp_Entity.getLoai(),
                    sp_Entity.getSize(),
                    sp_Entity.getHang(),
                    sp_Entity.getTrangThai()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void loadToCbxTT() {
        LSHT_DAO entity = new LSHT_DAO();
        List<TRANGTHAI_ENTITY> lst = entity.getAllTT();
        this.cbxTrangThai.removeAllItems();
        for (TRANGTHAI_ENTITY trangthai_entity : lst) {
            this.cbxTrangThai.addItem(trangthai_entity.getTenTT());
        }
    }
}
