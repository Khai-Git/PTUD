package UI;

import DAO.QLTH_DAO;
import ENTITY.HDCT_ENTITY;
import ENTITY.HD_ENTITY;
import ENTITY.SANPHAM_ENTITY;
import HELPER.UTILS_HELPER;
import java.awt.event.MouseEvent;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class QLTH_UI extends javax.swing.JInternalFrame {

	private int index;
	private QLTH_DAO qlth_Dao;
	private List<HD_ENTITY> hd_Lst;
	private List<HDCT_ENTITY> hdct_Lst;
	private DefaultTableModel tblModel_HD;
	private DefaultTableModel tblModel_HT;
	private DefaultTableModel tblModel_HDCT;
	private Locale locale = new Locale("vi", "VN");
	private NumberFormat format = NumberFormat.getCurrencyInstance(locale);

	public QLTH_UI() {
		this.initComponents();
		this.qlth_Dao = new QLTH_DAO();
		this.tblModel_HD = (DefaultTableModel) tblHoaDon.getModel();
		this.tblModel_HDCT = (DefaultTableModel) tblHDCT.getModel();
		this.tblModel_HT = (DefaultTableModel) tblHoanTra.getModel();
		this.inIt();
	}

	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated
	// Code">//GEN-BEGIN:initComponents
	private void initComponents() {

		ppMnu = new javax.swing.JPopupMenu();
		ppTraMot = new javax.swing.JMenuItem();
		jLabel1 = new javax.swing.JLabel();
		pnlHoaDon = new javax.swing.JPanel();
		jScrollPane1 = new javax.swing.JScrollPane();
		tblHoaDon = new javax.swing.JTable();
		jLabel2 = new javax.swing.JLabel();
		txtTimKiem = new javax.swing.JTextField();
		cbbTrangThai = new javax.swing.JComboBox<>();
		pnlHDCT = new javax.swing.JPanel();
		jScrollPane2 = new javax.swing.JScrollPane();
		tblHDCT = new javax.swing.JTable();
		pnlHoanTra = new javax.swing.JPanel();
		jScrollPane3 = new javax.swing.JScrollPane();
		tblHoanTra = new javax.swing.JTable();
		lblTenKH0 = new javax.swing.JLabel();
		lblMaHD1 = new javax.swing.JLabel();
		lblTenKH1 = new javax.swing.JLabel();
		lblMaHD2 = new javax.swing.JLabel();
		lblTDTT0 = new javax.swing.JLabel();
		lblTDTT1 = new javax.swing.JLabel();
		lblNgayTH = new javax.swing.JLabel();
		dtcNgayTH = new com.toedter.calendar.JDateChooser();
		lblTTHT0 = new javax.swing.JLabel();
		lblTTHT1 = new javax.swing.JLabel();
		btnHoanTra = new javax.swing.JButton();

		ppMnu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

		ppTraMot.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Delete.png"))); // NOI18N
		ppTraMot.setText("Trả một");
		ppTraMot.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
		ppTraMot.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				ppTraMotActionPerformed(evt);
			}
		});
		ppMnu.add(ppTraMot);

		setClosable(true);
		setIconifiable(true);
		setMaximizable(true);
		setResizable(true);

		jLabel1.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
		jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		jLabel1.setText("QUẢN LÝ TRẢ HÀNG");

		pnlHoaDon.setBackground(new java.awt.Color(204, 204, 255));
		pnlHoaDon.setBorder(javax.swing.BorderFactory.createTitledBorder("Hóa đơn"));

		tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {

		}, new String[] { "Mã HĐ", "Tên KH", "Ngày mua", "Hạn trả", "Người tạo", "Thành tiền" }) {
			boolean[] canEdit = new boolean[] { false, false, false, false, false, false };

			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return canEdit[columnIndex];
			}
		});
		tblHoaDon.setRowHeight(25);
		tblHoaDon.setRowMargin(5);
		tblHoaDon.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		tblHoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				tblHoaDonMouseClicked(evt);
			}
		});
		jScrollPane1.setViewportView(tblHoaDon);

		jLabel2.setText("Tìm kiếm:");

		txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyReleased(java.awt.event.KeyEvent evt) {
				txtTimKiemKeyReleased(evt);
			}
		});

		cbbTrangThai.setModel(new javax.swing.DefaultComboBoxModel<>(
				new String[] { "Đã thanh toán", "Chờ xử lý", "Đang giao hàng" }));
		cbbTrangThai.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				cbbTrangThaiActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout pnlHoaDonLayout = new javax.swing.GroupLayout(pnlHoaDon);
		pnlHoaDon.setLayout(pnlHoaDonLayout);
		pnlHoaDonLayout.setHorizontalGroup(pnlHoaDonLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlHoaDonLayout.createSequentialGroup().addContainerGap().addGroup(pnlHoaDonLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jScrollPane1)
						.addGroup(pnlHoaDonLayout.createSequentialGroup().addComponent(jLabel2)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 450,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addComponent(cbbTrangThai, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
						.addContainerGap()));
		pnlHoaDonLayout.setVerticalGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlHoaDonLayout.createSequentialGroup().addContainerGap().addGroup(pnlHoaDonLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel2)
						.addGroup(pnlHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
								.addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(cbbTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 298,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pnlHoaDonLayout.linkSize(javax.swing.SwingConstants.VERTICAL,
				new java.awt.Component[] { cbbTrangThai, jLabel2, txtTimKiem });

		pnlHDCT.setBackground(new java.awt.Color(204, 204, 255));
		pnlHDCT.setBorder(javax.swing.BorderFactory.createTitledBorder("Hóa đơn chi tiết"));

		tblHDCT.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {

		}, new String[] { "Mã HĐ", "Tên SP", "Số lượng", "Đơn giá" }) {
			boolean[] canEdit = new boolean[] { false, false, false, false };

			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return canEdit[columnIndex];
			}
		});
		tblHDCT.setRowHeight(25);
		tblHDCT.setRowMargin(5);
		tblHDCT.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
		tblHDCT.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseReleased(java.awt.event.MouseEvent evt) {
				tblHDCTMouseReleased(evt);
			}
		});
		jScrollPane2.setViewportView(tblHDCT);

		javax.swing.GroupLayout pnlHDCTLayout = new javax.swing.GroupLayout(pnlHDCT);
		pnlHDCT.setLayout(pnlHDCTLayout);
		pnlHDCTLayout.setHorizontalGroup(pnlHDCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlHDCTLayout.createSequentialGroup().addContainerGap()
						.addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 682, Short.MAX_VALUE)
						.addContainerGap()));
		pnlHDCTLayout.setVerticalGroup(pnlHDCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlHDCTLayout.createSequentialGroup().addContainerGap()
						.addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 333,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pnlHoanTra.setBackground(new java.awt.Color(204, 204, 255));
		pnlHoanTra.setBorder(javax.swing.BorderFactory.createTitledBorder("Hoàn trả"));

		tblHoanTra.setModel(new javax.swing.table.DefaultTableModel(new Object[][] {

		}, new String[] { "Mã HĐ", "Tên KH", "Ngày trả", "Tổng tiền hoàn trả" }) {
			boolean[] canEdit = new boolean[] { false, false, false, false };

			public boolean isCellEditable(int rowIndex, int columnIndex) {
				return canEdit[columnIndex];
			}
		});
		tblHoanTra.setRowHeight(25);
		tblHoanTra.setRowMargin(5);
		jScrollPane3.setViewportView(tblHoanTra);

		lblTenKH0.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
		lblTenKH0.setText("Khách hàng:");

		lblMaHD1.setText("Mã HĐ:");

		lblTenKH1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		lblTenKH1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		lblTenKH1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

		lblMaHD2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		lblMaHD2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		lblMaHD2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

		lblTDTT0.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
		lblTDTT0.setText("Tiền đã thanh toán:");

		lblTDTT1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
		lblTDTT1.setForeground(new java.awt.Color(255, 51, 51));
		lblTDTT1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		lblTDTT1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

		lblNgayTH.setText("Ngày trả hàng:");

		lblTTHT0.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
		lblTTHT0.setText("Tổng tiền hoàn trả:");

		lblTTHT1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
		lblTTHT1.setForeground(new java.awt.Color(255, 51, 51));
		lblTTHT1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		lblTTHT1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

		btnHoanTra.setBackground(new java.awt.Color(102, 255, 102));
		btnHoanTra.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Refresh.png"))); // NOI18N
		btnHoanTra.setText("Hoàn trả");
		btnHoanTra.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnHoanTraActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout pnlHoanTraLayout = new javax.swing.GroupLayout(pnlHoanTra);
		pnlHoanTra.setLayout(pnlHoanTraLayout);
		pnlHoanTraLayout.setHorizontalGroup(pnlHoanTraLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlHoanTraLayout.createSequentialGroup()
						.addContainerGap()
						.addGroup(pnlHoanTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addGroup(pnlHoanTraLayout
										.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(pnlHoanTraLayout.createSequentialGroup().addComponent(lblTDTT0)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
												.addComponent(lblTDTT1, javax.swing.GroupLayout.PREFERRED_SIZE, 276,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGroup(pnlHoanTraLayout.createSequentialGroup().addGroup(pnlHoanTraLayout
												.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(lblNgayTH, javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(lblTTHT0, javax.swing.GroupLayout.Alignment.LEADING))
												.addGroup(pnlHoanTraLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(pnlHoanTraLayout.createSequentialGroup()
																.addGap(12, 12, 12).addComponent(dtcNgayTH,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 74,
																		javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(pnlHoanTraLayout.createSequentialGroup()
																.addPreferredGap(
																		javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																.addComponent(lblTTHT1,
																		javax.swing.GroupLayout.PREFERRED_SIZE, 74,
																		javax.swing.GroupLayout.PREFERRED_SIZE))))
										.addGroup(pnlHoanTraLayout.createSequentialGroup()
												.addGroup(pnlHoanTraLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(lblTenKH0).addComponent(lblMaHD1))
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
												.addGroup(pnlHoanTraLayout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(lblMaHD2, javax.swing.GroupLayout.PREFERRED_SIZE,
																366, javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(lblTenKH1, javax.swing.GroupLayout.PREFERRED_SIZE,
																317, javax.swing.GroupLayout.PREFERRED_SIZE))))
								.addComponent(btnHoanTra, javax.swing.GroupLayout.PREFERRED_SIZE, 152,
										javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
						.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 967,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap()));

		pnlHoanTraLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL,
				new java.awt.Component[] { dtcNgayTH, lblMaHD2, lblTDTT1, lblTTHT1, lblTenKH1 });

		pnlHoanTraLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL,
				new java.awt.Component[] { lblMaHD1, lblNgayTH, lblTDTT0, lblTenKH0 });

		pnlHoanTraLayout.setVerticalGroup(pnlHoanTraLayout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(pnlHoanTraLayout.createSequentialGroup().addContainerGap().addGroup(pnlHoanTraLayout
						.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
						.addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
						.addGroup(pnlHoanTraLayout.createSequentialGroup().addGroup(pnlHoanTraLayout
								.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(lblTenKH0)
								.addComponent(lblTenKH1, javax.swing.GroupLayout.PREFERRED_SIZE, 21,
										javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGap(14, 14, 14)
								.addGroup(
										pnlHoanTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(lblMaHD1)
												.addComponent(lblMaHD2, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addGroup(
										pnlHoanTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(lblTDTT0)
												.addComponent(lblTDTT1, javax.swing.GroupLayout.PREFERRED_SIZE, 22,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addGroup(
										pnlHoanTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addComponent(lblNgayTH).addComponent(dtcNgayTH,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addGroup(
										pnlHoanTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(lblTTHT0).addComponent(lblTTHT1,
														javax.swing.GroupLayout.PREFERRED_SIZE, 15,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(btnHoanTra, javax.swing.GroupLayout.PREFERRED_SIZE, 56,
										javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pnlHoanTraLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] { dtcNgayTH, lblMaHD1,
				lblMaHD2, lblNgayTH, lblTDTT0, lblTDTT1, lblTTHT0, lblTTHT1, lblTenKH0, lblTenKH1 });

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout
				.createSequentialGroup().addContainerGap()
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(pnlHoanTra, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addGroup(layout.createSequentialGroup()
								.addComponent(pnlHoaDon, javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
								.addComponent(pnlHDCT, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
				.addContainerGap()));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addContainerGap()
						.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 62,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(pnlHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(pnlHDCT, javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
						.addComponent(pnlHoanTra, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));

		pack();
	}// </editor-fold>//GEN-END:initComponents

	private void tblHoaDonMouseClicked(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_tblHoaDonMouseClicked
		this.loadTblHDCT();
	}// GEN-LAST:event_tblHoaDonMouseClicked

	private void btnHoanTraActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_btnHoanTraActionPerformed
		if (!UTILS_HELPER.isManager()) {
			UTILS_HELPER.alert(this, "Bạn không phải là chủ cửa hàng!");
			return;
		} else {
			if (UTILS_HELPER.confirm(this, "Bạn có chắc chắn muốn hoàn trả?")) {
				this.hoanTra();
			}
		}
	}// GEN-LAST:event_btnHoanTraActionPerformed

	private void tblHDCTMouseReleased(java.awt.event.MouseEvent evt) {// GEN-FIRST:event_tblHDCTMouseReleased
		if (evt.getButton() == MouseEvent.BUTTON3) {
			if (evt.isPopupTrigger() && this.tblHDCT.getSelectedRowCount() != 0) {
				this.ppMnu.show(evt.getComponent(), evt.getX(), evt.getY());
			}
		}
	}// GEN-LAST:event_tblHDCTMouseReleased

	private void ppTraMotActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_ppTraMotActionPerformed
		if (!UTILS_HELPER.isManager()) {
			UTILS_HELPER.alert(this, "Bạn không phải chủ cửa hàng!");
			return;
		} else {
			this.traMotPhan();
		}
	}// GEN-LAST:event_ppTraMotActionPerformed

	private void cbbTrangThaiActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_cbbTrangThaiActionPerformed
		if (this.cbbTrangThai.getSelectedItem().equals("Đang giao hàng")) {
			this.loadTblHD("Đang giao hàng");
		} else if (this.cbbTrangThai.getSelectedItem().equals("Chờ xử lý")) {
			this.loadTblHD("Chờ xử lý");
		} else if (this.cbbTrangThai.getSelectedItem().equals("Đã thanh toán")) {
			this.loadTblHD("Đã thanh toán");
		}
	}// GEN-LAST:event_cbbTrangThaiActionPerformed

	private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {// GEN-FIRST:event_txtTimKiemKeyReleased
		String input = this.txtTimKiem.getText();
		if (this.cbbTrangThai.getSelectedItem().equals("Đang giao hàng")) {
			this.seartchHD(input, "Đang giao hàng");
		} else if (this.cbbTrangThai.getSelectedItem().equals("Chờ xử lý")) {
			this.seartchHD(input, "Chờ xử lý");
		} else if (this.cbbTrangThai.getSelectedItem().equals("Đã thanh toán")) {
			this.seartchHD(input, "Đã thanh toán");
		}
	}// GEN-LAST:event_txtTimKiemKeyReleased

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton btnHoanTra;
	private javax.swing.JComboBox<String> cbbTrangThai;
	private com.toedter.calendar.JDateChooser dtcNgayTH;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JLabel lblMaHD1;
	private javax.swing.JLabel lblMaHD2;
	private javax.swing.JLabel lblNgayTH;
	private javax.swing.JLabel lblTDTT0;
	private javax.swing.JLabel lblTDTT1;
	private javax.swing.JLabel lblTTHT0;
	private javax.swing.JLabel lblTTHT1;
	private javax.swing.JLabel lblTenKH0;
	private javax.swing.JLabel lblTenKH1;
	private javax.swing.JPanel pnlHDCT;
	private javax.swing.JPanel pnlHoaDon;
	private javax.swing.JPanel pnlHoanTra;
	private javax.swing.JPopupMenu ppMnu;
	private javax.swing.JMenuItem ppTraMot;
	private javax.swing.JTable tblHDCT;
	private javax.swing.JTable tblHoaDon;
	private javax.swing.JTable tblHoanTra;
	private javax.swing.JTextField txtTimKiem;
	// End of variables declaration//GEN-END:variables

	private void inIt() {
		this.loadTblHD("Đã thanh toán");
		this.setFrameIcon(UTILS_HELPER.APP_ICON_1);
		this.setTitle("Hệ thống quản lý cửa hàng giày");
	}

	private void loadTblHDCT() {
		try {
			this.loadlbl();
			String sql = "SELECT HOADON.MAHD, SANPHAM.TENSP, HDCHITIET.SOLUONG, HDCHITIET.DONGIA ,SANPHAM.MASP FROM HDCHITIET\n"
					+ "JOIN HOADON ON HOADON.MAHD = HDCHITIET.MAHD\n"
					+ "JOIN SANPHAM ON SANPHAM.MASP = HDCHITIET.MASP\n"
					+ "WHERE HDCHITIET.MAHD = ? AND HDCHITIET.TRANGTHAI =?";
			this.hdct_Lst = this.qlth_Dao.selectbySQLHDCT(sql, this.hd_Lst.get(this.index).getMaHD(), "Đã thanh toán");
			this.fillToTableProductDetail(this.hdct_Lst);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void hoanTra() {
		String maHD = this.lblMaHD2.getText();
		this.qlth_Dao.Update_TRAHANG("Đã trả hàng", maHD, "Đã trả hang");
		this.loadTblHT(maHD);
		this.lblTenKH1.setText("");
		this.lblMaHD2.setText("");
		this.lblTDTT1.setText("");
		this.dtcNgayTH.setDate(UTILS_HELPER.now());
		this.lblTTHT1.setText("");
	}

	private void traMotPhan() {
		this.dtcNgayTH.setDate(new Date());
		this.index = this.tblHDCT.getSelectedRow();
		String maHD = (String) this.tblHDCT.getValueAt(this.index, 0);
		try {
			if (DKTH(maHD) == true) {
				if (UTILS_HELPER.confirm(this, "Bạn có muốn hoàn trả không?")) {
					String tensp = (String) this.tblHDCT.getValueAt(this.index, 1);
					int sl = (int) this.tblHDCT.getValueAt(this.index, 2);
					String donGias = (String) this.tblHDCT.getValueAt(this.index, 3);
					String donGiar = donGias.replaceAll("[. đ]", "");
					float donGia = Float.parseFloat(donGiar);
					HDCT_ENTITY hdct_en = this.qlth_Dao.selectByID_tensp(maHD, tensp);
					String maSP = hdct_en.getMaSP();
					this.motPhan(maHD, maSP, sl, donGia);
					this.loadTblHDCT();
					this.TTKT(maHD);
					this.loadTblHT(maHD);
				}
			} else {
				UTILS_HELPER.alert(this, "Đã quá hạn trả hàng!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private boolean DKTH(String maHD) {
		HD_ENTITY hd_en = this.qlth_Dao.select_DK("Đã thanh toán", maHD);
		long diffDays = 0;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			String startdate = sdf.format(hd_en.getNgayTao());
			String enddate = sdf.format(new Date());
			Date date1 = sdf.parse(startdate);
			Date date2 = sdf.parse(enddate);
			long diff = date2.getTime() - date1.getTime();
			diffDays = diff / (24 * 60 * 60 * 1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (diffDays <= 7) {
			return true;
		}
		return false;
	}

	private void motPhan(String maHD, String maSP, int sl, float donGia) {
		int soLuong = 0;
		String input = JOptionPane.showInputDialog(this, "Nhập số lượng: ");
		while (input.replaceAll("[*a-zA-Z]", "").trim().length() == 0) {
			UTILS_HELPER.alert(this, "Vui lòng nhập lại số lượng sản phẩm!");
			input = JOptionPane.showInputDialog(this, "Nhập số lượng: ");
		}
		soLuong = Integer.parseInt(input);
		String trangThai = "";
		if (soLuong > sl) {
			return;
		} else if (soLuong == sl) {
			trangThai = "Không hoạt động";
		} else if (soLuong < sl) {
			trangThai = "Đã thanh toán";
		}
		HDCT_ENTITY hdct_en = new HDCT_ENTITY();
		hdct_en.setMaHD(maHD);
		hdct_en.setMaSP(maSP);
		int sl_1 = sl - soLuong;
		hdct_en.setSoluong(sl_1);
		hdct_en.setTrangThai(trangThai);
		this.qlth_Dao.Update_HDCT_TRUNGMASP(hdct_en, "Đã thanh toán");
		HDCT_ENTITY hdct_e = new HDCT_ENTITY();
		hdct_e.setMaHD(maHD);
		hdct_e.setMaSP(maSP);
		hdct_e.setSoluong(soLuong);
		hdct_e.setDonGia(donGia);
		this.qlth_Dao.Insert(hdct_e);
		SANPHAM_ENTITY sp_e = this.qlth_Dao.selectByID_SP(maSP);
		int sl_tra_sp = sp_e.getSoLuong() + soLuong;
		this.qlth_Dao.UPDATE_SP(maSP, sl_tra_sp);
	}

	private void loadTblHT(String maHD) {
		this.tblModel_HT.setRowCount(0);
		try {
			this.hdct_Lst = this.qlth_Dao.select(maHD, "Đã trả hang");
			for (HDCT_ENTITY entity : this.hdct_Lst) {
				DateFormat output = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
				Date nth = dtcNgayTH.getDate();
				String outputDate = output.format(nth);
				this.tblModel_HT.addRow(new Object[] { entity.getMaHD(), this.lblTenKH1.getText(), outputDate,
						this.lblTTHT1.getText() });
			}
		} catch (Exception e) {
			e.printStackTrace();
			UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
		}
	}

	private void TTKT(String maHD) {
		try {
			this.hdct_Lst = this.qlth_Dao.select(maHD, "Đã trả hang");
			float TKT = 0;
			int soLuong;
			float donGia;
			for (HDCT_ENTITY hdct_e : this.hdct_Lst) {
				soLuong = hdct_e.getSoluong();
				donGia = hdct_e.getDonGia();
				TKT += soLuong * donGia;
			}
			this.lblTTHT1.setText(this.format.format(TKT));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void loadTblHD(String loai) {
		this.tblModel_HD.setRowCount(0);

		try {
			this.hd_Lst = this.qlth_Dao.selectAllHD(loai);
			for (HD_ENTITY entity : this.hd_Lst) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
				Calendar c = Calendar.getInstance();
				c.setTime(entity.getNgayTao());
				c.add(Calendar.DAY_OF_YEAR, 7);
				this.tblModel_HD.addRow(new Object[] { entity.getMaHD(), entity.getTenKH(),
						dateFormat.format(entity.getNgayTao()), dateFormat.format(c.getTime()), entity.getMaNV(),
						this.format.format(entity.getThanhTien()) });
			}
		} catch (Exception e) {
			e.printStackTrace();
			UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
		}

	}

	private void seartchHD(String input, String loai) {
		this.tblModel_HD.setRowCount(0);
		try {
			this.hd_Lst = this.qlth_Dao.search(input, loai);
			for (HD_ENTITY entity : this.hd_Lst) {
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
				Calendar c = Calendar.getInstance();
				c.setTime(entity.getNgayTao());
				c.add(Calendar.DAY_OF_YEAR, 7);
				this.tblModel_HD.addRow(new Object[] { entity.getMaHD(), entity.getTenKH(),
						dateFormat.format(entity.getNgayTao()), dateFormat.format(c.getTime()), entity.getMaNV(),
						this.format.format(entity.getThanhTien()) });
			}
		} catch (Exception e) {
			e.printStackTrace();
			UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
		}
	}

	private void loadlbl() {
		try {
			this.index = this.tblHoaDon.getSelectedRow();
			if (this.index < 0) {
				return;
			} else {
				this.lblTenKH1.setText(this.tblHoaDon.getValueAt(this.index, 1).toString());
				this.lblMaHD2.setText(this.tblHoaDon.getValueAt(this.index, 0).toString());
				this.lblTDTT1.setText(this.tblHoaDon.getValueAt(this.index, 5).toString());
			}
			this.index = this.tblHoaDon.getSelectedRow();
			if (this.index == -1) {
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void fillToTableProductDetail(List<HDCT_ENTITY> hdct_Lst) {
		this.tblModel_HDCT.setRowCount(0);
		for (HDCT_ENTITY productDetail : hdct_Lst) {
			fillToTableProductDetail(productDetail);
		}
	}

	private void fillToTableProductDetail(HDCT_ENTITY p) {
		this.tblModel_HDCT.addRow(new Object[] { p.getMaHD(), p.getTenSP(), p.getSoluong(),
				this.format.format(p.getDonGia()), p.getTrangThai() });
	}

}
