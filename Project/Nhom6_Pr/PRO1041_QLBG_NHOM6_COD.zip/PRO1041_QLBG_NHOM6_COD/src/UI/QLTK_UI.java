package UI;

import DAO.QLTK_DAO;
import ENTITY.HD_ENTITY;
import ENTITY.SHD_ENITY;
import ENTITY.SPBR_ENITY;
import HELPER.UTILS_HELPER;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.text.DecimalFormat;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import ENTITY.STDT_ENITY;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class QLTK_UI extends javax.swing.JInternalFrame {

    public int index;
    public QLTK_DAO tk_Dao;
    public List<HD_ENTITY> hd_Lst;
    public DefaultTableModel tblModel_TK;

    public QLTK_UI() {
        this.initComponents();
        this.tk_Dao = new QLTK_DAO();
        this.tblModel_TK = (DefaultTableModel) this.tblTK.getModel();
        this.inIt();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTK = new javax.swing.JTable();
        lbltongtien = new javax.swing.JLabel();
        lbltongdoanhthu1 = new javax.swing.JLabel();
        btnxuatfile = new javax.swing.JButton();
        lblts = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        lbltongsohoadon = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("QUẢN LÝ THỐNG KÊ");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel2.setText("Tìm kiếm:");

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Statistics.png"))); // NOI18N
        jButton3.setText("Thống kê");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        tblTK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã HĐ", "Tên NV", "Ngày bán", "Tên khách hàng", "Thành tiền"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblTK.setRowHeight(25);
        tblTK.setRowMargin(5);
        tblTK.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tblTK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTKMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblTK);
        if (tblTK.getColumnModel().getColumnCount() > 0) {
            tblTK.getColumnModel().getColumn(3).setResizable(false);
            tblTK.getColumnModel().getColumn(4).setResizable(false);
        }

        lbltongtien.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbltongtien.setText("Tổng tiền hóa đơn:");

        lbltongdoanhthu1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        btnxuatfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Print.png"))); // NOI18N
        btnxuatfile.setText("Xuất file");
        btnxuatfile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnxuatfileActionPerformed(evt);
            }
        });

        lblts.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblts.setText("Tổng số hóa đơn:");

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });
        txtTimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTimKiemKeyReleased(evt);
            }
        });

        lbltongsohoadon.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(390, 390, 390)
                        .addComponent(lbltongdoanhthu1, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblts)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbltongsohoadon, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 425, Short.MAX_VALUE)
                                .addComponent(lbltongtien, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtTimKiem)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnxuatfile, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnxuatfile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(23, 23, 23))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lbltongsohoadon, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lbltongtien))
                    .addComponent(lblts, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addComponent(lbltongdoanhthu1))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lbltongsohoadon, lbltongtien, lblts});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jLabel2, txtTimKiem});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblTKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTKMouseClicked

    }//GEN-LAST:event_tblTKMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        BD_UI tk = new BD_UI();
        tk.setVisible(true); 
        tk.setSize(GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().width, GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds().height);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
        
        this.tblModel_TK.setRowCount(0);
        try {
            this.hd_Lst = this.tk_Dao.search(this.txtTimKiem.getText());
            for (HD_ENTITY hd : hd_Lst) {
                this.tblModel_TK.addRow(new Object[]{
                    hd.getMaHD(),
                    hd.getMaNV(),
                    hd.getNgayTao(),
                    hd.getTenKH(),
                    hd.getThanhTien()
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }//GEN-LAST:event_txtTimKiemKeyReleased

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void btnxuatfileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnxuatfileActionPerformed
        try {
            XSSFWorkbook workbook = new XSSFWorkbook();
            XSSFSheet spreadsheet = workbook.createSheet("Thống kê");

            XSSFRow row = null;
            Cell cell = null;

            row = spreadsheet.createRow((short) 2);
            row.setHeight((short) 500);
            cell = row.createCell(0, CellType.STRING);
            cell.setCellValue("DANH SÁCH THỐNG KÊ");

            row = spreadsheet.createRow((short) 3);
            row.setHeight((short) 500);
            cell = row.createCell(0, CellType.STRING);
            cell.setCellValue("STT");
            cell = row.createCell(1, CellType.STRING);
            cell.setCellValue("Mã hóa đơn");
            cell = row.createCell(2, CellType.STRING);
            cell.setCellValue("Tên nhân viên ");
            cell = row.createCell(3, CellType.STRING);
            cell.setCellValue("Ngày bán");
            cell = row.createCell(4, CellType.STRING);
            cell.setCellValue("Tên khách hàng");
            cell = row.createCell(5, CellType.STRING);
            cell.setCellValue("Thành tiền");

            for (int i = 0; i < hd_Lst.size(); i++) {
                HD_ENTITY hd = this.hd_Lst.get(i);
                row = spreadsheet.createRow((short) 4 + i);
                row.setHeight((short) 400);
                row.createCell(0).setCellValue(i + 1);
                row.createCell(1).setCellValue(hd.getMaHD());
                row.createCell(2).setCellValue(hd.getMaNV());
                row.createCell(3).setCellValue(hd.getNgayTao().toString());
                row.createCell(4).setCellValue(hd.getTenKH());
                row.createCell(5).setCellValue(hd.getThanhTien());
            }
            File file = new File("D:/DanhSach.xlsx");
            FileOutputStream out = new FileOutputStream(file);
            workbook.write(out);
            out.close();
            JOptionPane.showMessageDialog(this, "In danh sách thành công!");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_btnxuatfileActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnxuatfile;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbltongdoanhthu1;
    private javax.swing.JLabel lbltongsohoadon;
    private javax.swing.JLabel lbltongtien;
    private javax.swing.JLabel lblts;
    private javax.swing.JTable tblTK;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables

    public void inIt() {
        this.loadtblTK();
        this.tongdoanhthu2();
        this.tongdoanhthu1();
        this.setFrameIcon(UTILS_HELPER.APP_ICON_1);
        this.setTitle("Hệ thống quản lý cửa hàng giày");
    }

    public void loadtblTK() {
        this.tblModel_TK.setRowCount(0);
        try {
            this.hd_Lst = this.tk_Dao.selectHD();
            for (HD_ENTITY hd : this.hd_Lst) {
                this.tblModel_TK.addRow(new Object[]{
                    hd.getMaHD(),
                    hd.getMaNV(),
                    hd.getNgayTao(),
                    hd.getTenKH(),
                    hd.getThanhTien(),});
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }
        
   public void setDatatoChart3(JPanel pnlThongKe) {
        List<SPBR_ENITY> hd_Lst = this.tk_Dao.selectSPBR();
        if (hd_Lst != null) {
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for (SPBR_ENITY stdt : hd_Lst) {
                dataset.addValue(stdt.getSoluong(), "Sản phẩm", stdt.getMasp());
            }
            JFreeChart jchar = ChartFactory.createBarChart("Biểu đồ cột thống kê sản phẩm bán ra", "sản phẩm", "số lượng sản phẩm", dataset);
            ChartPanel chartfr = new ChartPanel(jchar);
            chartfr.setPreferredSize(new Dimension(pnlThongKe.getWidth(), 500));

            pnlThongKe.removeAll();
            pnlThongKe.setLayout(new CardLayout());
            pnlThongKe.add(chartfr);
        }
    }

    public void setDatatoChart2(JPanel pnlThongKe) {
        List<STDT_ENITY> hd_Lst = this.tk_Dao.selectDT();
        if (hd_Lst != null) {
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for (STDT_ENITY stdt : hd_Lst) {
                dataset.addValue(stdt.getDoanhthu(), "Doanh Thu", stdt.getNgaytao());
            }
            JFreeChart jchar = ChartFactory.createBarChart("Biểu đồ cột thống kê doanh thu", "Thời gian", "Doanh thu hóa đơn(VNĐ)", dataset);
            ChartPanel chartfr = new ChartPanel(jchar);
            chartfr.setPreferredSize(new Dimension(pnlThongKe.getWidth(), 500));

            pnlThongKe.removeAll();
            pnlThongKe.setLayout(new CardLayout());
            pnlThongKe.add(chartfr);
        }

    }

    public void tongdoanhthu1() {
        this.hd_Lst = this.tk_Dao.tongsohoadonHT();
        int sl = hd_Lst.size();
        this.lbltongsohoadon.setText(String.valueOf(sl));
    }

    public void tongdoanhthu2() {
        DecimalFormat x = new DecimalFormat();
        float Tong = 0;
        for (int i = 0; i < this.tblTK.getRowCount(); i++) {
            Tong += Float.parseFloat(this.tblTK.getValueAt(i, 4).toString());
        }
        this.lbltongtien.setText("Tổng doanh thu : " + x.format(Tong) + " " + ".VNĐ");
    }

}
