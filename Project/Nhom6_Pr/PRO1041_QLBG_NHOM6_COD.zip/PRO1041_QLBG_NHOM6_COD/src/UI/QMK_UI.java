package UI;

import DAO.QLND_DAO;
import ENTITY.NGUOIDUNG_ENTITY;
import HELPER.UTILS_HELPER;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class QMK_UI extends javax.swing.JFrame {

    private String save = "";
    private Pattern pattern;
    private Matcher matcher;

    public QMK_UI() {
        this.initComponents();
        this.init();
        this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtemail = new javax.swing.JTextField();
        txtcode = new javax.swing.JTextField();
        btnhuybo = new javax.swing.JButton();
        btndongy = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lblguilai = new javax.swing.JLabel();
        btngui = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 22)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("QUÊN MẬT KHẨU");

        jLabel1.setText("Email:");

        jLabel2.setText("Code:");

        txtcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodeActionPerformed(evt);
            }
        });

        btnhuybo.setBackground(new java.awt.Color(255, 153, 153));
        btnhuybo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/No.png"))); // NOI18N
        btnhuybo.setText("Hủy bỏ");
        btnhuybo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhuyboActionPerformed(evt);
            }
        });

        btndongy.setBackground(new java.awt.Color(102, 255, 102));
        btndongy.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Accept.png"))); // NOI18N
        btndongy.setText("Đồng ý");
        btndongy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndongyActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 11)); // NOI18N
        jLabel3.setText("Hãy nhập code được gửi trong gmail:");

        lblguilai.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblguilai.setForeground(new java.awt.Color(255, 0, 0));
        lblguilai.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblguilai.setText("Gửi lại code?");
        lblguilai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblguilaiMouseClicked(evt);
            }
        });

        btngui.setBackground(new java.awt.Color(255, 255, 102));
        btngui.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Letter.png"))); // NOI18N
        btngui.setText("Gửi");
        btngui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnguiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtcode)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addComponent(txtemail))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btngui, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(482, 482, 482)
                        .addComponent(btndongy)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblguilai, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnhuybo, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel1, jLabel2});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btndongy, btngui, btnhuybo});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtemail, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btngui, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcode, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblguilai)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btndongy, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnhuybo))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btngui, jLabel1, jLabel2, txtcode, txtemail});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btndongy, btnhuybo});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btndongyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndongyActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có muốn đổi mật khẩu không?")) {
            this.dongy();
            this.updateMKWhereEmail();
        }
    }//GEN-LAST:event_btndongyActionPerformed

    private void btnguiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnguiActionPerformed
        if (check_email() == true) {
            try {
                if (this.txtemail.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "không được để trống email");
                    return;
                }
                String email = this.txtemail.getText();
                this.pattern = Pattern.compile(EMAIL_PATTERN);
                if (!validate(email)) {
                    JOptionPane.showMessageDialog(this, "Email không hợp lệ");
                    return;
                }
                this.guiEmail();
            } catch (MessagingException ex) {
                Logger.getLogger(QMK_UI.class.getName()).log(Level.SEVERE, null, ex);
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(QMK_UI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_btnguiActionPerformed

    private void txtcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodeActionPerformed

    }//GEN-LAST:event_txtcodeActionPerformed

    private void btnhuyboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhuyboActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có muốn hủy không?")) {
            this.cancel();
        }
    }//GEN-LAST:event_btnhuyboActionPerformed

    private void lblguilaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblguilaiMouseClicked
        this.save = "";
        try {
            this.guiEmail();
        } catch (MessagingException ex) {
            Logger.getLogger(QMK_UI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(QMK_UI.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_lblguilaiMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btndongy;
    private javax.swing.JButton btngui;
    private javax.swing.JButton btnhuybo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblguilai;
    private javax.swing.JTextField txtcode;
    private javax.swing.JTextField txtemail;
    // End of variables declaration//GEN-END:variables

    private void init() {
        this.setResizable(false);
        this.setTitle("Hệ thống quản lý cửa hàng giày");
        this.setIconImage(UTILS_HELPER.APP_ICON);
    }

    private void guiEmail() throws MessagingException, UnsupportedEncodingException {
        if (check_email() == true) {
            final String fromEmail = "cuongboy0257@gmail.com";
            final String password = "0273838168";
            final String toEmail = this.txtemail.getText();
            final String subject = "CODE của 1 thằng *** quên mật khẩu là:";
            for (int i = 0; i < 6; i++) {
                double randomDouble = Math.random();
                randomDouble = randomDouble * 9 + 1;
                int randomInt = (int) randomDouble;
                this.save += randomInt;
            }
            final String body = "Code của bạn là: " + this.save;
            Properties props = new Properties();
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            Authenticator auth = new Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(fromEmail, password);
                }
            };
            Session session = Session.getInstance(props, auth);
            MimeMessage msg = new MimeMessage(session);
            msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
            msg.addHeader("format", "flowed");
            msg.addHeader("Content-Transfer-Encoding", "8bit");
            msg.setFrom(new InternetAddress(fromEmail, "NoReply-JD"));
            msg.setReplyTo(InternetAddress.parse(fromEmail, false));
            msg.setSubject(subject, "UTF-8");
            msg.setText(body, "UTF-8");
            msg.setSentDate(new Date());
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toEmail, false));
            Transport.send(msg);
            JOptionPane.showMessageDialog(this, "đã gửi mail thành công!");
        }
    }

    private void dongy() {
        String code = this.txtcode.getText();
        if (!code.equalsIgnoreCase(this.save)) {
            JOptionPane.showMessageDialog(this, "bạn đã nhập sai! mời bạn nhập lại");
            return;
        } else {
            JOptionPane.showMessageDialog(this, "bạn đã nhập đúng");
        }
    }

    private void cancel() {
        this.dispose();
    }

    private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

    public boolean validate(String regex) {
        this.matcher = this.pattern.matcher(regex);
        return this.matcher.matches();
    }

    private void updateMKWhereEmail() {
        try {
            QLND_DAO nd_d = new QLND_DAO();
            String email = this.txtemail.getText();
            NGUOIDUNG_ENTITY nd = this.model();
            nd_d.update_mk(nd);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private NGUOIDUNG_ENTITY model() {
        NGUOIDUNG_ENTITY nd_e = new NGUOIDUNG_ENTITY();
        String email = this.txtemail.getText();
        nd_e.setMatKhau(this.save);;
        nd_e.setEmail(email);
        return nd_e;
    }

    private boolean check_email() {
        try {
            QLND_DAO nd_dao = new QLND_DAO();
            String email = this.txtemail.getText();
            NGUOIDUNG_ENTITY nd = nd_dao.select_by_email(email);
            if (nd == null) {
                JOptionPane.showMessageDialog(this, "sai tên email", "lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            } else if (!nd.isTrangThai()) {
                JOptionPane.showMessageDialog(this, "Nhân viên có " + this.txtemail.getText() + " không còn hoạt động", "lỗi", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

}
