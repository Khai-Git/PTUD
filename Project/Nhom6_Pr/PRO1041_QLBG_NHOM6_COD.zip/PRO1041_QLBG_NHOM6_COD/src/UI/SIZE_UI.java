package UI;

import DAO.LSHT_DAO;
import java.util.List;
import ENTITY.SIZE_ENTITY;
import ENTITY.TRANGTHAI_ENTITY;
import HELPER.UTILS_HELPER;
import javax.swing.table.DefaultTableModel;

public class SIZE_UI extends javax.swing.JDialog {

    private LSHT_DAO Dao;
    private List<SIZE_ENTITY> Lst;
    private DefaultTableModel Model;

    public SIZE_UI(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.initComponents();
        this.inIt();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnTrangThai = new javax.swing.ButtonGroup();
        lblSize = new javax.swing.JLabel();
        txtSize = new javax.swing.JTextField();
        lblTrangThai = new javax.swing.JLabel();
        btnThem = new javax.swing.JButton();
        btnMoi = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblSize = new javax.swing.JTable();
        btnKHD = new javax.swing.JButton();
        btnHD = new javax.swing.JButton();
        cbxTrangThai = new javax.swing.JComboBox<>();
        btnXoa = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lblSize.setText("Size:");

        txtSize.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSizeKeyPressed(evt);
            }
        });

        lblTrangThai.setText("Trạng thái:");

        btnThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Save.png"))); // NOI18N
        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Add.png"))); // NOI18N
        btnMoi.setText("Mới");
        btnMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiActionPerformed(evt);
            }
        });

        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        tblSize.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Loại", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSizeMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblSize);

        btnKHD.setBackground(new java.awt.Color(255, 51, 51));
        btnKHD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Stop.png"))); // NOI18N
        btnKHD.setText("Không hoạt động");
        btnKHD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKHDActionPerformed(evt);
            }
        });

        btnHD.setBackground(new java.awt.Color(51, 255, 0));
        btnHD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Accept.png"))); // NOI18N
        btnHD.setText("Hoạt động");
        btnHD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHDActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnHD)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnKHD)))
                .addContainerGap())
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnHD, btnKHD});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnKHD)
                    .addComponent(btnHD))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnHD, btnKHD});

        btnXoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Delete.png"))); // NOI18N
        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnThem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnXoa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnMoi)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTrangThai)
                            .addComponent(lblSize))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtSize)
                            .addComponent(cbxTrangThai, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnMoi, btnThem, btnXoa});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSize))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTrangThai)
                    .addComponent(cbxTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMoi)
                    .addComponent(btnThem)
                    .addComponent(btnXoa))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có muốn thêm size không?")) {
            if (this.checknull() == true && this.checkformat() == true) {
                this.insert();
            }
        }
    }//GEN-LAST:event_btnThemActionPerformed

    private void tblSizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSizeMouseClicked
        this.clickTbl();
    }//GEN-LAST:event_tblSizeMouseClicked

    private void btnMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiActionPerformed
        this.clear();
    }//GEN-LAST:event_btnMoiActionPerformed

    private void btnHDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHDActionPerformed
        this.loadTblHD();
    }//GEN-LAST:event_btnHDActionPerformed

    private void btnKHDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKHDActionPerformed
        this.loadTblKHD();
    }//GEN-LAST:event_btnKHDActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed
        if (UTILS_HELPER.confirm(this, "Bạn có xóa size không?")) {
            this.delete();
        }
    }//GEN-LAST:event_btnXoaActionPerformed

    private void txtSizeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSizeKeyPressed
      
    }//GEN-LAST:event_txtSizeKeyPressed
//    public static void main(String[] args) {
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(SIZE_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(SIZE_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(SIZE_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(SIZE_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//        new SIZE_UI(null, true).setVisible(true);
//    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHD;
    private javax.swing.JButton btnKHD;
    private javax.swing.JButton btnMoi;
    private javax.swing.JButton btnThem;
    private javax.swing.ButtonGroup btnTrangThai;
    private javax.swing.JButton btnXoa;
    private javax.swing.JComboBox<String> cbxTrangThai;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblSize;
    private javax.swing.JLabel lblTrangThai;
    private javax.swing.JTable tblSize;
    private javax.swing.JTextField txtSize;
    // End of variables declaration//GEN-END:variables

    private void inIt() {
        this.setTitle("Hệ thống quản lý cửa hàng giày");
        this.setLocationRelativeTo(null);
        this.Dao = new LSHT_DAO();
        this.Lst = Dao.getAllSize();
        this.Model = (DefaultTableModel) tblSize.getModel();
        this.loadTblHD();
        this.loadToCbxTT();
        this.setIconImage(UTILS_HELPER.APP_ICON);
        this.setResizable(false);       
    }

    private boolean checknull() {
        if (txtSize.getText().isEmpty()) {
            UTILS_HELPER.alert(this, "Vui lòng điền size");
            return false;
        }
        return true;
    }

    private boolean checkformat() {
        try {
            Float size = Float.parseFloat(this.txtSize.getText());
            if(size<=0){
                UTILS_HELPER.alert(this,"Size phải lớn hơn 0");
                return false;
            }
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Size phải là số");
            return false;
        }
        return true;
    }

    private void loadToCbxTT() {
        LSHT_DAO entity = new LSHT_DAO();
        List<TRANGTHAI_ENTITY> lst = entity.getAllTT();
        this.cbxTrangThai.removeAllItems();
        for (TRANGTHAI_ENTITY trangthai_entity : lst) {
            this.cbxTrangThai.addItem(trangthai_entity.getTenTT());
        }
    }

    private void loadTblHD() {
        this.Model.setRowCount(0);
        try {
            this.Lst = this.Dao.selectSizeHD();
            for (SIZE_ENTITY Entity : this.Lst) {
                this.Model.addRow(
                        new Object[]{
                            Entity.getSize(),
                            Entity.getTrangThai()});
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void loadTblKHD() {
        this.Model.setRowCount(0);
        try {
            this.Lst = this.Dao.selectSizeKHD();
            for (SIZE_ENTITY Entity : this.Lst) {
                this.Model.addRow(
                        new Object[]{
                            Entity.getSize(),
                            Entity.getTrangThai()});
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void clickTbl() {
        int Index = tblSize.getSelectedRow();
        if (Index >= 0) {
            this.btnThem.setEnabled(false);
            this.txtSize.setEditable(false);
            String loai = tblSize.getValueAt(Index, 0).toString();
            String trangThai = tblSize.getValueAt(Index, 1).toString();
            txtSize.setText(loai);
            this.cbxTrangThai.setSelectedItem(trangThai);
        } else {
            return;
        }
    }

    private void clear() {
        this.txtSize.setText("");
        this.btnThem.setEnabled(true);
        this.txtSize.setEditable(true);
        this.cbxTrangThai.setSelectedIndex(0);
    }

    private void insert() {
        try {
            SIZE_ENTITY entity = new SIZE_ENTITY();
            entity.setSize(this.txtSize.getText());
            entity.setTrangThai(this.cbxTrangThai.getSelectedItem() + "");
            this.Dao.insert(entity);
            this.inIt();
            UTILS_HELPER.alert(this, "Thêm size mới thành công");
        } catch (Exception e) {
            UTILS_HELPER.alert(this, "Thêm size mới thất bại");
            e.printStackTrace();
        }
    }

    private void delete() {
        int Index = tblSize.getSelectedRow();
        if (Index >= 0) {
            int loai_Index = this.tblSize.getSelectedRow();
            try {
                if (this.tblSize.getValueAt(loai_Index, 1).equals("Hoạt động")) {
                    SIZE_ENTITY entity = new SIZE_ENTITY();
                    entity.setSize((String) this.tblSize.getValueAt(loai_Index, 0));
                    this.Dao.updateKHD(entity);
                    this.clear();
                    this.loadTblHD();
                    UTILS_HELPER.alert(this, "Xóa thành công");
                } else if (this.tblSize.getValueAt(loai_Index, 1).equals("Không hoạt động")) {
                    SIZE_ENTITY entity = new SIZE_ENTITY();
                    entity.setSize((String) this.tblSize.getValueAt(loai_Index, 0));
                    this.Dao.updateHD(entity);
                    this.clear();
                    this.loadTblKHD();
                    UTILS_HELPER.alert(this, "Xóa thành công");
                }
            } catch (Exception e) {
                e.printStackTrace();
                UTILS_HELPER.alert(this, "Xóa thất bại");
            }
        } else {
            return;
        }

    }
}
