package UI;

import java.awt.Color;
import java.util.Date;
import javax.swing.Timer;
import HELPER.UTILS_HELPER;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;

public class TRANGCHU_UI extends javax.swing.JFrame {

    public TRANGCHU_UI() {
        this.initComponents();
        this.inIt();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlMenu = new javax.swing.JPanel();
        lblSanPham = new javax.swing.JLabel();
        lblGiaoDich = new javax.swing.JLabel();
        lblNguoiDung = new javax.swing.JLabel();
        lblTraHang = new javax.swing.JLabel();
        lblThongKe = new javax.swing.JLabel();
        lblDangXuat = new javax.swing.JLabel();
        lblDoiMK = new javax.swing.JLabel();
        lblKetThuc = new javax.swing.JLabel();
        lblDongHo = new javax.swing.JLabel();
        lblQuyen = new javax.swing.JLabel();
        pnlHome = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlMenu.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        pnlMenu.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        lblSanPham.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblSanPham.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSanPham.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Full basket.png"))); // NOI18N
        lblSanPham.setText("SẢN PHẨM");
        lblSanPham.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblSanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSanPhamMouseClicked(evt);
            }
        });

        lblGiaoDich.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblGiaoDich.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGiaoDich.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Dollar.png"))); // NOI18N
        lblGiaoDich.setText("GIAO DỊCH");
        lblGiaoDich.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblGiaoDich.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGiaoDichMouseClicked(evt);
            }
        });

        lblNguoiDung.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblNguoiDung.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNguoiDung.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Users.png"))); // NOI18N
        lblNguoiDung.setText("NGƯỜI DÙNG");
        lblNguoiDung.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblNguoiDung.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblNguoiDungMouseClicked(evt);
            }
        });

        lblTraHang.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblTraHang.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTraHang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Conference.png"))); // NOI18N
        lblTraHang.setText("TRẢ HÀNG");
        lblTraHang.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblTraHang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTraHangMouseClicked(evt);
            }
        });

        lblThongKe.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblThongKe.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblThongKe.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Bar chart.png"))); // NOI18N
        lblThongKe.setText("THỐNG KÊ");
        lblThongKe.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblThongKe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblThongKeMouseClicked(evt);
            }
        });

        lblDangXuat.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblDangXuat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDangXuat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Exit.png"))); // NOI18N
        lblDangXuat.setText("ĐĂNG XUẤT");
        lblDangXuat.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblDangXuat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDangXuatMouseClicked(evt);
            }
        });

        lblDoiMK.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblDoiMK.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDoiMK.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Refresh.png"))); // NOI18N
        lblDoiMK.setText("ĐỔI MẬT KHẨU");
        lblDoiMK.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblDoiMK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDoiMKMouseClicked(evt);
            }
        });

        lblKetThuc.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        lblKetThuc.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKetThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Stop.png"))); // NOI18N
        lblKetThuc.setText("KẾT THÚC");
        lblKetThuc.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblKetThuc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblKetThucMouseClicked(evt);
            }
        });

        lblDongHo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lblDongHo.setForeground(new java.awt.Color(0, 153, 153));
        lblDongHo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Clock.png"))); // NOI18N
        lblDongHo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        lblDongHo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        lblQuyen.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        lblQuyen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/User.png"))); // NOI18N
        lblQuyen.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout pnlMenuLayout = new javax.swing.GroupLayout(pnlMenu);
        pnlMenu.setLayout(pnlMenuLayout);
        pnlMenuLayout.setHorizontalGroup(
            pnlMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlMenuLayout.createSequentialGroup()
                .addGroup(pnlMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblQuyen, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDongHo, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblKetThuc, javax.swing.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE)
                    .addComponent(lblSanPham, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(lblGiaoDich, javax.swing.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE)
                    .addComponent(lblNguoiDung, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(lblTraHang, javax.swing.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE)
                    .addComponent(lblThongKe, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(lblDangXuat, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                    .addComponent(lblDoiMK, javax.swing.GroupLayout.DEFAULT_SIZE, 285, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pnlMenuLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDangXuat, lblDoiMK, lblDongHo, lblGiaoDich, lblKetThuc, lblNguoiDung, lblSanPham, lblThongKe, lblTraHang});

        pnlMenuLayout.setVerticalGroup(
            pnlMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlMenuLayout.createSequentialGroup()
                .addComponent(lblQuyen, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDongHo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblGiaoDich, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblNguoiDung, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTraHang, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDoiMK, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDangXuat, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblKetThuc)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlMenuLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDangXuat, lblDoiMK, lblGiaoDich, lblKetThuc, lblNguoiDung, lblSanPham, lblThongKe, lblTraHang});

        pnlHome.setBackground(new java.awt.Color(204, 255, 204));
        pnlHome.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout pnlHomeLayout = new javax.swing.GroupLayout(pnlHome);
        pnlHome.setLayout(pnlHomeLayout);
        pnlHomeLayout.setHorizontalGroup(
            pnlHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1505, Short.MAX_VALUE)
        );
        pnlHomeLayout.setVerticalGroup(
            pnlHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlMenu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnlMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblSanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSanPhamMouseClicked
        this.FrmSanPham();
    }//GEN-LAST:event_lblSanPhamMouseClicked

    private void lblGiaoDichMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGiaoDichMouseClicked
        this.FrmGiaoDich();
    }//GEN-LAST:event_lblGiaoDichMouseClicked

    private void lblNguoiDungMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNguoiDungMouseClicked
        this.FrmNguoiDung();
    }//GEN-LAST:event_lblNguoiDungMouseClicked

    private void lblTraHangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTraHangMouseClicked
        this.FrmKhachHang();
    }//GEN-LAST:event_lblTraHangMouseClicked

    private void lblThongKeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblThongKeMouseClicked
        this.FrmThongKe();
    }//GEN-LAST:event_lblThongKeMouseClicked

    private void lblDoiMKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDoiMKMouseClicked
        this.doiMK();
    }//GEN-LAST:event_lblDoiMKMouseClicked

    private void lblDangXuatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDangXuatMouseClicked
        this.dangXuat();
    }//GEN-LAST:event_lblDangXuatMouseClicked

    private void lblKetThucMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblKetThucMouseClicked
        this.ketThuc();
    }//GEN-LAST:event_lblKetThucMouseClicked
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TRANGCHU_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TRANGCHU_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TRANGCHU_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TRANGCHU_UI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TRANGCHU_UI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblDangXuat;
    private javax.swing.JLabel lblDoiMK;
    private javax.swing.JLabel lblDongHo;
    private javax.swing.JLabel lblGiaoDich;
    private javax.swing.JLabel lblKetThuc;
    private javax.swing.JLabel lblNguoiDung;
    private javax.swing.JLabel lblQuyen;
    private javax.swing.JLabel lblSanPham;
    private javax.swing.JLabel lblThongKe;
    private javax.swing.JLabel lblTraHang;
    private javax.swing.JPanel pnlHome;
    private javax.swing.JPanel pnlMenu;
    // End of variables declaration//GEN-END:variables

    private void inIt() {
        this.clock();
        this.setLocationRelativeTo(null);
        this.setExtendedState(MAXIMIZED_BOTH);
        this.setIconImage(UTILS_HELPER.APP_ICON);
        new DN_UI(this, true).setVisible(true);
        this.setTitle("Hệ thống quản lý cửa hàng giày");
        if (UTILS_HELPER.isLogin()) {
            this.lblQuyen.setText(UTILS_HELPER.user.getTenND());
        } else {
            this.lblQuyen.setText("Bạn chưa đăng nhập");
            this.lblQuyen.setIcon(null);
            this.lblQuyen.setForeground(Color.RED);
        }
    }

    private void clock() {
        new Timer(10, (ActionEvent ae) -> {
            Date now = new Date();
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss a");
            String text = sdf.format(now);
            this.lblDongHo.setText(text);
        }).start();
    }

    private void FrmSanPham() {
        try {
            if (UTILS_HELPER.isLogin()) {
                QLSP_UI qlsp = new QLSP_UI();
                qlsp.setLocation((this.pnlHome.getWidth() - qlsp.getWidth()) / 2, (this.pnlHome.getHeight() - qlsp.getHeight()) / 2);
                this.pnlHome.add(qlsp).setVisible(true);
            } else {
                UTILS_HELPER.alert(this, "Vui lòng đăng nhập");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void FrmGiaoDich() {
        try {
            if (UTILS_HELPER.isLogin()) {
                QLGD_UI qlgd = new QLGD_UI();
                qlgd.setLocation((this.pnlHome.getWidth() - qlgd.getWidth()) / 2, (this.pnlHome.getHeight() - qlgd.getHeight()) / 2);
                this.pnlHome.add(qlgd).setVisible(true);
            } else {
                UTILS_HELPER.alert(this, "Vui lòng đăng nhập");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void FrmNguoiDung() {
        try {
            if (UTILS_HELPER.isLogin()) {
                QLND_UI qlnd = new QLND_UI();
                qlnd.setLocation((this.pnlHome.getWidth() - qlnd.getWidth()) / 2, (this.pnlHome.getHeight() - qlnd.getHeight()) / 2);
                this.pnlHome.add(qlnd).setVisible(true);
            } else {
                UTILS_HELPER.alert(this, "Vui lòng đăng nhập");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void FrmKhachHang() {
        try {
            if (UTILS_HELPER.isLogin()) {
                QLTH_UI qlkh = new QLTH_UI();
                qlkh.setLocation((this.pnlHome.getWidth() - qlkh.getWidth()) / 2, (this.pnlHome.getHeight() - qlkh.getHeight()) / 2);
                this.pnlHome.add(qlkh).setVisible(true);
            } else {
                UTILS_HELPER.alert(this, "Vui lòng đăng nhập");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void FrmThongKe() {
        if (UTILS_HELPER.isManager()) {
            try {
                if (UTILS_HELPER.isLogin()) {
                    QLTK_UI qlkh = new QLTK_UI();
                    qlkh.setLocation((this.pnlHome.getWidth() - qlkh.getWidth()) / 2, (this.pnlHome.getHeight() - qlkh.getHeight()) / 2);
                    this.pnlHome.add(qlkh).setVisible(true);
                } else {
                    UTILS_HELPER.alert(this, "Vui lòng đăng nhập");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            UTILS_HELPER.alert(this, "Bạn không phải chủ cửa hàng");
        }
    }

    private void HDSD() {
        try {

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void ketThuc() {
        try {
            if (UTILS_HELPER.confirm(this, "Bạn có muốn kết thúc ứng dụng?")) {
                System.exit(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void dangXuat() {
        try {
            UTILS_HELPER.clear();
            new DN_UI(this, true).setVisible(true);
            if (UTILS_HELPER.isLogin()) {
                this.lblQuyen.setText(UTILS_HELPER.user.getTenND());
            } else {
                this.lblQuyen.setText("Bạn chưa đăng nhập");
                this.lblQuyen.setIcon(null);
                this.lblQuyen.setForeground(Color.RED);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void doiMK() {
        try {
            if (UTILS_HELPER.isLogin()) {
                new DMK_UI(this, true).setVisible(true);
            } else {
                UTILS_HELPER.alert(this, "Vui lòng hãy đăng nhập");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
