package UI;

import DAO.HD_DAO;
import ENTITY.HD_ENTITY;
import HELPER.UTILS_HELPER;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class TTKH_UI extends javax.swing.JFrame {

    private HD_DAO hd_dao;
    private List<HD_ENTITY> list_hd;
    private Locale locale = new Locale("vi", "VN");
    private NumberFormat format = NumberFormat.getCurrencyInstance(locale);
    private QLGD_UI qlgd = new QLGD_UI();
    private DefaultTableModel model1 = new DefaultTableModel();
    private DefaultTableModel modelhdct = new DefaultTableModel();

    public TTKH_UI(String tenkh, String thanhtien, String mahd, String SDT, DefaultTableModel model,
            DefaultTableModel modelhdct, JTextField mahd1, JTextField sdt1, JTextField tenkh1,
            JLabel thanhtien1, JTextArea inhd,
            JLabel lbldanggiao, JLabel lblsuli) {
        initComponents();
        setLocationRelativeTo(null);
        this.hd_dao = new HD_DAO();
        this.txttenkh.setText(tenkh);
        this.txtsdt.setText(SDT);
        this.model1 = model;
        this.modelhdct = modelhdct;

        btnok.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {

                if (HELPER.UTILS_HELPER.confirm(qlgd, "Bạn có muốn in hoa đơn không không?")) {
                    try {
                        inHD(thanhtien, inhd);
                    } catch (ParseException ex) {
                        Logger.getLogger(TTKH_UI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    try {
                        inhd.print();
                    } catch (PrinterException ex) {
                        Logger.getLogger(TTKH_UI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (check() == true) {
                    if (HELPER.UTILS_HELPER.confirm(qlgd, "Bạn có muốn thanh toán không?")) {
                        hoadonGH(mahd, thanhtien);
                    }
                }
                dispose();
                clear();
                clearfromgd(modelhdct, mahd1, sdt1, tenkh1, thanhtien1);
                loadTblTTHD("Đang giao hàng");
                load(lbldanggiao);
                load1(lblsuli);
            }
        });
    }

    private boolean check() {
        String rgxHoTen = "^[A-Za-zÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚÝàáâãèéêìíòóôõùúýĂăĐđĨĩŨũƠơƯưẠ-ỹ ]{3,25}$";
        if (!this.txttenkh.getText().matches(rgxHoTen)) {
            UTILS_HELPER.alert(this, "Họ tên phải là tên tiếng việt hoặc không đấu từ 3-25 kí tự");
            this.txttenkh.requestFocus();
            return false;
        }

        String rgxDienThoai = "(084|086|096|097|098|032|033|034|035|036|037|038|039|089|090|093|070|079|077|078|076|088|091|094|083|084|085|081|082|092|056|058|099|059)[0-9]{7}";
        if (!this.txtsdt.getText().matches(rgxDienThoai)) {
            UTILS_HELPER.alert(this, "Số điện thoại phải gồm 10 số, đúng các đầu số của nhà mạng");
            this.txtsdt.requestFocus();
            return false;
        }
        return true;
    }

    private void hoadonGH(String mahd, String thanhtien) {
        String tenkh = this.txttenkh.getText();
        String diachi = this.txtdiachi.getText();
        String sdt = this.txtsdt.getText();
        String phiship = this.txtphiship.getText();
        String mota = this.txtghichu.getText();
        String ttstring = thanhtien.replaceAll("[. đ]", "");
        float thanhtien1 = Float.parseFloat(ttstring);

        String ttstring2 = phiship.replaceAll("[. đ]", "");
        float phiship1 = Float.parseFloat(ttstring2);

        HD_ENTITY hd_entity = new HD_ENTITY();
        hd_entity.setNgayTao(new Date());
        hd_entity.setMaHD(mahd);
        hd_entity.setThanhTien(thanhtien1);
        hd_entity.setMaNV("HAINH");
        hd_entity.setTenKH(tenkh);
        hd_entity.setDiaChi(diachi);
        hd_entity.setTrangThai("Đang giao hàng");
        hd_entity.setMota(mota);
        hd_entity.setGiaship(phiship1);
        hd_entity.setSDT(sdt);
        this.hd_dao.Update_HD_HOANTHANH(hd_entity);
    }

    private void clear() {
        this.txtdiachi.setText("");
        this.txtghichu.setText("");
        this.txttenkh.setText("");
        this.txtsdt.setText("");
        this.txtphiship.setText("");
    }

    private void clearfromgd(DefaultTableModel modelhdct, JTextField mahd1, JTextField sdt1, JTextField tenkh1, JLabel thanhtien1) {
        this.modelhdct.setRowCount(0);
        mahd1.setText("");
        sdt1.setText("");
        tenkh1.setText("");
        thanhtien1.setText("");
    }

    private void inHD(String thanhtien, JTextArea txtinhd) throws ParseException {
        String tenKH = this.txttenkh.getText();
        String diachi = this.txtdiachi.getText();
        String phiShip = this.txtphiship.getText();
        DateFormat output = new SimpleDateFormat("dd-MM-yyyy", Locale.US);
        DateFormat input = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        Date nth = input.parse(java.time.LocalDate.now().toString());
        String outputDate = output.format(nth);
        txtinhd.setText(txtinhd.getText() + "Hóa đơn thanh toán" + "\n");
        txtinhd.setText(txtinhd.getText() + "*******************" + "\n");
        txtinhd.setText(txtinhd.getText() + "\n");
        txtinhd.setText(txtinhd.getText() + "Tên khách hàng: " + tenKH + "\n");
        txtinhd.setText(txtinhd.getText() + "Thành tiền: " + thanhtien + "\n");
        txtinhd.setText(txtinhd.getText() + "Thời gian thanh toán: " + outputDate + "\n");
        txtinhd.setText(txtinhd.getText() + "Địa chỉ giao hàng: " + diachi + "\n");
        txtinhd.setText(txtinhd.getText() + "Phí ship: " + phiShip + "\n");
        txtinhd.setText(txtinhd.getText() + "*******************" + "\n");
        txtinhd.setText(txtinhd.getText() + "Hẹn gặp lại quý khách vào lần tới" + "\n");
    }

    private void loadTblTTHD(String loai) {
        this.model1.setRowCount(0);
        try {
            this.list_hd = this.hd_dao.selectAll_LOAI(loai);
            for (HD_ENTITY sp_Entity : this.list_hd) {
                this.model1.addRow(new Object[]{
                    sp_Entity.getMaHD(),
                    sp_Entity.getTenKH(),
                    sp_Entity.getMaNV(),
                    this.format.format(sp_Entity.getThanhTien())
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
            UTILS_HELPER.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    private void load(JLabel lbl) {
        this.list_hd = this.hd_dao.selectAll_LOAI("Đang giao hàng");
        int so1 = list_hd.size();
        lbl.setText(String.valueOf(so1));
    }

    private void load1(JLabel lbl) {
        this.list_hd = this.hd_dao.selectAll_LOAI("Chờ sử lí");
        int so1 = list_hd.size();
        lbl.setText(String.valueOf(so1));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        txttenkh = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtsdt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtdiachi = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtghichu = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtphiship = new javax.swing.JTextField();
        btnok = new javax.swing.JButton();
        btnok1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel5.setText("Tên KH:");

        jLabel3.setText("SĐT:");

        jLabel2.setText("Địa chỉ:");

        txtdiachi.setColumns(20);
        txtdiachi.setRows(5);
        jScrollPane2.setViewportView(txtdiachi);

        jLabel4.setText("Ghi chú:");

        txtghichu.setColumns(20);
        txtghichu.setRows(5);
        jScrollPane1.setViewportView(txtghichu);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("THÔNG TIN KHÁCH HÀNG");

        jLabel7.setText("Phí ship:");

        btnok.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Accept.png"))); // NOI18N
        btnok.setText("Đồng ý");
        btnok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnokActionPerformed(evt);
            }
        });

        btnok1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ICON/Delete.png"))); // NOI18N
        btnok1.setText("Hủy");
        btnok1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnok1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtsdt, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtphiship, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txttenkh, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnok, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnok1)))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jScrollPane1, jScrollPane2, txtphiship, txtsdt, txttenkh});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jLabel2, jLabel3, jLabel4, jLabel5, jLabel7});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnok, btnok1});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txttenkh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtsdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtphiship, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnok, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnok1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jScrollPane1, jScrollPane2});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jLabel2, jLabel3, jLabel4, jLabel5, jLabel7, txtphiship, txtsdt, txttenkh});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnok, btnok1});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnok1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnok1ActionPerformed
        this.dispose();
        this.clear();
    }//GEN-LAST:event_btnok1ActionPerformed

    private void btnokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnokActionPerformed

    }//GEN-LAST:event_btnokActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnok;
    private javax.swing.JButton btnok1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea txtdiachi;
    private javax.swing.JTextArea txtghichu;
    private javax.swing.JTextField txtphiship;
    private javax.swing.JTextField txtsdt;
    private javax.swing.JTextField txttenkh;
    // End of variables declaration//GEN-END:variables
}
